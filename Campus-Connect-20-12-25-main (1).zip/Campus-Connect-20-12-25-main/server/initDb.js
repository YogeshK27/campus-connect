import sqlite3 from 'sqlite3';
import { readFileSync, existsSync, unlinkSync } from 'fs';
import { join } from 'path';

const schemaPath = join(process.cwd(), 'server', 'schema.sql');
const schema = readFileSync(schemaPath, 'utf8');

const targetFiles = [
    join(process.cwd(), 'server', 'woxify.db'),
    join(process.cwd(), '.db'),
    join(process.cwd(), '.sqlite'),
    join(process.cwd(), '.sqlite3')
];

async function initFile(path) {
    return new Promise((resolve, reject) => {
        const db = new sqlite3.Database(path, (err) => {
            if (err) return reject(err);
            db.exec(schema, (err) => {
                if (err) {
                    db.close();
                    return reject(err);
                }
                db.close();
                resolve();
            });
        });
    });
}

(async () => {
    for (const file of targetFiles) {
        try {
            console.log(`Initializing ${file}...`);
            await initFile(file);
            console.log(`Success: ${file}`);
        } catch (err) {
            console.error(`Failed to initialize ${file}:`, err.message);
        }
    }
    console.log('All databases initialized.');
})();
