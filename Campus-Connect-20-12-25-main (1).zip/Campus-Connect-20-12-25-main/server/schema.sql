-- Woxify SQLite Schema (Server-side)
-- Used for local data refinement and potential sync with Firebase

CREATE TABLE users (
    uid TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    email TEXT UNIQUE,
    profilePhotoUrl TEXT,
    college TEXT,
    year TEXT,
    branch TEXT,
    bio TEXT,
    role TEXT DEFAULT 'member',
    createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
    lastLogin DATETIME
);

CREATE TABLE posts (
    id TEXT PRIMARY KEY,
    userId TEXT NOT NULL,
    content TEXT NOT NULL,
    imageUrl TEXT,
    createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (userId) REFERENCES users(uid)
);

CREATE TABLE rides (
    id TEXT PRIMARY KEY,
    hostId TEXT NOT NULL,
    rideType TEXT,
    "from" TEXT,
    "to" TEXT,
    date TEXT,
    time TEXT,
    totalSeats INTEGER,
    availableSeats INTEGER,
    fare INTEGER,
    status TEXT DEFAULT 'available',
    createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (hostId) REFERENCES users(uid)
);

CREATE TABLE friendRequests (
    id TEXT PRIMARY KEY,
    fromUserId TEXT NOT NULL,
    toUserId TEXT NOT NULL,
    status TEXT DEFAULT 'pending',
    createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (fromUserId) REFERENCES users(uid),
    FOREIGN KEY (toUserId) REFERENCES users(uid)
);
