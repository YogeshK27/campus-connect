import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { ThemeProvider } from './context/ThemeContext';
import { ToastProvider } from './context/ToastContext';
import Layout from './components/layout/Layout';
import Home from './pages/Home';
import ProtectedRoute from './components/auth/ProtectedRoute';
import Login from './pages/auth/Login';
import ProfileSetup from './pages/auth/ProfileSetup';
import Signup from './pages/auth/Signup';
import Profile from './pages/Profile';
import Messages from './pages/Messages';
import Notifications from './pages/Notifications';
import Saved from './pages/Saved';
import RideSharing from './pages/RideSharing';
import Events from './pages/Events';
import Notes from './pages/Notes';
import LostFound from './pages/LostFound';
import Clubs from './pages/Clubs';
import Internships from './pages/Internships';
import Polls from './pages/Polls';
import AISection from './pages/AISection';
import Friends from './pages/Friends';
import Chat from './pages/Chat';

const CloudBackground = () => (
  <div className="google-clouds-bg">
    <div className="cloud w-64 h-24 top-[10%] left-[-10%]" style={{ animationDuration: '40s' }}></div>
    <div className="cloud w-80 h-32 top-[40%] left-[-20%]" style={{ animationDuration: '60s', animationDelay: '-10s' }}></div>
    <div className="cloud w-72 h-28 top-[70%] left-[-15%]" style={{ animationDuration: '50s', animationDelay: '-25s' }}></div>
    <div className="cloud w-96 h-40 top-[20%] left-[-25%]" style={{ animationDuration: '70s', animationDelay: '-40s' }}></div>
  </div>
);

function App() {
  return (
    <ThemeProvider>
      <ToastProvider>
        <CloudBackground />
        <BrowserRouter>
          <Routes>
            <Route path="/login" element={<Login />} />
            <Route path="/signup" element={<Signup />} />
            <Route
              path="/*"
              element={
                <ProtectedRoute>
                  <Layout>
                    <Routes>
                      <Route path="/" element={<Home />} />
                      <Route path="/profile" element={<Profile />} />
                      <Route path="/profile/:uid" element={<Profile />} />
                      <Route path="/setup" element={<ProfileSetup />} />
                      <Route path="/messages" element={<Messages />} />
                      <Route path="/notifications" element={<Notifications />} />
                      <Route path="/saved" element={<Saved />} />
                      <Route path="/rides" element={<RideSharing />} />
                      <Route path="/events" element={<Events />} />
                      <Route path="/notes" element={<Notes />} />
                      <Route path="/lost-found" element={<LostFound />} />
                      <Route path="/clubs" element={<Clubs />} />
                      <Route path="/internships" element={<Internships />} />
                      <Route path="/polls" element={<Polls />} />
                      <Route path="/ai" element={<AISection />} />
                      <Route path="/friends" element={<Friends />} />
                      <Route path="/chat/:chatId" element={<Chat />} />
                      <Route path="*" element={<Home />} />
                    </Routes>
                  </Layout>
                </ProtectedRoute>
              }
            />
          </Routes>
        </BrowserRouter>
      </ToastProvider>
    </ThemeProvider>
  );
}

export default App;
