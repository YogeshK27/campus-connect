import React, { useState, useRef } from 'react';
import { Image, Send, X, Paperclip, Loader2 } from 'lucide-react';
import { auth, storage } from '../../lib/firebase';
import { ref as storageRef, uploadBytes, getDownloadURL } from 'firebase/storage';
import { dbService } from '../../services/db.service';

const CreatePost: React.FC = () => {
  const [content, setContent] = useState('');
  const [image, setImage] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setImage(file);
      setPreview(URL.createObjectURL(file));
    }
  };

  const clearImage = () => {
    setImage(null);
    setPreview(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!content.trim() && !image) return;
    setLoading(true);

    try {
      if (!auth.currentUser) throw new Error("Not authenticated");
      const user = auth.currentUser;

      let imageUrl = '';
      if (image) {
        const fileRef = storageRef(storage, `posts/${user.uid}/${Date.now()}_${image.name}`);
        await uploadBytes(fileRef, image);
        imageUrl = await getDownloadURL(fileRef);
      }

      await dbService.createPost({
        uid: user.uid,
        authorName: user.displayName || 'Campus User',
        authorPic: user.photoURL || '',
        content: content,
        type: 'post',
        mediaUrl: imageUrl
      });

      setContent('');
      clearImage();
    } catch (error: any) {
      alert("Failed to post: " + error.message);
    } finally {
      setLoading(false);
    }
  };

  const userInitial = auth.currentUser?.displayName?.charAt(0) || 'U';

  return (
    <div className="bg-[var(--color-surface)] border border-[var(--color-border)] rounded-2xl p-5 mb-6 shadow-sm">
      <form onSubmit={handleSubmit}>
        <div className="flex gap-4 mb-4">
          <div className="flex-shrink-0">
            {auth.currentUser?.photoURL ? (
              <img src={auth.currentUser.photoURL} className="w-10 h-10 rounded-full object-cover" alt="" />
            ) : (
              <div className="w-10 h-10 rounded-full bg-indigo-500 flex items-center justify-center text-white font-bold">
                {userInitial}
              </div>
            )}
          </div>
          <textarea
            placeholder="What's on your mind? Share with the campus..."
            className="flex-1 bg-transparent border-none text-[var(--color-text-main)] font-medium text-sm focus:outline-none resize-none pt-2"
            value={content}
            onChange={(e) => setContent(e.target.value)}
            rows={2}
          />
        </div>

        {preview && (
          <div className="relative mb-4 rounded-xl overflow-hidden">
            <img src={preview} className="w-full max-h-[300px] object-cover" alt="" />
            <button type="button" onClick={clearImage} className="absolute top-2 right-2 bg-black/60 text-white p-1 rounded-full hover:bg-black transition-colors">
              <X size={16} />
            </button>
          </div>
        )}

        <div className="flex items-center justify-between pt-4 border-t border-[var(--color-border)]">
          <div className="flex gap-1">
            <button type="button" onClick={() => fileInputRef.current?.click()} className="p-2 text-indigo-500 hover:bg-indigo-500/10 rounded-full transition-colors"><Image size={20} /></button>
            <button type="button" className="p-2 text-indigo-500 hover:bg-indigo-500/10 rounded-full transition-colors"><Paperclip size={20} /></button>
            <input type="file" ref={fileInputRef} hidden accept="image/*" onChange={handleImageSelect} />
          </div>
          <button type="submit" disabled={loading || (!content.trim() && !image)} className="bg-indigo-600 text-white px-6 py-2 rounded-full font-bold text-sm hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2 transition-all active:scale-95 shadow-md shadow-indigo-500/20">
            {loading ? <Loader2 className="animate-spin" size={16} /> : <Send size={16} />}
            {loading ? 'Posting...' : 'Post'}
          </button>
        </div>
      </form>
    </div>
  );
};

export default CreatePost;
