import React, { useState, useRef, useEffect } from 'react';
import { MessageCircle, Share2, MoreHorizontal, ThumbsUp, ThumbsDown, Heart, Smile, HandHeart, Bookmark, Trash2 } from 'lucide-react';
import { auth } from '../../lib/firebase';
import { Link } from 'react-router-dom';
import CommentsSection from '../common/CommentsSection';
import { dbService } from '../../services/db.service';
import { formatDate } from '../../utils/date.utils';
import { useToast } from '../../context/ToastContext';

export interface Post {
  $id: string; // Firestore ID
  authorName: string;
  authorPic?: string;
  content: string;
  mediaUrl?: string;
  reactions?: Record<string, string>; // uid -> type
  reactionCounts?: {
    like: number;
    dislike: number;
    love: number;
    laugh: number;
    support: number;
  };
  comments: number;
  createdAt: any; // Firestore Timestamp or string
  userId?: string;
}

interface PostItemProps {
  post: Post;
}

const REACTION_TYPES = [
  { type: 'like', icon: ThumbsUp, color: 'text-blue-500', label: 'Like' },
  { type: 'dislike', icon: ThumbsDown, color: 'text-orange-500', label: 'Dislike' },
  { type: 'love', icon: Heart, color: 'text-red-500', label: 'Love' },
  { type: 'laugh', icon: Smile, color: 'text-yellow-500', label: 'Haha' },
  { type: 'support', icon: HandHeart, color: 'text-green-500', label: 'Support' },
];

const PostItem: React.FC<PostItemProps> = ({ post }) => {
  const [showReactions, setShowReactions] = useState(false);
  const reactionTimeoutRef = useRef<any>(null);
  const [showComments, setShowComments] = useState(false);
  const currentUser = auth.currentUser;
  const { showToast } = useToast();

  const handleMouseEnter = () => {
    if (reactionTimeoutRef.current) clearTimeout(reactionTimeoutRef.current);
    setShowReactions(true);
  };

  const handleMouseLeave = () => {
    reactionTimeoutRef.current = setTimeout(() => {
      setShowReactions(false);
    }, 500);
  };

  const handleReaction = async (type: string) => {
    if (!currentUser) return showToast("Please login to react", "error");
    const uid = currentUser.uid;

    try {
      const currentReaction = post.reactions?.[uid];
      const updates: any = {};

      if (currentReaction === type) {
        updates[`reactions.${uid}`] = null;
        updates[`reactionCounts.${type}`] = Math.max(0, (post.reactionCounts?.[type as keyof typeof post.reactionCounts] || 1) - 1);
      } else {
        updates[`reactions.${uid}`] = type;
        updates[`reactionCounts.${type}`] = (post.reactionCounts?.[type as keyof typeof post.reactionCounts] || 0) + 1;
        if (currentReaction) {
          updates[`reactionCounts.${currentReaction}`] = Math.max(0, (post.reactionCounts?.[currentReaction as keyof typeof post.reactionCounts] || 1) - 1);
        }
      }

      await dbService.updatePost(post.$id, updates);
      setShowReactions(false);
    } catch (error) {
      console.error("Error updating reaction (Firestore):", error);
      showToast("Failed to update reaction", "error");
    }
  };

  const handleDelete = async () => {
    if (!currentUser || currentUser.uid !== post.userId) return;
    if (!confirm("Delete post permanently?")) return;
    try {
      await dbService.deletePost(post.$id);
      showToast("Post deleted successfully");
    } catch (error) {
      console.error("Error deleting post (Firestore):", error);
      showToast("Failed to delete post", "error");
    }
  };

  const handleShare = () => {
    const url = `${window.location.origin}/post/${post.$id}`;
    navigator.clipboard.writeText(url);
    showToast("Link copied to clipboard", "success");
  };

  const [isSaved, setIsSaved] = useState(false);
  useEffect(() => {
    if (!currentUser) return;
    const checkSaved = async () => {
      const saved = await dbService.isItemSaved(currentUser.uid, post.$id);
      setIsSaved(saved);
    };
    checkSaved();
  }, [currentUser, post.$id]);

  const handleSave = async () => {
    if (!currentUser) return;
    try {
      await dbService.toggleSaveItem(currentUser.uid, post.$id, 'post', post, isSaved);
      setIsSaved(!isSaved);
      showToast(isSaved ? "Removed from saved" : "Saved to your profile", "success");
    } catch (err) {
      console.error("Error toggling save:", err);
      showToast("Failed to save item", "error");
    }
  };

  const myReaction = currentUser && post.reactions ? post.reactions[currentUser.uid] : null;
  const authorInitial = post.authorName ? post.authorName.charAt(0).toUpperCase() : '?';

  return (
    <div className="bg-[var(--color-surface)] rounded-2xl p-5 mb-4 border border-[var(--color-border)] shadow-sm hover:border-indigo-500/30 transition-colors">
      <div className="flex justify-between items-start mb-4">
        <Link to={`/profile/${post.userId}`} className="flex items-center gap-3 group">
          <div className="w-10 h-10 rounded-full overflow-hidden bg-indigo-500 flex items-center justify-center text-white font-bold group-hover:scale-105 transition-transform">
            {post.authorPic ? (
              <img src={post.authorPic} className="w-full h-full object-cover" alt="" />
            ) : authorInitial}
          </div>
          <div>
            <div className="font-bold text-[var(--color-text-main)] group-hover:text-indigo-500">{post.authorName}</div>
            <div className="text-[10px] text-[var(--color-text-muted)] font-bold uppercase tracking-widest">{formatDate(post.createdAt)}</div>
          </div>
        </Link>
        <div className="flex gap-1">
          {currentUser?.uid === post.userId && (
            <button onClick={handleDelete} className="p-2 text-red-500 hover:bg-red-500/10 rounded-full"><Trash2 size={18} /></button>
          )}
          <button className="p-2 text-[var(--color-text-muted)]"><MoreHorizontal size={18} /></button>
        </div>
      </div>

      <div className="mb-4">
        <p className="text-[var(--color-text-main)] whitespace-pre-wrap leading-relaxed">{post.content}</p>
        {post.mediaUrl && (
          <div className="mt-3 rounded-xl overflow-hidden border border-[var(--color-border)]">
            <img src={post.mediaUrl} className="w-full max-h-[400px] object-cover" alt="" />
          </div>
        )}
      </div>

      <div className="flex items-center gap-4 pt-3 border-t border-[var(--color-border)]">
        <div className="relative" onMouseEnter={handleMouseEnter} onMouseLeave={handleMouseLeave}>
          {showReactions && (
            <div className="absolute bottom-full left-0 mb-2 flex gap-2 bg-[var(--color-surface)] border border-[var(--color-border)] p-2 rounded-full shadow-xl animate-in fade-in zoom-in duration-200">
              {REACTION_TYPES.map((r) => (
                <button key={r.type} onClick={() => handleReaction(r.type)} className="p-2 rounded-full hover:bg-[var(--color-surface-hover)] hover:scale-125 transition-all"><r.icon size={20} className={r.color} /></button>
              ))}
            </div>
          )}
          <button className={`flex items-center gap-2 text-sm font-bold ${myReaction ? 'text-indigo-500' : 'text-[var(--color-text-secondary)]'}`}>
            {myReaction ? (() => { const I = REACTION_TYPES.find(r => r.type === myReaction)?.icon || ThumbsUp; return <I size={18} /> })() : <ThumbsUp size={18} />}
            {Object.values(post.reactionCounts || {}).reduce((a, b) => a + b, 0) || 'Like'}
          </button>
        </div>
        <button onClick={() => setShowComments(!showComments)} className="flex items-center gap-2 text-sm font-bold text-[var(--color-text-secondary)]">
          <MessageCircle size={18} /> {post.comments || 'Comment'}
        </button>
        <button onClick={handleShare} className="ml-auto text-[var(--color-text-muted)] hover:text-indigo-500"><Share2 size={18} /></button>
        <button onClick={handleSave} className={`transition-colors ${isSaved ? 'text-indigo-500' : 'text-[var(--color-text-muted)]'}`}><Bookmark size={18} fill={isSaved ? 'currentColor' : 'none'} /></button>
      </div>

      {showComments && (
        <div className="mt-4 pt-4 border-t border-[var(--color-border)]">
          <CommentsSection parentId={post.$id} collectionPath={`posts/${post.$id}/comments`} currentUser={currentUser} />
        </div>
      )}
    </div>
  );
};

export default PostItem;
