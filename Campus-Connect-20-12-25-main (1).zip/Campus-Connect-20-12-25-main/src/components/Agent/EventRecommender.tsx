import React, { useState, useEffect } from 'react';
import { Sparkles, Calendar, MapPin, Star, TrendingUp } from 'lucide-react';
import { auth } from '../../lib/firebase';
import { eventRecommenderService, type EventRecommendation } from '../../services/agentic/event-recommender.service';
import { useToast } from '../../context/ToastContext';

const EventRecommender: React.FC = () => {
    const [recommendations, setRecommendations] = useState<EventRecommendation[]>([]);
    const [loading, setLoading] = useState(false);
    const { showToast } = useToast();

    const loadRecommendations = async () => {
        const currentUser = auth.currentUser;
        if (!currentUser) return;

        setLoading(true);
        try {
            const recs = await eventRecommenderService.getPersonalizedRecommendations(currentUser.uid);
            setRecommendations(recs);

            if (recs.length > 0) {
                showToast(`Found ${recs.length} events you might love!`, 'success');
            }
        } catch (error) {
            console.error('Error loading recommendations:', error);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        loadRecommendations();
    }, []);

    if (loading && recommendations.length === 0) {
        return (
            <div className="bg-gradient-to-br from-blue-500/10 via-cyan-500/10 to-teal-500/10 border-2 border-blue-500/20 rounded-3xl p-6 mb-6">
                <div className="flex items-center justify-center gap-3 py-8">
                    <div className="animate-spin rounded-full h-8 w-8 border-3 border-blue-500 border-t-transparent"></div>
                    <p className="text-[var(--color-text-secondary)]">Analyzing your preferences...</p>
                </div>
            </div>
        );
    }

    if (recommendations.length === 0) {
        return null;
    }

    return (
        <div className="bg-gradient-to-br from-blue-500/10 via-cyan-500/10 to-teal-500/10 border-2 border-blue-500/20 rounded-3xl p-6 mb-6">
            <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-cyan-600 rounded-2xl flex items-center justify-center shadow-lg">
                    <Star className="text-white" size={24} />
                </div>
                <div>
                    <h2 className="text-2xl font-black text-[var(--color-text-main)] tracking-tight">
                        Events For You
                    </h2>
                    <p className="text-sm text-[var(--color-text-secondary)] font-medium">
                        AI-powered personalized recommendations
                    </p>
                </div>
            </div>

            <div className="bg-[var(--color-surface)] border border-[var(--color-border)] rounded-2xl p-4 mb-4">
                <div className="flex items-start gap-3">
                    <Sparkles className="text-blue-500 mt-1" size={20} />
                    <div className="flex-1">
                        <p className="text-sm text-[var(--color-text-secondary)] leading-relaxed">
                            I learned your interests from your activity and found events you'll love.
                            These recommendations are personalized just for you!
                        </p>
                    </div>
                </div>
            </div>

            <div className="space-y-3">
                {recommendations.map((rec) => (
                    <div key={rec.eventId} className="bg-[var(--color-surface)] border border-[var(--color-border)] rounded-2xl p-4 hover:border-blue-500/30 transition-colors">
                        <div className="flex items-start justify-between mb-3">
                            <div className="flex-1">
                                <h3 className="font-bold text-[var(--color-text-main)] text-lg mb-1">{rec.eventTitle}</h3>
                                <div className="flex items-center gap-4 text-sm text-[var(--color-text-secondary)] mb-2">
                                    <div className="flex items-center gap-1">
                                        <Calendar size={14} />
                                        <span>{rec.eventDate} at {rec.eventTime}</span>
                                    </div>
                                    <div className="flex items-center gap-1">
                                        <MapPin size={14} />
                                        <span>{rec.eventLocation}</span>
                                    </div>
                                </div>
                            </div>
                            <div className="flex items-center gap-1 bg-gradient-to-r from-blue-500/10 to-cyan-500/10 px-3 py-1 rounded-full">
                                <TrendingUp size={14} className="text-blue-500" />
                                <span className="text-sm font-black text-blue-600 dark:text-blue-400">{rec.matchScore}%</span>
                            </div>
                        </div>

                        <div className="bg-gradient-to-r from-blue-500/5 to-cyan-500/5 border border-blue-500/10 rounded-xl p-3">
                            <p className="text-xs font-bold text-blue-700 dark:text-blue-300 mb-1">✨ Why you'll love this</p>
                            <p className="text-sm text-[var(--color-text-main)] italic">"{rec.reason}"</p>
                        </div>
                    </div>
                ))}
            </div>

            <button
                onClick={loadRecommendations}
                className="w-full mt-4 bg-gradient-to-r from-blue-600 to-cyan-600 text-white py-3 rounded-2xl font-bold shadow-lg hover:shadow-xl hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center justify-center gap-2"
            >
                <Sparkles size={20} />
                Refresh Recommendations
            </button>
        </div>
    );
};

export default EventRecommender;
