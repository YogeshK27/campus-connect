import React, { useState } from 'react';
import { Sparkles, Clock, AlertTriangle, CheckCircle, XCircle } from 'lucide-react';
import { auth } from '../../lib/firebase';
import { scheduleAssistantService, type Conflict, type Solution } from '../../services/agentic/schedule-assistant.service';
import { useToast } from '../../context/ToastContext';

const ScheduleAssistant: React.FC = () => {
    const [conflicts, setConflicts] = useState<Conflict[]>([]);
    const [solutions, setSolutions] = useState<Map<string, Solution[]>>(new Map());
    const [loading, setLoading] = useState(false);
    const { showToast } = useToast();

    const checkForConflicts = async () => {
        const currentUser = auth.currentUser;
        if (!currentUser) {
            showToast('Please login to use Schedule Assistant', 'error');
            return;
        }

        setLoading(true);
        try {
            const detectedConflicts = await scheduleAssistantService.detectConflicts(currentUser.uid);
            setConflicts(detectedConflicts);

            if (detectedConflicts.length > 0) {
                showToast(`Found ${detectedConflicts.length} scheduling conflict(s)!`, 'error');

                // Generate solutions for each conflict
                const newSolutions = new Map<string, Solution[]>();
                for (const conflict of detectedConflicts) {
                    const sols = await scheduleAssistantService.generateSolutions(conflict);
                    newSolutions.set(conflict.id, sols);
                }
                setSolutions(newSolutions);
            } else {
                showToast('No conflicts detected! Your schedule looks good.', 'success');
            }
        } catch (error) {
            console.error('Error checking conflicts:', error);
            showToast('Failed to check schedule', 'error');
        } finally {
            setLoading(false);
        }
    };

    const getSeverityColor = (severity: string) => {
        switch (severity) {
            case 'high': return 'text-red-600 dark:text-red-400';
            case 'medium': return 'text-orange-600 dark:text-orange-400';
            default: return 'text-yellow-600 dark:text-yellow-400';
        }
    };

    const getSeverityIcon = (severity: string) => {
        switch (severity) {
            case 'high': return <XCircle size={18} />;
            case 'medium': return <AlertTriangle size={18} />;
            default: return <Clock size={18} />;
        }
    };

    return (
        <div className="bg-gradient-to-br from-orange-500/10 via-red-500/10 to-pink-500/10 border-2 border-orange-500/20 rounded-3xl p-6 mb-6">
            <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 bg-gradient-to-br from-orange-500 to-red-600 rounded-2xl flex items-center justify-center shadow-lg">
                    <Clock className="text-white" size={24} />
                </div>
                <div>
                    <h2 className="text-2xl font-black text-[var(--color-text-main)] tracking-tight">
                        Schedule Assistant
                    </h2>
                    <p className="text-sm text-[var(--color-text-secondary)] font-medium">
                        AI-powered conflict detection & resolution
                    </p>
                </div>
            </div>

            <div className="bg-[var(--color-surface)] border border-[var(--color-border)] rounded-2xl p-4 mb-4">
                <div className="flex items-start gap-3">
                    <Sparkles className="text-orange-500 mt-1" size={20} />
                    <div className="flex-1">
                        <p className="text-sm text-[var(--color-text-secondary)] leading-relaxed">
                            I monitor your calendar for conflicts and use AI to suggest smart solutions based on priority and context.
                        </p>
                    </div>
                </div>
            </div>

            <button
                onClick={checkForConflicts}
                disabled={loading}
                className="w-full bg-gradient-to-r from-orange-600 to-red-600 text-white py-3 rounded-2xl font-bold shadow-lg hover:shadow-xl hover:scale-[1.02] active:scale-[0.98] transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 mb-4"
            >
                {loading ? (
                    <>
                        <div className="animate-spin rounded-full h-5 w-5 border-2 border-white border-t-transparent"></div>
                        Checking Schedule...
                    </>
                ) : (
                    <>
                        <Clock size={20} />
                        Check for Conflicts
                    </>
                )}
            </button>

            {conflicts.length > 0 && (
                <div className="space-y-3">
                    <div className="flex items-center gap-2">
                        <div className="h-px flex-1 bg-gradient-to-r from-transparent via-[var(--color-border)] to-transparent"></div>
                        <span className="text-xs font-bold text-[var(--color-text-muted)] uppercase tracking-widest">
                            Conflicts Detected
                        </span>
                        <div className="h-px flex-1 bg-gradient-to-r from-transparent via-[var(--color-border)] to-transparent"></div>
                    </div>

                    {conflicts.map((conflict) => (
                        <div key={conflict.id} className="bg-[var(--color-surface)] border border-[var(--color-border)] rounded-2xl p-4">
                            <div className={`flex items-center gap-2 mb-3 ${getSeverityColor(conflict.severity)}`}>
                                {getSeverityIcon(conflict.severity)}
                                <span className="font-bold text-sm uppercase">{conflict.severity} Priority Conflict</span>
                            </div>

                            <div className="space-y-2 mb-3">
                                {conflict.items.map((item, idx) => (
                                    <div key={item.id} className="flex items-start gap-2 p-2 bg-[var(--color-bg)] rounded-xl">
                                        <span className="text-xs font-bold text-[var(--color-text-muted)] mt-1">{idx + 1}.</span>
                                        <div className="flex-1">
                                            <p className="text-sm font-medium text-[var(--color-text-main)]">{item.title}</p>
                                            <p className="text-xs text-[var(--color-text-muted)]">
                                                {item.date} at {item.time}
                                                {item.location && ` • ${item.location}`}
                                            </p>
                                        </div>
                                    </div>
                                ))}
                            </div>

                            {solutions.get(conflict.id) && solutions.get(conflict.id)!.length > 0 && (
                                <div className="bg-gradient-to-r from-orange-500/10 to-red-500/10 border border-orange-500/20 rounded-xl p-3">
                                    <p className="text-xs font-bold text-orange-700 dark:text-orange-300 mb-2">💡 AI Suggestions</p>
                                    <div className="space-y-2">
                                        {solutions.get(conflict.id)!.slice(0, 2).map((solution) => (
                                            <div key={solution.id} className="flex items-start gap-2">
                                                <CheckCircle size={14} className="text-green-500 mt-0.5" />
                                                <div className="flex-1">
                                                    <p className="text-sm text-[var(--color-text-main)] font-medium">{solution.description}</p>
                                                    <p className="text-xs text-[var(--color-text-muted)]">{solution.details}</p>
                                                </div>
                                                <span className="text-xs bg-green-500/10 text-green-600 dark:text-green-400 px-2 py-1 rounded-full font-bold">
                                                    {solution.confidence}%
                                                </span>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            )}
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
};

export default ScheduleAssistant;
