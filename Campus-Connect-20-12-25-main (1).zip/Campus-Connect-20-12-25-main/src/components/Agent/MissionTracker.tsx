import React from 'react';
import { CheckCircle, Clock, XCircle, Loader2 } from 'lucide-react';
import type { Mission } from '../../types/agent.types';

interface MissionTrackerProps {
    missions: Mission[];
}

const MissionTracker: React.FC<MissionTrackerProps> = ({ missions }) => {
    const getStatusIcon = (status: string) => {
        switch (status) {
            case 'completed':
                return <CheckCircle size={16} className="text-green-500" />;
            case 'failed':
                return <XCircle size={16} className="text-red-500" />;
            case 'in_progress':
                return <Loader2 size={16} className="text-blue-500 animate-spin" />;
            default:
                return <Clock size={16} className="text-gray-400" />;
        }
    };

    const getMissionIcon = (type: string) => {
        switch (type) {
            case 'transport':
                return '🚗';
            case 'credentialing':
                return '🎫';
            case 'academic_sync':
                return '📚';
            default:
                return '📋';
        }
    };

    return (
        <div className="space-y-4">
            {missions.map((mission) => (
                <div
                    key={mission.id}
                    className="bg-[var(--color-surface)] border border-[var(--color-border)] rounded-2xl p-4 space-y-3"
                >
                    <div className="flex items-center gap-3">
                        <span className="text-2xl">{getMissionIcon(mission.type)}</span>
                        <div className="flex-1">
                            <h4 className="font-bold text-[var(--color-text-main)] flex items-center gap-2">
                                {mission.title}
                                {getStatusIcon(mission.status)}
                            </h4>
                            {mission.error && (
                                <p className="text-xs text-red-500 mt-1">{mission.error}</p>
                            )}
                        </div>
                    </div>

                    {/* Mission Steps */}
                    <div className="pl-8 space-y-2">
                        {mission.steps.map((step) => (
                            <div key={step.id} className="flex items-start gap-2 text-sm">
                                <div className="mt-0.5">{getStatusIcon(step.status)}</div>
                                <div className="flex-1">
                                    <p className="text-[var(--color-text-secondary)]">{step.description}</p>
                                    {step.details && (
                                        <p className="text-xs text-[var(--color-text-muted)] mt-0.5">
                                            {step.details}
                                        </p>
                                    )}
                                </div>
                            </div>
                        ))}
                    </div>

                    {/* Mission Result */}
                    {mission.status === 'completed' && mission.result && (
                        <div className="mt-3 p-3 bg-green-500/10 border border-green-500/20 rounded-xl">
                            <p className="text-sm font-medium text-green-700 dark:text-green-400">
                                {mission.type === 'transport' && (
                                    <>
                                        Ride confirmed with {mission.result.driverName} at {mission.result.time} (₹
                                        {mission.result.fare})
                                    </>
                                )}
                                {mission.type === 'credentialing' && (
                                    <>Event pass ready for {mission.result.eventTitle}</>
                                )}
                                {mission.type === 'academic_sync' && (
                                    <>{mission.result.summary}</>
                                )}
                            </p>
                        </div>
                    )}
                </div>
            ))}
        </div>
    );
};

export default MissionTracker;
