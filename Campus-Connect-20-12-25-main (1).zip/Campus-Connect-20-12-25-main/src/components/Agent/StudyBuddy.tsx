import React, { useState } from 'react';
import { Sparkles, Users, BookOpen, TrendingUp } from 'lucide-react';
import { auth } from '../../lib/firebase';
import { studyBuddyService, type StudyGroupSuggestion } from '../../services/agentic/study-buddy.service';
import { useToast } from '../../context/ToastContext';

const StudyBuddy: React.FC = () => {
    const [suggestions, setSuggestions] = useState<StudyGroupSuggestion[]>([]);
    const [loading, setLoading] = useState(false);
    const { showToast } = useToast();

    const handleFindStudyPartners = async () => {
        const currentUser = auth.currentUser;
        if (!currentUser) {
            showToast('Please login to use Study Buddy', 'error');
            return;
        }

        setLoading(true);
        try {
            // For demo: simulate finding partners for a common subject
            const matches = await studyBuddyService.findStudyPartners('Data Structures', currentUser.uid);

            if (matches.length > 0) {
                const suggestion = await studyBuddyService.createStudyGroupSuggestion(
                    'Data Structures',
                    matches
                );

                if (suggestion) {
                    setSuggestions([suggestion]);
                    showToast(`Found ${matches.length} study partners!`, 'success');
                }
            } else {
                showToast('No study partners found yet. Try posting about what you\'re studying!', 'info');
            }
        } catch (error) {
            console.error('Error finding study partners:', error);
            showToast('Failed to find study partners', 'error');
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="bg-gradient-to-br from-purple-500/10 via-pink-500/10 to-orange-500/10 border-2 border-purple-500/20 rounded-3xl p-6 mb-6">
            <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-600 rounded-2xl flex items-center justify-center shadow-lg">
                    <Users className="text-white" size={24} />
                </div>
                <div>
                    <h2 className="text-2xl font-black text-[var(--color-text-main)] tracking-tight">
                        AI Study Buddy
                    </h2>
                    <p className="text-sm text-[var(--color-text-secondary)] font-medium">
                        Autonomous study group formation powered by AI
                    </p>
                </div>
            </div>

            <div className="bg-[var(--color-surface)] border border-[var(--color-border)] rounded-2xl p-4 mb-4">
                <div className="flex items-start gap-3">
                    <Sparkles className="text-purple-500 mt-1" size={20} />
                    <div className="flex-1">
                        <p className="text-sm text-[var(--color-text-secondary)] leading-relaxed">
                            I analyze your posts to detect study needs, find compatible study partners using AI,
                            and automatically suggest optimal study groups with meeting times and locations.
                        </p>
                    </div>
                </div>
            </div>

            <button
                onClick={handleFindStudyPartners}
                disabled={loading}
                className="w-full bg-gradient-to-r from-purple-600 to-pink-600 text-white py-3 rounded-2xl font-bold shadow-lg hover:shadow-xl hover:scale-[1.02] active:scale-[0.98] transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 mb-4"
            >
                {loading ? (
                    <>
                        <div className="animate-spin rounded-full h-5 w-5 border-2 border-white border-t-transparent"></div>
                        Finding Partners...
                    </>
                ) : (
                    <>
                        <BookOpen size={20} />
                        Find Study Partners
                    </>
                )}
            </button>

            {suggestions.length > 0 && (
                <div className="space-y-3">
                    <div className="flex items-center gap-2">
                        <div className="h-px flex-1 bg-gradient-to-r from-transparent via-[var(--color-border)] to-transparent"></div>
                        <span className="text-xs font-bold text-[var(--color-text-muted)] uppercase tracking-widest">
                            AI Suggestions
                        </span>
                        <div className="h-px flex-1 bg-gradient-to-r from-transparent via-[var(--color-border)] to-transparent"></div>
                    </div>

                    {suggestions.map((suggestion) => (
                        <div key={suggestion.id} className="bg-[var(--color-surface)] border border-[var(--color-border)] rounded-2xl p-4">
                            <div className="flex items-center gap-2 mb-3">
                                <BookOpen className="text-purple-500" size={18} />
                                <h3 className="font-bold text-[var(--color-text-main)]">{suggestion.subject}</h3>
                                <span className="ml-auto text-xs bg-purple-500/10 text-purple-600 dark:text-purple-400 px-2 py-1 rounded-full font-bold">
                                    {suggestion.members.length} matches
                                </span>
                            </div>

                            <div className="space-y-2 mb-3">
                                {suggestion.members.slice(0, 3).map((member) => (
                                    <div key={member.userId} className="flex items-center gap-3 p-2 bg-[var(--color-bg)] rounded-xl">
                                        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-purple-400 to-pink-400 flex items-center justify-center text-white font-bold text-sm">
                                            {member.userName.charAt(0)}
                                        </div>
                                        <div className="flex-1">
                                            <p className="text-sm font-medium text-[var(--color-text-main)]">{member.userName}</p>
                                            <p className="text-xs text-[var(--color-text-muted)]">{member.reason}</p>
                                        </div>
                                        <div className="flex items-center gap-1">
                                            <TrendingUp size={14} className="text-green-500" />
                                            <span className="text-xs font-bold text-green-600 dark:text-green-400">{member.matchScore}%</span>
                                        </div>
                                    </div>
                                ))}
                            </div>

                            <div className="bg-gradient-to-r from-purple-500/10 to-pink-500/10 border border-purple-500/20 rounded-xl p-3">
                                <p className="text-xs font-bold text-purple-700 dark:text-purple-300 mb-1">📅 Suggested Meeting</p>
                                <p className="text-sm text-[var(--color-text-main)]">
                                    <span className="font-bold">{suggestion.suggestedTime}</span> at <span className="font-bold">{suggestion.suggestedLocation}</span>
                                </p>
                            </div>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
};

export default StudyBuddy;
