import React, { useState } from 'react';
import { Sparkles, Send, Loader2 } from 'lucide-react';
import { auth } from '../../lib/firebase';
import { agentService } from '../../services/agent.service';
import { useToast } from '../../context/ToastContext';
import MissionTracker from './MissionTracker';
import type { AgentResponse } from '../../types/agent.types';

const CampusConcierge: React.FC = () => {
    const [userInput, setUserInput] = useState('');
    const [isProcessing, setIsProcessing] = useState(false);
    const [response, setResponse] = useState<AgentResponse | null>(null);
    const { showToast } = useToast();

    const exampleRequest = "Hey, I'm heading to the Fest at 7. I need a ride from Block B and I'll need my QR pass ready. Also, check if my project group has posted any new notes for our 9 PM meeting.";

    const handleActivate = async () => {
        const currentUser = auth.currentUser;
        if (!currentUser) {
            showToast('Please login to use the concierge', 'error');
            return;
        }

        const input = userInput.trim() || exampleRequest;
        setIsProcessing(true);
        setResponse(null);

        try {
            const result = await agentService.executeConciergeRequest(currentUser.uid, input);
            setResponse(result);
            showToast('Concierge missions completed!', 'success');
        } catch (error: any) {
            console.error('Concierge error:', error);
            showToast('Failed to execute concierge request: ' + error.message, 'error');
        } finally {
            setIsProcessing(false);
        }
    };

    return (
        <div className="bg-gradient-to-br from-indigo-500/10 via-purple-500/10 to-pink-500/10 border-2 border-indigo-500/20 rounded-3xl p-6 mb-6 relative overflow-hidden">
            {/* Animated background */}
            <div className="absolute inset-0 bg-gradient-to-r from-indigo-500/5 to-purple-500/5 animate-pulse"></div>

            <div className="relative z-10">
                {/* Header */}
                <div className="flex items-center gap-3 mb-4">
                    <div className="w-12 h-12 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-2xl flex items-center justify-center shadow-lg">
                        <Sparkles className="text-white" size={24} />
                    </div>
                    <div>
                        <h2 className="text-2xl font-black text-[var(--color-text-main)] tracking-tight">
                            Campus Concierge
                        </h2>
                        <p className="text-sm text-[var(--color-text-secondary)] font-medium">
                            Your AI-powered campus logistics assistant
                        </p>
                    </div>
                </div>

                {/* Description */}
                <div className="bg-[var(--color-surface)] border border-[var(--color-border)] rounded-2xl p-4 mb-4">
                    <p className="text-sm text-[var(--color-text-secondary)] leading-relaxed">
                        <span className="font-bold text-[var(--color-primary)]">Zero-Click Logistics:</span> Tell me what you need in one sentence, and I'll autonomously handle your rides, event passes, and project updates.
                    </p>
                </div>

                {/* Input Area */}
                <div className="space-y-3 mb-4">
                    <textarea
                        className="w-full bg-[var(--color-bg)] border border-[var(--color-border)] rounded-2xl px-4 py-3 text-[var(--color-text-main)] placeholder:text-[var(--color-text-muted)] focus:ring-2 ring-indigo-500 outline-none transition-all resize-none"
                        placeholder={exampleRequest}
                        value={userInput}
                        onChange={(e) => setUserInput(e.target.value)}
                        rows={3}
                        disabled={isProcessing}
                    />

                    <button
                        onClick={handleActivate}
                        disabled={isProcessing}
                        className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 text-white py-4 rounded-2xl font-black text-lg shadow-xl hover:shadow-2xl hover:scale-[1.02] active:scale-[0.98] transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                    >
                        {isProcessing ? (
                            <>
                                <Loader2 className="animate-spin" size={20} />
                                Processing Missions...
                            </>
                        ) : (
                            <>
                                <Send size={20} />
                                Activate Concierge
                            </>
                        )}
                    </button>
                </div>

                {/* Mission Tracker */}
                {response && (
                    <div className="space-y-4">
                        <div className="flex items-center gap-2">
                            <div className="h-px flex-1 bg-gradient-to-r from-transparent via-[var(--color-border)] to-transparent"></div>
                            <span className="text-xs font-bold text-[var(--color-text-muted)] uppercase tracking-widest">
                                Agent Activity
                            </span>
                            <div className="h-px flex-1 bg-gradient-to-r from-transparent via-[var(--color-border)] to-transparent"></div>
                        </div>

                        <MissionTracker missions={response.missions} />

                        {/* Summary */}
                        {response.summary && (
                            <div className="bg-gradient-to-br from-green-500/10 to-emerald-500/10 border-2 border-green-500/20 rounded-2xl p-4">
                                <h3 className="text-sm font-black text-green-700 dark:text-green-400 uppercase tracking-wider mb-2">
                                    ✓ Mission Complete
                                </h3>
                                <div className="text-sm text-[var(--color-text-main)] whitespace-pre-line leading-relaxed">
                                    {response.summary}
                                </div>
                            </div>
                        )}
                    </div>
                )}

                {/* Example Hint */}
                {!response && !isProcessing && (
                    <div className="mt-4 p-3 bg-indigo-500/5 border border-indigo-500/10 rounded-xl">
                        <p className="text-xs text-[var(--color-text-muted)] italic">
                            💡 Tip: Leave the field empty to try the example scenario, or type your own request!
                        </p>
                    </div>
                )}
            </div>
        </div>
    );
};

export default CampusConcierge;
