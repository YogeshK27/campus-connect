import React, { useState, useEffect } from 'react';
import { Sparkles, Lightbulb, TrendingUp, ArrowRight } from 'lucide-react';
import { auth } from '../../lib/firebase';
import { proactiveAssistantService, type ProactiveSuggestion } from '../../services/agentic/proactive-assistant.service';
import { useNavigate } from 'react-router-dom';

const ProactiveAssistant: React.FC = () => {
    const [suggestions, setSuggestions] = useState<ProactiveSuggestion[]>([]);
    const [loading, setLoading] = useState(true);
    const navigate = useNavigate();

    useEffect(() => {
        loadSuggestions();
    }, []);

    const loadSuggestions = async () => {
        const currentUser = auth.currentUser;
        if (!currentUser) {
            setLoading(false);
            return;
        }

        setLoading(true);
        try {
            const sug = await proactiveAssistantService.generateSuggestions(currentUser.uid);
            setSuggestions(sug);
        } catch (error) {
            console.error('Error loading suggestions:', error);
        } finally {
            setLoading(false);
        }
    };

    const handleAction = (action: any) => {
        if (action.type === 'navigate' && action.data) {
            navigate(action.data);
        } else {
            // Dismiss suggestion
            setSuggestions(prev => prev.slice(1));
        }
    };

    const getCategoryColor = (category: string) => {
        switch (category) {
            case 'deadline': return 'from-red-500/10 to-orange-500/10 border-red-500/20';
            case 'conflict': return 'from-yellow-500/10 to-orange-500/10 border-yellow-500/20';
            case 'opportunity': return 'from-green-500/10 to-teal-500/10 border-green-500/20';
            default: return 'from-blue-500/10 to-cyan-500/10 border-blue-500/20';
        }
    };

    if (loading) {
        return (
            <div className="bg-gradient-to-br from-green-500/10 via-teal-500/10 to-cyan-500/10 border-2 border-green-500/20 rounded-3xl p-6 mb-6">
                <div className="flex items-center justify-center gap-3 py-4">
                    <div className="animate-spin rounded-full h-6 w-6 border-2 border-green-500 border-t-transparent"></div>
                    <p className="text-sm text-[var(--color-text-secondary)]">Analyzing your activity...</p>
                </div>
            </div>
        );
    }

    if (suggestions.length === 0) {
        return null;
    }

    return (
        <div className="bg-gradient-to-br from-green-500/10 via-teal-500/10 to-cyan-500/10 border-2 border-green-500/20 rounded-3xl p-6 mb-6">
            <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-teal-600 rounded-2xl flex items-center justify-center shadow-lg">
                    <Lightbulb className="text-white" size={24} />
                </div>
                <div>
                    <h2 className="text-2xl font-black text-[var(--color-text-main)] tracking-tight">
                        Proactive Assistant
                    </h2>
                    <p className="text-sm text-[var(--color-text-secondary)] font-medium">
                        AI predicts your needs before you ask
                    </p>
                </div>
            </div>

            <div className="bg-[var(--color-surface)] border border-[var(--color-border)] rounded-2xl p-4 mb-4">
                <div className="flex items-start gap-3">
                    <Sparkles className="text-green-500 mt-1" size={20} />
                    <div className="flex-1">
                        <p className="text-sm text-[var(--color-text-secondary)] leading-relaxed">
                            I analyze your activity patterns and proactively suggest helpful actions based on context.
                        </p>
                    </div>
                </div>
            </div>

            <div className="space-y-3">
                {suggestions.map((suggestion) => (
                    <div key={suggestion.id} className={`bg-gradient-to-r ${getCategoryColor(suggestion.category)} border rounded-2xl p-4`}>
                        <div className="flex items-start gap-3 mb-3">
                            <span className="text-2xl">{suggestion.icon}</span>
                            <div className="flex-1">
                                <p className="text-sm font-bold text-[var(--color-text-main)] mb-1">{suggestion.suggestion}</p>
                                <p className="text-xs text-[var(--color-text-muted)]">{suggestion.trigger}</p>
                            </div>
                            <div className="flex items-center gap-1">
                                <TrendingUp size={14} className="text-green-500" />
                                <span className="text-xs font-bold text-green-600 dark:text-green-400">{suggestion.priority}%</span>
                            </div>
                        </div>

                        <div className="flex gap-2">
                            {suggestion.actions.map((action, idx) => (
                                <button
                                    key={idx}
                                    onClick={() => handleAction(action)}
                                    className={`flex-1 py-2 px-4 rounded-xl font-bold text-sm transition-all ${idx === 0
                                            ? 'bg-gradient-to-r from-green-600 to-teal-600 text-white shadow-lg hover:shadow-xl hover:scale-[1.02]'
                                            : 'bg-[var(--color-surface)] border border-[var(--color-border)] text-[var(--color-text-secondary)] hover:border-green-500/30'
                                        } flex items-center justify-center gap-2`}
                                >
                                    {action.label}
                                    {idx === 0 && <ArrowRight size={16} />}
                                </button>
                            ))}
                        </div>
                    </div>
                ))}
            </div>

            <button
                onClick={loadSuggestions}
                className="w-full mt-4 bg-gradient-to-r from-green-600 to-teal-600 text-white py-3 rounded-2xl font-bold shadow-lg hover:shadow-xl hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center justify-center gap-2"
            >
                <Sparkles size={20} />
                Refresh Suggestions
            </button>
        </div>
    );
};

export default ProactiveAssistant;
