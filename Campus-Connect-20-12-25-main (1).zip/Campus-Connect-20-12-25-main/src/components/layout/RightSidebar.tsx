import React, { useEffect, useState } from 'react';
import { db, auth } from '../../lib/firebase';
import { collection, query, orderBy, onSnapshot, where } from 'firebase/firestore';
import { onAuthStateChanged } from 'firebase/auth';

const RightSidebar: React.FC = () => {
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [trendingPosts, setTrendingPosts] = useState<any[]>([]);
  const [activeRides, setActiveRides] = useState<any[]>([]);
  const [upcomingEvents, setUpcomingEvents] = useState<any[]>([]);

  useEffect(() => {
    const unsubAuth = onAuthStateChanged(auth, (user) => {
      setCurrentUser(user);
    });
    return () => unsubAuth();
  }, []);

  useEffect(() => {
    // Trending Posts (Latest 3)
    const qPosts = query(collection(db, 'posts'), orderBy('createdAt', 'desc'));
    const unsubPosts = onSnapshot(qPosts, (snap) => {
      const posts = snap.docs.map(d => ({ id: d.id, ...d.data() }));
      setTrendingPosts(posts.slice(0, 3));
    });

    // Active Rides
    // We want the user to see rides they are part of first, then other open/ongoing rides for today/future
    const qRides = query(
      collection(db, 'rides'),
      where('status', 'in', ['open', 'ongoing']),
      orderBy('createdAt', 'desc')
    );

    const unsubRides = onSnapshot(qRides, (snapshot) => {
      const todayStr = new Date().toISOString().split('T')[0];
      const allRides = snapshot.docs.map(doc => ({ $id: doc.id, ...doc.data() }));

      // Filter for today or future
      const futureRides = allRides.filter((r: any) => r.date >= todayStr);

      // Separate joined vs not joined
      const joined = futureRides.filter((r: any) => r.participants?.includes(currentUser?.uid));
      const notJoined = futureRides.filter((r: any) => !r.participants?.includes(currentUser?.uid));

      // Sort: Joined first, then the rest
      setActiveRides([...joined, ...notJoined].slice(0, 5)); // Show up to 5
    });

    // Upcoming Events
    const qEvents = query(collection(db, 'events'), orderBy('date', 'asc'));
    const unsubEvents = onSnapshot(qEvents, (snapshot) => {
      const todayStr = new Date().toISOString().split('T')[0];
      const items = snapshot.docs
        .map(doc => ({ $id: doc.id, ...doc.data() }))
        .filter((e: any) => e.date >= todayStr);
      setUpcomingEvents(items.slice(0, 3));
    });

    return () => {
      unsubPosts();
      unsubRides();
      unsubEvents();
    };
  }, [currentUser]); // Added currentUser to dependency array

  return (
    <aside className="right-sidebar">
      <div className="sidebar-section">
        <h3>Trending Posts</h3>
        {trendingPosts.length > 0 ? (
          <div className="flex flex-col gap-3">
            {trendingPosts.map(post => (
              <div key={post.id} className="text-sm border-b border-[var(--color-border)] pb-2">
                <div className="font-semibold">{post.authorName}</div>
                <div className="text-[var(--color-text-secondary)] truncate">{post.content || post.title}</div>
              </div>
            ))}
          </div>
        ) : <div className="empty-state">No trending posts.</div>}
      </div>

      <div className="sidebar-section">
        <h3>Active Rides Today</h3>
        {activeRides.length > 0 ? (
          <div className="flex flex-col gap-3">
            {activeRides.map(ride => (
              <div key={ride.id} className="text-sm border-b border-[var(--color-border)] pb-2">
                <div className="font-semibold">{ride.from} ➔ {ride.to}</div>
                <div className="text-[var(--color-text-secondary)] text-xs">
                  {ride.time} | ₹{ride.fare} | {ride.availableSeats} seats
                </div>
              </div>
            ))}
          </div>
        ) : <div className="empty-state">No active rides.</div>}
      </div>

      <div className="sidebar-section">
        <h3>Upcoming Events</h3>
        {upcomingEvents.length > 0 ? (
          <div className="flex flex-col gap-3">
            {upcomingEvents.map(event => (
              <div key={event.id} className="text-sm border-b border-[var(--color-border)] pb-2">
                <div className="font-semibold">{event.title}</div>
                <div className="text-[var(--color-text-secondary)] text-xs">
                  {event.date} @ {event.location}
                </div>
              </div>
            ))}
          </div>
        ) : <div className="empty-state">No upcoming events.</div>}
      </div>

      <style>{`
        .sidebar-section {
          background: var(--color-surface);
          border: 1px solid var(--color-border);
          border-radius: var(--radius-lg);
          padding: 1.25rem;
          margin-bottom: 1.5rem;
          box-shadow: var(--shadow-sm);
          transition: border-color 0.2s;
        }

        .sidebar-section:hover {
          border-color: var(--color-primary);
        }

        .sidebar-section h3 {
          font-size: 0.7rem;
          color: var(--color-text-muted);
          text-transform: uppercase;
          letter-spacing: 0.1em;
          margin-bottom: 1rem;
          font-weight: 800;
          padding-bottom: 0.5rem;
          border-bottom: 1px solid var(--color-border);
          display: flex;
          align-items: center;
          gap: 0.5rem;
        }

        .empty-state {
          color: var(--color-text-muted);
          font-size: 0.8rem;
          font-style: italic;
          text-align: center;
          padding: 0.5rem 0;
        }
      `}</style>
    </aside>
  );
};

export default RightSidebar;
