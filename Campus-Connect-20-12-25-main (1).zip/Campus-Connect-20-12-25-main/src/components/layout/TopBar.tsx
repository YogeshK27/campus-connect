import React, { useState, useRef, useEffect } from 'react';
import { Search, Plus, MessageSquare, Bell, Settings, LogOut, Sun, Moon, User, Menu } from 'lucide-react';
import { useNavigate, Link } from 'react-router-dom';
import { auth, db } from '../../lib/firebase';
import { onAuthStateChanged } from 'firebase/auth';
import { doc, onSnapshot } from 'firebase/firestore';
import { useTheme } from '../../context/ThemeContext';

interface TopBarProps {
  onCreateClick?: () => void;
  onMenuToggle?: () => void;
}

import campusLogo from '../../assets/campus_connect_icon.png';

const TopBar: React.FC<TopBarProps> = ({ onCreateClick, onMenuToggle }) => {
  const { theme, toggleTheme } = useTheme();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [userData, setUserData] = useState<any>(null);
  const menuRef = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setIsMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);

    let unsubProfile: (() => void) | undefined;

    const unsubAuth = onAuthStateChanged(auth, (user) => {
      if (user) {
        const userDocRef = doc(db, 'users', user.uid);
        unsubProfile = onSnapshot(userDocRef, (snapshot) => {
          if (snapshot.exists()) {
            setUserData(snapshot.data());
          }
        });
      } else {
        setUserData(null);
      }
    });

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      unsubAuth();
      if (unsubProfile) unsubProfile();
    };
  }, []);

  const handleLogout = async () => {
    try {
      await auth.signOut();
      navigate('/login');
    } catch (error) {
      console.error('Logout failed', error);
      navigate('/login');
    }
  };

  const handleSettings = () => {
    navigate('/profile');
    setIsMenuOpen(false);
  };

  return (
    <header className="top-bar">
      <div className="brand">
        <button className="mobile-menu-btn" onClick={onMenuToggle}>
          <Menu size={24} />
        </button>
        <Link to="/" className="flex items-center gap-3 group">
          <img src={campusLogo} className="w-9 h-9 group-hover:scale-110 transition-transform" alt="Logo" />
          <span className="app-name font-black italic tracking-tighter text-indigo-600">CAMPUS CONNECT</span>
        </Link>
      </div>

      <div className="search-container">
        <div className="search-bar">
          <Search size={18} className="search-icon" />
          <input type="text" placeholder="Search..." />
        </div>
      </div>

      <div className="actions">
        <button className="create-btn" onClick={onCreateClick}>
          <Plus size={20} />
          <span>Create</span>
        </button>

        <div className="icon-group">
          <button className="icon-btn" onClick={toggleTheme} title="Toggle Theme">
            {theme === 'dark' ? <Sun size={20} /> : <Moon size={20} />}
          </button>
          <button className="icon-btn">
            <MessageSquare size={20} />
          </button>
          <button className="icon-btn relative">
            <Bell size={20} />
            <span className="notification-dot" />
          </button>
        </div>

        <div className="profile-section" ref={menuRef}>
          <div className="profile-icon-container" onClick={() => setIsMenuOpen(!isMenuOpen)}>
            {userData?.profilePhotoUrl ? (
              <img src={userData.profilePhotoUrl} alt="Profile" className="profile-img-small" />
            ) : userData?.name ? (
              <div className="profile-initial-small">{userData.name.charAt(0).toUpperCase()}</div>
            ) : (
              <User size={20} className="text-[var(--color-text-secondary)]" />
            )}
          </div>

          {isMenuOpen && (
            <div className="dropdown-menu">
              <button className="menu-item" onClick={handleSettings}>
                <Settings size={16} />
                <span>Settings</span>
              </button>
              <div className="divider"></div>
              <button className="menu-item logout" onClick={handleLogout}>
                <LogOut size={16} />
                <span>Logout</span>
              </button>
            </div>
          )}
        </div>
      </div>

      <style>{`
        .top-bar {
          display: flex;
          align-items: center;
          justify-content: space-between;
          height: var(--header-height);
          padding: 0 1.5rem;
          background: var(--color-header-bg);
          backdrop-filter: blur(20px);
          border-bottom: 1px solid var(--color-border);
          position: sticky;
          top: 0;
          z-index: 50;
          box-shadow: var(--shadow-sm);
        }

        .brand {
          display: flex;
          align-items: center;
          gap: 1rem;
          font-weight: 900;
          font-size: 1.5rem;
          color: var(--color-primary);
          min-width: 200px;
        }

        .mobile-menu-btn {
          display: none;
          color: var(--color-text-main);
          padding: 0.5rem;
          margin-left: -0.5rem;
        }

        @media (max-width: 768px) {
          .mobile-menu-btn {
            display: flex;
            align-items: center;
            justify-content: center;
          }
          .search-container {
            display: none !important;
          }
        }

        .app-name {
          color: inherit;
          text-decoration: none;
          white-space: nowrap;
        }

        .logo-img {
          width: 32px;
          height: 32px;
          object-fit: contain;
        }

        .search-container {
            flex: 1;
            display: flex;
            justify-content: center;
        }

        .search-bar {
          position: relative;
          width: 100%;
          max-width: 400px;
        }

        .search-bar input {
          width: 100%;
          background: var(--color-surface);
          border: 1px solid var(--color-border);
          border-radius: var(--radius-full);
          padding: 0.5rem 1rem 0.5rem 2.5rem;
          color: var(--color-text-main);
          font-size: 0.875rem;
          transition: all 0.2s;
        }

        .search-bar input:focus {
          border-color: var(--color-primary);
          background: var(--color-bg);
          box-shadow: 0 0 0 2px rgba(109, 40, 217, 0.1);
          width: 100%;
        }

        .search-icon {
          position: absolute;
          left: 0.75rem;
          top: 50%;
          transform: translateY(-50%);
          color: var(--color-text-muted);
        }

        .actions {
          display: flex;
          align-items: center;
          gap: 1.5rem;
          min-width: 200px;
          justify-content: flex-end;
        }

        .create-btn {
          display: flex;
          align-items: center;
          gap: 0.5rem;
          background: linear-gradient(135deg, var(--color-primary), var(--color-primary-hover));
          color: white;
          padding: 0.5rem 1.25rem;
          border-radius: var(--radius-full);
          font-weight: 600;
          font-size: 0.875rem;
          box-shadow: 0 2px 10px rgba(109, 40, 217, 0.2);
          transition: transform 0.2s, box-shadow 0.2s;
        }

        .create-btn:hover {
          transform: translateY(-1px);
          box-shadow: 0 4px 12px rgba(109, 40, 217, 0.3);
        }

        .icon-group {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            padding-right: 1rem;
            border-right: 1px solid var(--color-border);
        }

        .icon-btn {
          color: var(--color-text-secondary);
          padding: 0.5rem;
          border-radius: 50%;
          transition: all 0.2s;
          position: relative;
        }

        .icon-btn:hover {
          background-color: var(--color-surface-hover);
          color: var(--color-text-main);
        }

        .notification-dot {
            position: absolute;
            top: 6px;
            right: 6px;
            width: 8px;
            height: 8px;
            background: #ef4444;
            border-radius: 50%;
            border: 2px solid var(--color-bg);
        }

        .profile-section {
          position: relative;
          cursor: pointer;
        }

        .profile-icon-container {
          width: 36px;
          height: 36px;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          background: var(--color-surface-hover);
          border: 2px solid transparent;
          transition: all 0.2s;
          overflow: hidden;
        }

        .profile-img-small {
          width: 100%;
          height: 100%;
          object-fit: cover;
        }

        .profile-initial-small {
          width: 100%;
          height: 100%;
          display: flex;
          align-items: center;
          justify-content: center;
          background: var(--color-primary);
          color: white;
          font-weight: 700;
          font-size: 0.875rem;
        }

        .profile-section:hover .profile-icon-container {
            border-color: var(--color-primary);
            background: var(--color-bg);
        }

        .dropdown-menu {
            position: absolute;
            top: 100%;
            right: 0;
            margin-top: 0.75rem;
            width: 180px;
            background: var(--color-surface);
            border: 1px solid var(--color-border);
            border-radius: var(--radius-lg);
            padding: 0.5rem;
            box-shadow: 0 4px 20px rgba(0,0,0,0.2);
            animation: slideIn 0.2s ease-out;
            display: flex;
            flex-direction: column;
            gap: 0.25rem;
        }

        @keyframes slideIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .menu-item {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            width: 100%;
            padding: 0.5rem 0.75rem;
            border-radius: var(--radius-md);
            color: var(--color-text-main);
            transition: background 0.2s;
            text-align: left;
            background: transparent;
            border: none;
            cursor: pointer;
            font-size: 0.9rem;
        }

        .menu-item:hover {
            background: var(--color-surface-hover);
        }

        .menu-item.logout {
            color: #ef4444;
        }

        .menu-item.logout:hover {
            background: rgba(239, 68, 68, 0.1);
        }

        .divider {
            height: 1px;
            background: var(--color-border);
            margin: 0.25rem 0;
        }

        /* Google Cloud Animation */
        @keyframes float {
            0% { transform: translateY(0px); }
            50% { transform: translateY(-20px); }
            100% { transform: translateY(0px); }
        }

        .animate-float {
            animation: float 6s ease-in-out infinite;
        }

        .animate-float-delayed {
            animation: float 8s ease-in-out infinite;
            animation-delay: 2s;
        }
      `}</style>
    </header>
  );
};

export default TopBar;
