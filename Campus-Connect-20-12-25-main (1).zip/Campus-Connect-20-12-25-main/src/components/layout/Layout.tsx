import React, { useState, useEffect } from 'react';
import { Outlet } from 'react-router-dom';
import TopBar from './TopBar';
import LeftSidebar from './LeftSidebar';
import RightSidebar from './RightSidebar';
import CreateModal from '../common/CreateModal';
import { auth } from '../../lib/firebase';
import { onAuthStateChanged } from 'firebase/auth';
import { dbService } from '../../services/db.service';

interface LayoutProps {
  children?: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  // Self-Healing & Session Logging (v2 Firestore)
  useEffect(() => {
    const syncUserDoc = async (user: any) => {
      if (!user) return;
      try {
        const userData = await dbService.getUser(user.uid);

        if (!userData) {
          console.log("Initializing v2 user profile in Firestore...");
          await dbService.createUser(user.uid, {
            email: user.email,
            name: user.displayName || 'Campus User',
            profilePhotoUrl: user.photoURL || '',
            college: 'Woxsen University' // Default for v2
          });
        } else {
          // Update last login in Firestore
          await dbService.updateUser(user.uid, {});
        }
      } catch (err) {
        console.error("Error syncing v2 profile (Firestore):", err);
      }
    };

    const unsubscribe = onAuthStateChanged(auth, (user) => {
      if (user) syncUserDoc(user);
    });
    return () => unsubscribe();
  }, []);

  return (
    <div className={`layout ${isSidebarOpen ? 'sidebar-open' : ''}`}>
      <TopBar
        onCreateClick={() => setIsCreateModalOpen(true)}
        onMenuToggle={() => setIsSidebarOpen(!isSidebarOpen)}
      />

      <div className="main-container">
        <div className={`sidebar-overlay ${isSidebarOpen ? 'active' : ''}`} onClick={() => setIsSidebarOpen(false)} />

        <div className={`left-sidebar-container ${isSidebarOpen ? 'active' : ''}`}>
          <LeftSidebar />
        </div>

        <main className="content-area">
          {children ? children : <Outlet />}
        </main>

        <div className="right-sidebar">
          <RightSidebar />
        </div>
      </div>

      <CreateModal isOpen={isCreateModalOpen} onClose={() => setIsCreateModalOpen(false)} />

      <style>{`
        .layout {
          display: flex;
          flex-direction: column;
          height: 100vh;
          background: var(--color-bg);
          color: var(--color-text-main);
          transition: background 0.3s, color 0.3s;
          overflow-x: hidden;
        }
        
        .main-container {
          display: flex;
          flex: 1;
          overflow: hidden;
          background: var(--color-bg);
          max-width: 100vw;
        }

        .left-sidebar-container {
          width: 240px;
          border-right: 1px solid var(--color-border);
          background: var(--color-bg);
          position: sticky;
          top: var(--header-height);
          height: calc(100vh - var(--header-height));
          overflow-y: auto;
          scrollbar-width: thin;
          transition: transform 0.3s ease;
          z-index: 40;
        }

        .sidebar-overlay {
          display: none;
          position: fixed;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: rgba(0, 0, 0, 0.5);
          z-index: 35;
          backdrop-filter: blur(4px);
        }

        .sidebar-overlay.active {
          display: block;
        }

        .content-area {
          flex: 1;
          overflow-y: auto;
          padding: 1rem;
          max-width: 800px;
          margin: 0 auto;
          width: 100%;
        }

        .right-sidebar {
          width: 280px;
          border-left: 1px solid var(--color-border);
          background: var(--color-bg);
          padding: 1rem;
          display: none;
          position: sticky;
          top: var(--header-height);
          height: calc(100vh - var(--header-height));
          overflow-y: auto;
          scrollbar-width: thin;
        }

        @media (max-width: 768px) {
          .left-sidebar-container {
            position: fixed;
            left: 0;
            top: 0;
            height: 100vh;
            width: 260px;
            transform: translateX(-100%);
            box-shadow: 10px 0 30px rgba(0, 0, 0, 0.2);
            z-index: 1000;
          }
          
          .left-sidebar-container.active {
            transform: translateX(0);
          }
        }

        @media (min-width: 769px) {
          .left-sidebar-container {
            display: block;
            transform: none !important;
          }
        }
        
        @media (min-width: 1024px) {
          .right-sidebar {
            display: block;
          }
        }
      `}</style>
    </div>
  );
};

export default Layout;
