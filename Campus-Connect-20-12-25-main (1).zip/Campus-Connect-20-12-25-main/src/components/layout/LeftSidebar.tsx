import React from 'react';
import { NavLink } from 'react-router-dom';
import {
  Home,
  Car,
  Calendar,
  BookOpen,
  HelpCircle,
  Users,
  Briefcase,
  BarChart2,
  Bookmark,
  Info,
  Sparkles
} from 'lucide-react';

const navItems = [
  { name: 'Home', icon: Home, path: '/' },
  { name: 'Ride Sharing', icon: Car, path: '/rides' },
  { name: 'Events', icon: Calendar, path: '/events' },
  { name: 'Notes & Resources', icon: BookOpen, path: '/notes' },
  { name: 'Lost & Found', icon: HelpCircle, path: '/lost-found' },
  { name: 'Clubs', icon: Users, path: '/clubs' },
  { name: 'Internships', icon: Briefcase, path: '/internships' },
  { name: 'Polls', icon: BarChart2, path: '/polls' },
  { name: 'AI Section', icon: Sparkles, path: '/ai' },
  { name: 'Saved', icon: Bookmark, path: '/saved' },
];

const LeftSidebar: React.FC = () => {
  return (
    <aside className="left-sidebar-content">
      <nav className="nav-menu">
        {navItems.map((item) => (
          <NavLink
            key={item.name}
            to={item.path}
            className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}
          >
            <item.icon size={20} />
            <span>{item.name}</span>
          </NavLink>
        ))}
        <div className="divider" />
        <NavLink to="/rules" className="nav-item">
          <Info size={20} />
          <span>Rules</span>
        </NavLink>
      </nav>

      <style>{`
        .left-sidebar-content {
          padding: 1rem;
        }
        .nav-menu {
          display: flex;
          flex-direction: column;
          gap: 0.5rem;
        }

        .nav-item {
          display: flex;
          align-items: center;
          gap: 1rem;
          padding: 0.75rem 1rem;
          border-radius: var(--radius-lg);
          color: var(--color-text-secondary);
          transition: all 0.2s ease;
          font-weight: 500;
          border: 1px solid transparent;
        }

        .nav-item:hover {
          background-color: var(--color-surface-hover);
          color: var(--color-text-main);
          transform: translateX(2px);
        }

        .nav-item.active {
          background: linear-gradient(90deg, rgba(109, 40, 217, 0.1), transparent);
          color: var(--color-primary);
          border-left: 3px solid var(--color-primary);
          border-radius: 0 var(--radius-lg) var(--radius-lg) 0;
        }

        .divider {
          height: 1px;
          background: linear-gradient(to right, transparent, var(--color-border), transparent);
          margin: 1rem 0;
        }
      `}</style>
    </aside>
  );
};

export default LeftSidebar;
