import React, { useState, useEffect, useRef } from 'react';
import { aiService } from '../../services/aiService';
import { Send, Bot, RefreshCw, Trash2, Sparkles, User } from 'lucide-react';
import { auth } from '../../lib/firebase';
import { onAuthStateChanged } from 'firebase/auth';

interface Message {
    id: string;
    text: string;
    sender: 'ai' | 'user';
    timestamp: Date;
}

const SUGGESTED_PROMPTS = [
    "Explain Quantum Computing to a 5-year-old",
    "Write a Python script to scrape a website",
    "Give me 5 unique date ideas",
    "Debug my React useEffect hook"
];

const Chatbot: React.FC = () => {
    const [messages, setMessages] = useState<Message[]>([
        {
            id: 'init',
            text: "Hello! I'm Campus Connect AI. I can help you with coding, writing, or just brainstorming. What's on your mind?",
            sender: 'ai',
            timestamp: new Date()
        }
    ]);
    const [input, setInput] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [currentUser, setCurrentUser] = useState<any>(null);
    const messagesEndRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const unsub = onAuthStateChanged(auth, u => setCurrentUser(u));
        return () => unsub();
    }, []);

    useEffect(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    }, [messages, isLoading]);

    const handleSend = async (e?: React.FormEvent, overrideText?: string) => {
        e?.preventDefault();
        const textToSend = overrideText || input;

        if (!textToSend.trim() || isLoading) return;

        const userMessage: Message = {
            id: Date.now().toString(),
            text: textToSend,
            sender: 'user',
            timestamp: new Date()
        };

        setMessages(prev => [...prev, userMessage]);
        setInput('');
        setIsLoading(true);

        try {
            // Debug Command Logic
            if (textToSend.trim().toLowerCase() === '/debug') {
                const models = await aiService.getModels();
                const aiMessage: Message = {
                    id: (Date.now() + 1).toString(),
                    text: models,
                    sender: 'ai',
                    timestamp: new Date()
                };
                setMessages(prev => [...prev, aiMessage]);
                return;
            }

            const response = await aiService.chat(textToSend, messages);
            const aiMessage: Message = {
                id: (Date.now() + 1).toString(),
                text: response,
                sender: 'ai',
                timestamp: new Date()
            };
            setMessages(prev => [...prev, aiMessage]);
        } catch (error) {
            console.error('Chat error:', error);
            setMessages(prev => [...prev, {
                id: Date.now().toString(),
                text: `Error: ${error instanceof Error ? error.message : "Unknown error"}. Please try again.`,
                sender: 'ai',
                timestamp: new Date()
            }]);
        } finally {
            setIsLoading(false);
        }
    };

    const clearChat = () => {
        setMessages([{
            id: 'init',
            text: "Chat cleared. Ready for a new topic!",
            sender: 'ai',
            timestamp: new Date()
        }]);
    };

    return (
        <div className="h-[650px] flex flex-col bg-[var(--color-surface)] rounded-3xl border border-[var(--color-border)] shadow-xl overflow-hidden relative">
            {/* Header */}
            <div className="px-6 py-4 border-b border-[var(--color-border)] flex justify-between items-center bg-[var(--color-surface)]/80 backdrop-blur-md sticky top-0 z-10">
                <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-indigo-500 to-purple-600 flex items-center justify-center shadow-lg shadow-indigo-500/20">
                        <Bot size={20} className="text-white" />
                    </div>
                    <div>
                        <h3 className="font-bold text-[var(--color-text-main)]">Campus Connect Assistant</h3>
                        <p className="text-xs text-green-400 font-medium flex items-center gap-1">
                            <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                            Online
                        </p>
                    </div>
                </div>
                <button
                    onClick={clearChat}
                    className="p-2 text-[var(--color-text-muted)] hover:text-red-400 hover:bg-red-500/10 rounded-full transition-all"
                    title="Clear Chat"
                >
                    <Trash2 size={18} />
                </button>
            </div>

            {/* Chat Area */}
            <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-[var(--color-bg)] scroll-smooth">
                {messages.map((msg) => (
                    <div
                        key={msg.id}
                        className={`flex gap-4 ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                    >
                        {msg.sender === 'ai' && (
                            <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-indigo-500 to-purple-600 flex items-center justify-center flex-shrink-0 mt-2 shadow-sm">
                                <Bot size={14} className="text-white" />
                            </div>
                        )}

                        <div className={`max-w-[85%] rounded-2xl px-5 py-3.5 shadow-sm leading-relaxed ${msg.sender === 'user'
                            ? 'bg-indigo-600 text-white rounded-br-sm'
                            : 'bg-[var(--color-surface)] text-[var(--color-text-main)] rounded-bl-sm border border-[var(--color-border)]'
                            }`}>
                            <p className="text-[15px] whitespace-pre-wrap">{msg.text}</p>
                            <span className={`text-[10px] block mt-1.5 opacity-70 font-medium ${msg.sender === 'user' ? 'text-indigo-200' : 'text-[var(--color-text-muted)]'
                                }`}>
                                {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                            </span>
                        </div>

                        {msg.sender === 'user' && (
                            <div className="w-8 h-8 rounded-full bg-[var(--color-surface)] overflow-hidden flex-shrink-0 mt-2 border border-[var(--color-border)] shadow-sm">
                                {currentUser?.photoURL ? (
                                    <img src={currentUser.photoURL} alt="User" className="w-full h-full object-cover" />
                                ) : (
                                    <div className="w-full h-full flex items-center justify-center bg-[var(--color-bg)]">
                                        <User size={14} className="text-[var(--color-text-muted)]" />
                                    </div>
                                )}
                            </div>
                        )}
                    </div>
                ))}

                {isLoading && (
                    <div className="flex gap-4 animate-pulse">
                        <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-indigo-500 to-purple-600 flex items-center justify-center flex-shrink-0 shadow-sm">
                            <Bot size={14} className="text-white" />
                        </div>
                        <div className="bg-[var(--color-surface)] border border-[var(--color-border)] rounded-2xl rounded-bl-sm px-5 py-4 flex items-center gap-1.5 shadow-sm">
                            <span className="w-2 h-2 bg-[var(--color-text-muted)] rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                            <span className="w-2 h-2 bg-[var(--color-text-muted)] rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                            <span className="w-2 h-2 bg-[var(--color-text-muted)] rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                        </div>
                    </div>
                )}
                <div ref={messagesEndRef} />
            </div>

            {/* Input Area */}
            <div className="p-4 bg-[var(--color-surface)] border-t border-[var(--color-border)]">
                {messages.length < 3 && !isLoading && (
                    <div className="flex gap-2 overflow-x-auto pb-4 scrollbar-hide">
                        {SUGGESTED_PROMPTS.map((prompt, i) => (
                            <button
                                key={i}
                                onClick={() => handleSend(undefined, prompt)}
                                className="flex-shrink-0 px-3 py-1.5 bg-[var(--color-bg)] text-indigo-400 text-xs font-medium rounded-full hover:bg-[var(--color-surface-hover)] transition-colors border border-[var(--color-border)]"
                            >
                                {prompt}
                            </button>
                        ))}
                    </div>
                )}

                <form onSubmit={(e) => handleSend(e)} className="relative flex items-center gap-2">
                    <div className="p-2 bg-[var(--color-bg)] rounded-full">
                        <Sparkles size={18} className="text-indigo-500" />
                    </div>
                    <input
                        type="text"
                        value={input}
                        onChange={(e) => setInput(e.target.value)}
                        placeholder="Type your message..."
                        className="flex-1 bg-[var(--color-bg)] border-none outline-none text-[var(--color-text-main)] placeholder-[var(--color-text-muted)] text-sm py-3 px-2 focus:ring-0 rounded-xl"
                        disabled={isLoading}
                    />
                    <button
                        type="submit"
                        disabled={!input.trim() || isLoading}
                        className={`p-2.5 rounded-full transition-all flex items-center justify-center ${!input.trim() || isLoading
                            ? 'bg-[var(--color-bg)] text-[var(--color-text-muted)] cursor-not-allowed'
                            : 'bg-indigo-600 text-white hover:bg-indigo-700 hover:scale-105 active:scale-95 shadow-md shadow-indigo-500/30'
                            }`}
                    >
                        {isLoading ? <RefreshCw className="animate-spin" size={18} /> : <Send size={18} />}
                    </button>
                </form>
                <p className="text-center text-[10px] text-[var(--color-text-muted)] mt-2">
                    Accessing <strong>Gemini v2.5 Flash</strong> via Campus Connect Cloud
                </p>
            </div>
        </div>
    );
};

export default Chatbot;
