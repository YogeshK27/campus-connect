import React, { useState } from 'react';
import { aiService } from '../../services/aiService';
import { Send, Copy, Check, Twitter, Linkedin, Instagram, RefreshCw, ThumbsUp, MessageCircle, Share2, MoreHorizontal } from 'lucide-react';
import { auth } from '../../lib/firebase';

const SmartPostGenerator: React.FC = () => {
    const [topic, setTopic] = useState('');
    const [tone, setTone] = useState('Professional');
    const [platform, setPlatform] = useState('LinkedIn');
    const [generatedPost, setGeneratedPost] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [isCopied, setIsCopied] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const user = auth.currentUser;
    const userName = user?.displayName || 'User Name';
    const userRole = 'Software Engineer @ Woxify'; // Mock title
    const userPhoto = user?.photoURL || `https://ui-avatars.com/api/?name=${userName}&background=random`;

    const handleGenerate = async () => {
        if (!topic.trim()) return;

        setIsLoading(true);
        setGeneratedPost('');
        setError(null);
        try {
            const prompt = `Write a ${platform} post about "${topic}" in a ${tone} tone. Include relevant hashtags and emojis. Keep it optimized for ${platform}'s audience.`;
            const result = await aiService.generatePost(prompt);
            setGeneratedPost(result);
        } catch (error: any) {
            console.error('Error generating post:', error);
            setError(error.message || "Failed to generate post.");
        } finally {
            setIsLoading(false);
        }
    };

    const handleCopy = () => {
        navigator.clipboard.writeText(generatedPost);
        setIsCopied(true);
        setTimeout(() => setIsCopied(false), 2000);
    };

    return (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 max-w-6xl mx-auto">
            {/* Left Column: Controls */}
            <div className="bg-[var(--color-surface)] rounded-2xl shadow-sm p-6 border border-[var(--color-border)] h-fit sticky top-24">
                <div className="mb-8">
                    <div className="flex items-center gap-3 mb-2">
                        <div className="bg-indigo-500/20 p-2.5 rounded-xl">
                            <Send size={24} className="text-indigo-400" />
                        </div>
                        <h2 className="text-2xl font-bold text-[var(--color-text-main)]">Post Generator</h2>
                    </div>
                    <p className="text-[var(--color-text-secondary)]">Draft viral-worthy content in seconds.</p>
                </div>

                <div className="space-y-6">
                    <div>
                        <label className="block text-sm font-semibold text-[var(--color-text-secondary)] mb-2">Topic</label>
                        <textarea
                            value={topic}
                            onChange={(e) => setTopic(e.target.value)}
                            placeholder="What's on your mind? (e.g., Launched a new feature today...)"
                            className="w-full px-4 py-3 rounded-xl border border-[var(--color-border)] focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition-all bg-[var(--color-bg)] text-[var(--color-text-main)] placeholder-gray-500 min-h-[100px] resize-none"
                            onKeyDown={(e) => e.key === 'Enter' && e.ctrlKey && handleGenerate()}
                        />
                        <p className="text-xs text-[var(--color-text-muted)] mt-1 text-right">Ctrl + Enter to generate</p>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                        <div>
                            <label className="block text-sm font-semibold text-[var(--color-text-secondary)] mb-2">Platform</label>
                            <div className="relative">
                                <select
                                    value={platform}
                                    onChange={(e) => setPlatform(e.target.value)}
                                    className="w-full pl-10 pr-4 py-3 rounded-xl border border-[var(--color-border)] focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none bg-[var(--color-bg)] text-[var(--color-text-main)] appearance-none cursor-pointer hover:bg-[var(--color-surface-hover)] transition-all"
                                >
                                    <option>LinkedIn</option>
                                    <option>Twitter</option>
                                    <option>Instagram</option>
                                </select>
                                <div className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--color-text-muted)] pointer-events-none">
                                    {platform === 'Twitter' ? <Twitter size={18} /> :
                                        platform === 'Instagram' ? <Instagram size={18} /> :
                                            <Linkedin size={18} />}
                                </div>
                            </div>
                        </div>

                        <div>
                            <label className="block text-sm font-semibold text-[var(--color-text-secondary)] mb-2">Tone</label>
                            <select
                                value={tone}
                                onChange={(e) => setTone(e.target.value)}
                                className="w-full px-4 py-3 rounded-xl border border-[var(--color-border)] focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none bg-[var(--color-bg)] text-[var(--color-text-main)] appearance-none cursor-pointer hover:bg-[var(--color-surface-hover)] transition-all"
                            >
                                <option>Professional</option>
                                <option>Casual</option>
                                <option>Viral / Hype</option>
                                <option>Storytelling</option>
                            </select>
                        </div>
                    </div>

                    <button
                        onClick={handleGenerate}
                        disabled={isLoading || !topic.trim()}
                        className={`w-full py-4 rounded-xl flex items-center justify-center gap-2 text-white font-bold tracking-wide transition-all transform ${isLoading || !topic.trim()
                                ? 'bg-gray-700 cursor-not-allowed text-gray-400'
                                : 'bg-gradient-to-r from-indigo-600 to-purple-600 hover:scale-[1.02] shadow-lg hover:shadow-indigo-500/30'
                            }`}
                    >
                        {isLoading ? <RefreshCw className="animate-spin" /> : <Send size={20} />}
                        {isLoading ? 'Crafting Magic...' : 'Generate Post'}
                    </button>

                    {error && (
                        <div className="p-4 bg-red-900/20 text-red-400 rounded-xl text-sm border border-red-900/30 flex items-center gap-2">
                            <span className="font-bold">Error:</span> {error}
                        </div>
                    )}
                </div>
            </div>

            {/* Right Column: Preview */}
            <div className="flex flex-col gap-4">
                <div className="flex items-center justify-between">
                    <h3 className="text-lg font-semibold text-[var(--color-text-main)]">Live Preview</h3>
                    {generatedPost && (
                        <button
                            onClick={handleCopy}
                            className="flex items-center gap-2 text-sm text-indigo-400 font-medium hover:bg-indigo-500/10 px-3 py-1.5 rounded-lg transition-colors"
                        >
                            {isCopied ? <Check size={16} /> : <Copy size={16} />}
                            {isCopied ? 'Copied' : 'Copy Text'}
                        </button>
                    )}
                </div>

                {!generatedPost && !isLoading && (
                    <div className="h-64 border-2 border-dashed border-[var(--color-border)] rounded-2xl flex flex-col items-center justify-center text-[var(--color-text-muted)] bg-[var(--color-surface)]">
                        <div className="p-4 bg-[var(--color-bg)] rounded-full shadow-sm mb-3">
                            <Send size={24} className="text-gray-600" />
                        </div>
                        <p>Your generated post will appear here</p>
                    </div>
                )}

                {isLoading && (
                    <div className="h-64 rounded-2xl bg-[var(--color-surface)] border border-[var(--color-border)] shadow-sm p-6 animate-pulse space-y-4">
                        <div className="flex items-center gap-3">
                            <div className="w-12 h-12 bg-[var(--color-border)] rounded-full" />
                            <div className="space-y-2">
                                <div className="w-32 h-4 bg-[var(--color-border)] rounded" />
                                <div className="w-24 h-3 bg-[var(--color-border)] rounded" />
                            </div>
                        </div>
                        <div className="space-y-2 pt-4">
                            <div className="w-full h-4 bg-[var(--color-border)] rounded" />
                            <div className="w-full h-4 bg-[var(--color-border)] rounded" />
                            <div className="w-3/4 h-4 bg-[var(--color-border)] rounded" />
                        </div>
                    </div>
                )}

                {generatedPost && (
                    <div className="bg-[var(--color-surface)] rounded-2xl shadow-md border border-[var(--color-border)] overflow-hidden animate-fadeIn">
                        {/* Mock Header */}
                        <div className="p-4 flex items-center justify-between border-b border-[var(--color-border)]">
                            <div className="flex items-center gap-3">
                                <img src={userPhoto} alt="User" className="w-12 h-12 rounded-full border border-[var(--color-border)] object-cover" />
                                <div>
                                    <h4 className="font-bold text-[var(--color-text-main)]">{userName}</h4>
                                    <p className="text-xs text-[var(--color-text-muted)]">{userRole} • Just now</p>
                                </div>
                            </div>
                            <MoreHorizontal className="text-[var(--color-text-muted)]" />
                        </div>

                        {/* Content */}
                        <div className="p-5">
                            <p className="text-[var(--color-text-main)] whitespace-pre-wrap leading-relaxed">
                                {generatedPost}
                            </p>
                            <p className="mt-4 text-indigo-400 text-sm font-medium">#{platform} #AI</p>
                        </div>

                        {/* Mock Footer */}
                        <div className="bg-[var(--color-bg)] p-3 flex justify-around text-[var(--color-text-muted)] border-t border-[var(--color-border)]">
                            <div className="flex items-center gap-2 cursor-pointer hover:text-indigo-400 transition-colors">
                                <ThumbsUp size={18} /> <span className="text-sm font-medium">Like</span>
                            </div>
                            <div className="flex items-center gap-2 cursor-pointer hover:text-green-400 transition-colors">
                                <MessageCircle size={18} /> <span className="text-sm font-medium">Comment</span>
                            </div>
                            <div className="flex items-center gap-2 cursor-pointer hover:text-indigo-400 transition-colors">
                                <Share2 size={18} /> <span className="text-sm font-medium">Share</span>
                            </div>
                        </div>
                    </div>
                )}
            </div>

            <style>{`
                @keyframes fadeIn {
                    from { opacity: 0; transform: translateY(10px); }
                    to { opacity: 1; transform: translateY(0); }
                }
                .animate-fadeIn {
                    animation: fadeIn 0.4s ease-out forwards;
                }
            `}</style>
        </div>
    );
};

export default SmartPostGenerator;
