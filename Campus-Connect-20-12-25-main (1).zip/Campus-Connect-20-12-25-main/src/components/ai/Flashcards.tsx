import React, { useState } from 'react';
import { aiService, type Flashcard } from '../../services/aiService';
import { RefreshCw, ArrowLeft, ArrowRight, BookOpen, Award } from 'lucide-react';

const Flashcards: React.FC = () => {
    const [topic, setTopic] = useState('');
    const [cards, setCards] = useState<Flashcard[]>([]);
    const [currentIndex, setCurrentIndex] = useState(0);
    const [isFlipped, setIsFlipped] = useState(false);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [completed, setCompleted] = useState(false);

    const handleGenerate = async () => {
        if (!topic.trim()) return;

        setIsLoading(true);
        setError(null);
        setCards([]);
        setCurrentIndex(0);
        setIsFlipped(false);
        setCompleted(false);

        try {
            const result = await aiService.getFlashcards(topic);
            if (result.length === 0) {
                setError("No flashcards generated. Try a different topic.");
            } else {
                setCards(result);
            }
        } catch (error: any) {
            console.error('Error fetching cards:', error);
            setError(error.message || "Failed to generate flashcards.");
        } finally {
            setIsLoading(false);
        }
    };

    const handleNext = () => {
        if (currentIndex < cards.length - 1) {
            setIsFlipped(false);
            setTimeout(() => setCurrentIndex(c => c + 1), 200);
        } else {
            setCompleted(true);
        }
    };

    const handlePrev = () => {
        if (currentIndex > 0) {
            setIsFlipped(false);
            setTimeout(() => setCurrentIndex(c => c - 1), 200);
        }
    };

    const resetDeck = () => {
        setCompleted(false);
        setCurrentIndex(0);
        setIsFlipped(false);
    };

    const progress = cards.length > 0 ? ((currentIndex + 1) / cards.length) * 100 : 0;

    return (
        <div className="max-w-2xl mx-auto">
            {/* Header / Input */}
            <div className={`bg-[var(--color-surface)] rounded-2xl shadow-sm p-6 mb-6 border border-[var(--color-border)] transition-all ${cards.length > 0 ? 'border-indigo-500/30' : ''}`}>
                <div className="flex items-center gap-3 mb-4">
                    <div className="bg-gradient-to-br from-indigo-500 to-purple-500 p-2.5 rounded-xl shadow-md">
                        <BookOpen size={24} className="text-white" />
                    </div>
                    <div>
                        <h2 className="text-xl font-bold text-[var(--color-text-main)]">AI Flashcards</h2>
                        <p className="text-sm text-[var(--color-text-secondary)]">Master any topic with {cards.length > 0 ? `${cards.length} Generated Cards` : 'AI-generated cards'}</p>
                    </div>
                </div>

                <div className="flex gap-2">
                    <input
                        type="text"
                        value={topic}
                        onChange={(e) => setTopic(e.target.value)}
                        placeholder="Enter a subject (e.g. React Hooks, History of Rome)..."
                        className="flex-1 px-4 py-3 border border-[var(--color-border)] rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition-all bg-[var(--color-bg)] text-[var(--color-text-main)] shadow-sm placeholder-gray-500"
                        onKeyDown={(e) => e.key === 'Enter' && handleGenerate()}
                    />
                    <button
                        onClick={handleGenerate}
                        disabled={isLoading || !topic.trim()}
                        className="px-6 py-3 bg-[var(--color-surface-hover)] border border-[var(--color-border)] text-white font-medium rounded-xl hover:bg-[var(--color-border)] disabled:opacity-50 disabled:cursor-not-allowed transition-all flex items-center gap-2 shadow-lg active:scale-95"
                    >
                        {isLoading ? <RefreshCw className="animate-spin" size={20} /> : 'Start'}
                    </button>
                </div>

                {error && (
                    <div className="mt-4 p-4 bg-red-900/20 text-red-400 rounded-xl text-sm border border-red-900/30 flex items-center gap-2 animate-fadeIn">
                        <span className="font-semibold">Error:</span> {error}
                    </div>
                )}
            </div>

            {/* Deck Area */}
            {cards.length > 0 && !completed && (
                <div className="animate-fadeIn">
                    {/* Progress Bar */}
                    <div className="mb-4 flex items-center gap-3">
                        <div className="flex-1 h-2 bg-[var(--color-border)] rounded-full overflow-hidden">
                            <div
                                className="h-full bg-gradient-to-r from-indigo-500 to-purple-500 transition-all duration-500 ease-out"
                                style={{ width: `${progress}%` }}
                            />
                        </div>
                        <span className="text-xs font-bold text-[var(--color-text-muted)]">{currentIndex + 1} / {cards.length}</span>
                    </div>

                    <div className="relative perspective-1000 h-[360px]">
                        <div
                            className={`w-full h-full relative preserve-3d transition-transform duration-500 cursor-pointer ${isFlipped ? 'rotate-y-180' : ''
                                }`}
                            onClick={() => setIsFlipped(!isFlipped)}
                        >
                            {/* Front */}
                            <div className="absolute inset-0 backface-hidden bg-[var(--color-surface)] rounded-3xl shadow-xl border border-[var(--color-border)] flex flex-col items-center justify-center p-8 text-center hover:border-indigo-500/50 transition-all group">
                                <span className="absolute top-6 left-6 text-xs font-bold tracking-wider text-indigo-400 bg-indigo-500/10 px-3 py-1 rounded-full uppercase">
                                    Question
                                </span>
                                <div className="w-16 h-16 bg-[var(--color-bg)] rounded-full flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                                    <span className="text-2xl">🤔</span>
                                </div>
                                <h3 className="text-2xl font-semibold text-[var(--color-text-main)] leading-snug max-w-lg">
                                    {cards[currentIndex].question}
                                </h3>
                                <p className="absolute bottom-8 text-[var(--color-text-muted)] text-xs font-medium tracking-wide uppercase group-hover:text-indigo-400 transition-colors">Tap to flip</p>
                            </div>

                            {/* Back */}
                            <div className="absolute inset-0 backface-hidden bg-gradient-to-br from-indigo-900 to-purple-900 rotate-y-180 rounded-3xl shadow-xl border border-indigo-500/30 flex flex-col items-center justify-center p-8 text-center text-white">
                                <span className="absolute top-6 left-6 text-xs font-bold tracking-wider text-white/80 bg-white/10 px-3 py-1 rounded-full uppercase backdrop-blur-sm">
                                    Answer
                                </span>
                                <div className="w-16 h-16 bg-white/10 rounded-full flex items-center justify-center mb-6 backdrop-blur-sm">
                                    <span className="text-2xl">💡</span>
                                </div>
                                <p className="text-xl leading-relaxed font-medium text-indigo-100">
                                    {cards[currentIndex].answer}
                                </p>
                            </div>
                        </div>

                        {/* Navigation Controls */}
                        <div className="absolute -bottom-16 left-0 right-0 flex justify-between items-center">
                            <button
                                onClick={handlePrev}
                                disabled={currentIndex === 0}
                                className="p-4 rounded-full bg-[var(--color-surface)] shadow-lg hover:bg-[var(--color-surface-hover)] disabled:opacity-0 transition-all text-[var(--color-text-secondary)] border border-[var(--color-border)]"
                            >
                                <ArrowLeft size={24} />
                            </button>

                            <button
                                onClick={() => setIsFlipped(!isFlipped)}
                                className="text-indigo-400 font-medium text-sm hover:underline"
                            >
                                {isFlipped ? 'Show Question' : 'Show Answer'}
                            </button>

                            <button
                                onClick={handleNext}
                                className="px-6 py-3 rounded-xl bg-indigo-600 text-white shadow-lg hover:bg-indigo-700 hover:shadow-indigo-500/30 transition-all flex items-center gap-2 font-medium"
                            >
                                {currentIndex === cards.length - 1 ? 'Finish' : 'Next Card'}
                                <ArrowRight size={20} />
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {/* Completion State */}
            {completed && (
                <div className="mt-12 text-center animate-fadeIn p-8 bg-[var(--color-surface)] rounded-3xl shadow-xl border border-[var(--color-border)]">
                    <div className="inline-flex p-4 bg-yellow-500/20 rounded-full mb-6 text-yellow-500 shadow-inner">
                        <Award size={48} />
                    </div>
                    <h2 className="text-3xl font-bold text-[var(--color-text-main)] mb-2">Excellent Work!</h2>
                    <p className="text-[var(--color-text-secondary)] mb-8 max-w-md mx-auto">You've mastered this set of cards about "{topic}". Keep learning to build your streak!</p>

                    <button
                        onClick={resetDeck}
                        className="px-8 py-3 bg-[var(--color-surface-hover)] border border-[var(--color-border)] text-white font-bold rounded-xl hover:scale-105 transition-all shadow-lg flex items-center gap-2 mx-auto"
                    >
                        <RefreshCw size={20} />
                        Study Again
                    </button>
                </div>
            )}

            <style>{`
        .perspective-1000 { perspective: 1000px; }
        .preserve-3d { transform-style: preserve-3d; }
        .backface-hidden { backface-visibility: hidden; }
        .rotate-y-180 { transform: rotateY(180deg); }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .animate-fadeIn { animation: fadeIn 0.5s cubic-bezier(0.16, 1, 0.3, 1) forwards; }
      `}</style>
        </div>
    );
};

export default Flashcards;
