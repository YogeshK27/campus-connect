import React from 'react';
import {
  PenTool,
  Car,
  Calendar,
  FileText,
  BarChart2,
  X
} from 'lucide-react';

interface CreateModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const options = [
  { label: 'Create Post', icon: PenTool, color: '#8B5CF6' },
  { label: 'Create Ride', icon: Car, color: '#EF4444' },
  { label: 'Create Event', icon: Calendar, color: '#F59E0B' },
  { label: 'Upload Notes', icon: FileText, color: '#10B981' },
  { label: 'Create Poll', icon: BarChart2, color: '#3B82F6' },
];

const CreateModal: React.FC<CreateModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={e => e.stopPropagation()}>
        <div className="modal-header">
          <h3>Create New</h3>
          <button className="close-btn" onClick={onClose}><X size={20} /></button>
        </div>

        <div className="options-grid">
          {options.map((opt) => (
            <button key={opt.label} className="option-card">
              <div className="option-icon" style={{ backgroundColor: `${opt.color}20`, color: opt.color }}>
                <opt.icon size={24} />
              </div>
              <span>{opt.label}</span>
            </button>
          ))}
        </div>
      </div>

      <style>{`
        .modal-overlay {
          position: fixed;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: rgba(0, 0, 0, 0.7);
          display: flex;
          align-items: center;
          justify-content: center;
          z-index: 100;
          backdrop-filter: blur(4px);
          animation: fade-in 0.2s ease-out;
        }

        .modal-content {
          background: var(--color-surface);
          width: 100%;
          max-width: 500px;
          border-radius: var(--radius-lg);
          border: 1px solid var(--color-border);
          padding: 1.5rem;
          transform: translateY(0);
          animation: slide-up 0.2s ease-out;
        }

        .modal-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 1.5rem;
        }

        .modal-header h3 {
          font-size: 1.25rem;
          font-weight: 700;
        }

        .close-btn {
          color: var(--color-text-secondary);
          padding: 0.5rem;
          border-radius: 50%;
        }

        .close-btn:hover {
          background: var(--color-surface-hover);
          color: var(--color-text-main);
        }

        .options-grid {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 1rem;
        }

        .option-card {
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          gap: 0.75rem;
          background: var(--color-bg);
          border: 1px solid var(--color-border);
          padding: 1.5rem;
          border-radius: var(--radius-md);
          font-weight: 600;
          color: var(--color-text-main);
          transition: all 0.2s;
        }

        .option-card:hover {
          border-color: var(--color-primary);
          transform: translateY(-2px);
          box-shadow: var(--shadow-md);
        }

        .option-icon {
          width: 48px;
          height: 48px;
          border-radius: 12px;
          display: flex;
          align-items: center;
          justify-content: center;
        }

        @keyframes fade-in {
          from { opacity: 0; }
          to { opacity: 1; }
        }

        @keyframes slide-up {
          from { transform: translateY(20px); opacity: 0; }
          to { transform: translateY(0); opacity: 1; }
        }
      `}</style>
    </div>
  );
};

export default CreateModal;
