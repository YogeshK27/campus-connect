import React, { useState, useEffect } from 'react';
import { Send, ThumbsUp, Heart, Smile, MessageCircle, Reply, Trash2 } from 'lucide-react';
import type { User } from 'firebase/auth';
import { db } from '../../lib/firebase';
import { collection, addDoc, onSnapshot, query, orderBy, serverTimestamp, updateDoc, doc, getDoc, deleteDoc } from 'firebase/firestore';
import { Link } from 'react-router-dom';
import { formatDistanceToNow } from '../../utils/date.utils';

interface Comment {
    id: string;
    text: string;
    authorId: string;
    authorName: string;
    authorPic?: string;
    createdAt: string;
    reactions?: Record<string, string>; // uid -> type
    replyCount?: number;
    replies?: Comment[]; // For nested (we'll only do one level deep for simplicity)
}

interface CommentsSectionProps {
    parentId: string; // Post ID or Poll ID
    collectionPath: string; // 'posts/{id}/comments' or 'polls/{id}/comments'
    currentUser: User | null;
}



const CommentsSection = (props: CommentsSectionProps) => {
    const { collectionPath, currentUser } = props;
    const [comments, setComments] = useState<Comment[]>([]);
    const [newComment, setNewComment] = useState('');
    const [replyingTo, setReplyingTo] = useState<string | null>(null); // comment ID
    const [replyText, setReplyText] = useState('');


    useEffect(() => {
        const q = query(collection(db, collectionPath), orderBy('createdAt', 'asc'));
        const unsubscribe = onSnapshot(q, (snapshot) => {
            const items = snapshot.docs.map(doc => ({
                id: doc.id,
                ...doc.data()
            })) as Comment[];
            setComments(items);
        });
        return () => unsubscribe();
    }, [collectionPath]);

    const handleAddComment = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!currentUser || !newComment.trim()) return;

        try {
            await addDoc(collection(db, collectionPath), {
                text: newComment,
                authorId: currentUser.uid,
                authorName: currentUser.displayName || 'User',
                authorPic: currentUser.photoURL,
                createdAt: serverTimestamp(),
                reactions: {},
                replyCount: 0
            });
            setNewComment('');

            // Increment parent comment count if applicable (requires parent knowledge, skip for now or pass callback)
        } catch (error) {
            console.error("Error adding comment:", error);
        }
    };

    const handleReply = async (commentId: string) => {
        if (!currentUser || !replyText.trim()) return;

        try {
            // Add to sub-collection: parentPath/{commentId}/replies
            await addDoc(collection(db, collectionPath, commentId, 'replies'), {
                text: replyText,
                authorId: currentUser.uid,
                authorName: currentUser.displayName || 'User',
                authorPic: currentUser.photoURL,
                createdAt: serverTimestamp(),
                reactions: {}
            });

            // Update reply count on parent comment
            const parentDocRef = doc(db, collectionPath, commentId);
            const snapshot = await getDoc(parentDocRef);
            if (snapshot.exists()) {
                const count = (snapshot.data() as any).replyCount || 0;
                await updateDoc(parentDocRef, { replyCount: count + 1 });
            }

            setReplyText('');
            setReplyingTo(null);
        } catch (error) {
            console.error("Error replying:", error);
        }
    };

    const handleReaction = async (commentId: string, type: string, isReply = false, parentCommentId?: string) => {
        if (!currentUser) return;

        const commentDocRef = doc(db, collectionPath, isReply && parentCommentId ? `${parentCommentId}/replies/${commentId}` : commentId);

        try {
            const snap = await getDoc(commentDocRef);
            if (!snap.exists()) return;

            const data = snap.data() as any;
            const currentReaction = data.reactions?.[currentUser.uid];

            if (currentReaction === type) {
                // Remove
                await updateDoc(commentDocRef, {
                    [`reactions.${currentUser.uid}`]: null
                });
            } else {
                // Set/Change
                await updateDoc(commentDocRef, {
                    [`reactions.${currentUser.uid}`]: type
                });
            }
        } catch (error) {
            console.error("Error reacting (Firestore):", error);
        }
    };

    const deleteComment = async (commentId: string) => {
        if (!currentUser) return;
        if (!confirm("Delete this comment?")) return;
        try {
            await deleteDoc(doc(db, collectionPath, commentId));
        } catch (e) {
            console.error(e);
        }
    };

    return (
        <div className="comments-section">
            <div className="comments-list space-y-4 mb-4">
                {comments.map(comment => (
                    <CommentItem
                        key={comment.id}
                        comment={comment}
                        currentUser={currentUser}
                        onReply={setReplyingTo}
                        replyingTo={replyingTo}
                        onSubmitReply={() => handleReply(comment.id)}
                        setReplyText={setReplyText}
                        replyText={replyText}
                        onReaction={handleReaction}
                        onDelete={deleteComment}
                        collectionPath={collectionPath} // Pass down for fetching replies
                    />
                ))}
            </div>

            <form onSubmit={handleAddComment} className="flex gap-2 relative">
                <input
                    type="text"
                    placeholder="Write a comment..."
                    className="flex-1 bg-[var(--color-bg)] border border-[var(--color-border)] rounded-full px-4 py-2 text-sm focus:border-[var(--color-primary)] outline-none text-[var(--color-text-main)]"
                    value={newComment}
                    onChange={(e) => setNewComment(e.target.value)}
                />
                <button type="submit" className="p-2 bg-[var(--color-primary)] text-white rounded-full hover:opacity-90 disabled:opacity-50" disabled={!newComment.trim()}>
                    <Send size={16} />
                </button>
            </form>
        </div>
    );
};

// Sub-component for individual comment item to handle its own replies state
const CommentItem: React.FC<any> = ({ comment, currentUser, onReply, replyingTo, onSubmitReply, setReplyText, replyText, onReaction, onDelete, collectionPath }) => {
    const [replies, setReplies] = useState<any[]>([]);
    const [showReplies, setShowReplies] = useState(false);

    // Fetch replies if replyCount > 0
    const fetchReplies = () => {
        if (!comment?.id) return;
        if (showReplies) {
            setShowReplies(false);
            return;
        }

        setShowReplies(true);
        const q = query(collection(db, collectionPath, comment.id, 'replies'), orderBy('createdAt', 'asc'));
        onSnapshot(q, (snapshot) => {
            const items = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
            setReplies(items);
        });
    };

    if (!comment) return null;

    const myReaction = currentUser ? comment.reactions?.[currentUser.uid] : null;

    return (
        <div className="comment-group flex gap-3">
            <Link to={`/profile/${comment.authorId || ''}`}>
                <img src={comment.authorPic || `https://ui-avatars.com/api/?name=${comment.authorName || 'User'}`} className="w-8 h-8 rounded-full object-cover border border-[var(--color-border)]" alt="" />
            </Link>
            <div className="flex-1">
                <div className="bg-[var(--color-surface)] border border-[var(--color-border)] rounded-2xl p-3 inline-block relative group">
                    <div className="flex justify-between items-start gap-4">
                        <Link to={`/profile/${comment.authorId || ''}`} className="text-xs font-bold hover:underline text-[var(--color-text-main)]">
                            {comment.authorName || 'Anonymous'}
                        </Link>
                        {currentUser && currentUser.uid === comment.authorId && (
                            <button onClick={() => onDelete(comment.id)} className="text-red-500 opacity-0 group-hover:opacity-100 transition-opacity">
                                <Trash2 size={12} />
                            </button>
                        )}
                    </div>
                    <p className="text-sm text-[var(--color-text-secondary)] mt-1 whitespace-pre-wrap">{comment.text || ''}</p>

                    {/* Reactions Display */}
                    {comment.reactions && Object.keys(comment.reactions).length > 0 && (
                        <div className="absolute -bottom-2 -right-2 bg-[var(--color-surface)] border border-[var(--color-border)] rounded-full px-1.5 py-0.5 flex items-center gap-1 shadow-sm text-[10px]">
                            {Object.values(comment.reactions).some(t => t === 'like') && <ThumbsUp size={10} className="text-blue-500" fill="currentColor" />}
                            {Object.values(comment.reactions).some(t => t === 'love') && <Heart size={10} className="text-red-500" fill="currentColor" />}
                            {Object.values(comment.reactions).some(t => t === 'haha') && <Smile size={10} className="text-yellow-500" fill="currentColor" />}
                            <span className="ml-1">{Object.keys(comment.reactions).length}</span>
                        </div>
                    )}
                </div>

                <div className="flex items-center gap-4 mt-1 ml-2 text-xs text-[var(--color-text-muted)]">
                    <span>{formatDistanceToNow(comment.createdAt, { addSuffix: true })}</span>
                    <button
                        className={`font-semibold hover:text-[var(--color-primary)] ${myReaction ? 'text-[var(--color-primary)]' : ''}`}
                        onClick={() => onReaction(comment.id, 'like')}
                    >
                        Like
                    </button>
                    <button
                        className="font-semibold hover:text-[var(--color-primary)]"
                        onClick={() => onReply(replyingTo === comment.id ? null : comment.id)}
                    >
                        Reply
                    </button>
                    {comment.replyCount > 0 && (
                        <button className="flex items-center gap-1 hover:text-[var(--color-text-main)]" onClick={fetchReplies}>
                            <MessageCircle size={12} /> {comment.replyCount} replies
                        </button>
                    )}
                </div>

                {/* Reply Input */}
                {replyingTo === comment.id && (
                    <div className="mt-2 flex gap-2 animate-in fade-in slide-in-from-top-1">
                        <input
                            autoFocus
                            className="flex-1 bg-[var(--color-bg)] border border-[var(--color-border)] rounded-full px-3 py-1.5 text-xs focus:border-[var(--color-primary)] outline-none text-[var(--color-text-main)]"
                            placeholder={`Reply to ${comment.authorName || 'User'}...`}
                            value={replyText}
                            onChange={(e) => setReplyText(e.target.value)}
                            onKeyDown={(e) => e.key === 'Enter' && onSubmitReply()}
                        />
                        <button onClick={onSubmitReply} className="p-1.5 bg-[var(--color-primary)] text-white rounded-full">
                            <Reply size={12} />
                        </button>
                    </div>
                )}

                {/* Sub-Replies List */}
                {showReplies && replies.length > 0 && (
                    <div className="ml-4 mt-2 pl-3 border-l-2 border-[var(--color-border)] space-y-3">
                        {replies.map(reply => (
                            <div key={reply.id} className="flex gap-2">
                                <Link to={`/profile/${reply.authorId || ''}`}>
                                    <img src={reply.authorPic || `https://ui-avatars.com/api/?name=${reply.authorName || 'User'}`} className="w-6 h-6 rounded-full" alt="" />
                                </Link>
                                <div>
                                    <div className="bg-[var(--color-surface)] border border-[var(--color-border)] rounded-xl p-2 px-3">
                                        <Link to={`/profile/${reply.authorId || ''}`} className="text-xs font-bold hover:underline text-[var(--color-text-main)]">{reply.authorName || 'Anonymous'}</Link>
                                        <p className="text-xs text-[var(--color-text-secondary)] mt-0.5">{reply.text || ''}</p>
                                    </div>
                                    <div className="flex gap-3 ml-2 mt-0.5 text-[10px] text-[var(--color-text-muted)]">
                                        <span>{formatDistanceToNow(reply.createdAt)} ago</span>
                                        <button
                                            className={`${reply.reactions?.[currentUser?.uid] === 'like' ? 'text-blue-500' : ''} hover:text-blue-500`}
                                            onClick={() => onReaction(reply.id, 'like', true, comment.id)}
                                        >
                                            Like {Object.keys(reply.reactions || {}).length > 0 && `(${Object.keys(reply.reactions).length})`}
                                        </button>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                )}
            </div>
        </div>
    );
};

export default CommentsSection;
