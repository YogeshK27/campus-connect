import React from 'react';
import { CheckCircle, AlertCircle, Info } from 'lucide-react';
import type { ToastType } from '../../context/ToastContext';

interface ToastProps {
    type: ToastType;
    message: string;
}

export const Toast: React.FC<ToastProps> = ({ type, message }) => {
    const icons = {
        success: <CheckCircle className="text-green-500" size={20} />,
        error: <AlertCircle className="text-red-500" size={20} />,
        info: <Info className="text-blue-500" size={20} />
    };

    return (
        <div className={`toast ${type}`}>
            <div className="flex items-center gap-3 w-full">
                <div className="shrink-0">{icons[type]}</div>
                <p className="text-sm font-bold text-[var(--color-text-main)] flex-1">{message}</p>
            </div>
        </div>
    );
};
