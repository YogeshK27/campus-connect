import { initializeApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import { getStorage } from 'firebase/storage';
import { getAnalytics } from "firebase/analytics";

const firebaseConfig = {
    apiKey: "AIzaSyBqgPJAldyH-yt-O9y5Jz1t5KCVgWBU1QY",
    authDomain: "campus-connect-183.firebaseapp.com",
    projectId: "campus-connect-183",
    storageBucket: "campus-connect-183.firebasestorage.app",
    messagingSenderId: "869935172230",
    appId: "1:869935172230:web:9858eb5e4914773c2f9f07",
    measurementId: "G-RP2XXNHGLG"
};

const app = initializeApp(firebaseConfig);
export const analytics = getAnalytics(app);
export const auth = getAuth(app);
export const firestore = getFirestore(app);
// We keep db exported as null or remove if unused, but to avoid immediate crashes in components, we'll keep it as firestore for now or just export it.
// Actually, let's export firestore specifically.
export const db = firestore;
export const storage = getStorage(app);
export const googleProvider = new GoogleAuthProvider();
