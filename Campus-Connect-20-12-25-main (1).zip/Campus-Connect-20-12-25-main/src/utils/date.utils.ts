import { formatDistanceToNow as fdn, format, isToday, isYesterday } from 'date-fns';

/**
 * Safely converts a value (Timestamp, Date, or string) to a JavaScript Date.
 */
export const toDate = (value: any): Date => {
    if (!value) return new Date();

    if (typeof value.toDate === 'function') {
        return value.toDate();
    }

    if (value instanceof Date) {
        return value;
    }

    // Handle firestore nested objects if they wasn't normalized
    if (value && typeof value.seconds === 'number') {
        return new Date(value.seconds * 1000);
    }

    const date = new Date(value);
    return isNaN(date.getTime()) ? new Date() : date;
};

/**
 * Formats a date relative to now or as a formatted string.
 * Shows "Today at 5:00 PM" or "Yesterday at 2:00 PM" or "Oct 12 at 1:00 PM"
 */
export const formatDate = (value: any): string => {
    try {
        const date = toDate(value);
        const timeStr = format(date, 'h:mm a');

        if (isToday(date)) return `Today at ${timeStr}`;
        if (isYesterday(date)) return `Yesterday at ${timeStr}`;

        return format(date, 'MMM d') + ` at ${timeStr}`;
    } catch (error) {
        return 'Recently';
    }
};

/**
 * Safe wrapper for formatDistanceToNow
 */
export const formatDistanceToNow = (value: any, options?: any): string => {
    try {
        const date = toDate(value);
        return fdn(date, options);
    } catch (error) {
        return 'just now';
    }
};
