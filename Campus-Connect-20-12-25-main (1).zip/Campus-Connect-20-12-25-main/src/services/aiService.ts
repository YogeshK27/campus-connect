
export interface Flashcard {
    id: number;
    question: string;
    answer: string;
}

const GEMINI_API_KEY = 'AIzaSyCa-MV4qGWGpbYQkoy8l57ESFndXzfACII';

export const aiService = {
    getModels: async (): Promise<string> => {
        try {
            const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models?key=${GEMINI_API_KEY}`);
            const data = await response.json();
            if (!response.ok) return `Error: ${data.error?.message || response.statusText}`;
            return "Available Models:\n" + (data.models?.map((m: any) => m.name.replace('models/', '')).join('\n') || "No models found.");
        } catch (e: any) {
            return `Debug Error: ${e.message}`;
        }
    },

    generatePost: async (topic: string): Promise<string> => {
        try {
            const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${GEMINI_API_KEY}`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    contents: [{ parts: [{ text: `Write a social media post about ${topic}. Include hashtags.` }] }]
                })
            });
            const data = await response.json();
            if (!response.ok) throw new Error(data.error?.message || response.statusText);
            return data.candidates?.[0]?.content?.parts?.[0]?.text || "No content generated.";
        } catch (e: any) {
            console.error(e);
            throw new Error(e.message || "Failed to generate post.");
        }
    },

    chat: async (message: string, history: any[] = []): Promise<string> => {
        try {
            const contents = [
                ...history.map(h => ({ role: h.sender === 'ai' ? 'model' : 'user', parts: [{ text: h.text }] })),
                { role: 'user', parts: [{ text: message }] }
            ];

            const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${GEMINI_API_KEY}`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ contents })
            });
            const data = await response.json();
            if (!response.ok) throw new Error(data.error?.message || response.statusText);
            return data.candidates?.[0]?.content?.parts?.[0]?.text || "I didn't understand that.";
        } catch (e: any) {
            console.error(e);
            throw new Error(e.message || "Error connecting to AI.");
        }
    },

    getFlashcards: async (topic: string): Promise<Flashcard[]> => {
        try {
            const prompt = `Generate 10 flashcards about "${topic}" in JSON format. 
       Return ONLY a JSON array of objects with "id" (number), "question" (string), and "answer" (string). 
       Do not include markdown formatting like \`\`\`json.`;

            const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${GEMINI_API_KEY}`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    contents: [{ parts: [{ text: prompt }] }]
                })
            });
            const data = await response.json();
            if (!response.ok) throw new Error(data.error?.message || response.statusText);

            const text = data.candidates?.[0]?.content?.parts?.[0]?.text || "[]";
            const cleanText = text.replace(/```json|```/g, '').trim();
            try {
                return JSON.parse(cleanText);
            } catch {
                // Fallback parsing if AI adds extra text
                const jsonMatch = cleanText.match(/\[.*\]/s);
                return jsonMatch ? JSON.parse(jsonMatch[0]) : [];
            }
        } catch (e: any) {
            console.error(e);
            throw new Error(e.message || "Failed to generate flashcards.");
        }
    }
};
