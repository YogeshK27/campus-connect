import {
    collection,
    doc,
    setDoc,
    getDoc,
    getDocs,
    query,
    where,
    orderBy,
    addDoc,
    updateDoc,
    deleteDoc,
    serverTimestamp,
    increment,
    onSnapshot,
    arrayUnion,
    arrayRemove
} from 'firebase/firestore';
import { db } from '../lib/firebase';

export const dbService = {
    // Users
    createUser: async (uid: string, data: any) => {
        const userRef = doc(db, 'users', uid);
        await setDoc(userRef, {
            ...data,
            uid,
            createdAt: serverTimestamp(),
            lastLogin: serverTimestamp(),
            profileComplete: false
        }, { merge: true });
    },

    getUser: async (uid: string) => {
        const userRef = doc(db, 'users', uid);
        const snap = await getDoc(userRef);
        return snap.exists() ? snap.data() : null;
    },

    updateUser: async (uid: string, data: any) => {
        const userRef = doc(db, 'users', uid);
        await updateDoc(userRef, {
            ...data,
            lastLogin: serverTimestamp()
        });
    },

    // Posts
    createPost: async (post: { uid: string; type: string; content: string; authorName: string; authorPic?: string; mediaUrl?: string }) => {
        const postsRef = collection(db, 'posts');
        const docRef = await addDoc(postsRef, {
            ...post,
            userId: post.uid,
            createdAt: serverTimestamp(),
            likes: 0,
            comments: 0,
            reactions: {},
            reactionCounts: { like: 0, dislike: 0, love: 0, laugh: 0, support: 0 }
        });
        return docRef.id;
    },

    updatePost: async (postId: string, data: any) => {
        const postRef = doc(db, 'posts', postId);
        await updateDoc(postRef, data);
    },

    deletePost: async (postId: string) => {
        const postRef = doc(db, 'posts', postId);
        await deleteDoc(postRef);
    },

    getPosts: async () => {
        const postsRef = collection(db, 'posts');
        const q = query(postsRef, orderBy('createdAt', 'desc'));
        const snap = await getDocs(q);
        return snap.docs.map(d => ({ $id: d.id, ...d.data() }));
    },

    // Rides
    createRide: async (ride: any) => {
        const ridesRef = collection(db, 'rides');
        const docRef = await addDoc(ridesRef, {
            ...ride,
            createdAt: serverTimestamp(),
            status: 'open',
            participants: [ride.hostId]
        });
        return docRef.id;
    },

    updateRide: async (rideId: string, data: any) => {
        const rideRef = doc(db, 'rides', rideId);
        await updateDoc(rideRef, data);
    },

    deleteRide: async (rideId: string) => {
        const rideRef = doc(db, 'rides', rideId);
        await deleteDoc(rideRef);
    },

    joinRide: async (rideId: string, uid: string, passengerInfo: any) => {
        const rideRef = doc(db, 'rides', rideId);
        await updateDoc(rideRef, {
            participants: arrayUnion(uid),
            passengers: arrayUnion(passengerInfo),
            availableSeats: increment(-1)
        });
    },

    leaveRide: async (rideId: string, uid: string, passengerInfo: any) => {
        const rideRef = doc(db, 'rides', rideId);
        await updateDoc(rideRef, {
            participants: arrayRemove(uid),
            passengers: arrayRemove(passengerInfo),
            availableSeats: increment(1)
        });
    },

    getRides: async () => {
        const ridesRef = collection(db, 'rides');
        // Removed orderBy to avoid composite index requirement with where clause
        const q = query(ridesRef, where('status', '==', 'open'));
        const snap = await getDocs(q);
        return snap.docs.map(d => ({ $id: d.id, ...d.data() }));
    },

    // Events
    getEvents: async () => {
        const eventsRef = collection(db, 'events');
        const q = query(eventsRef, orderBy('date', 'asc'));
        const snap = await getDocs(q);
        return snap.docs.map(d => ({ $id: d.id, ...d.data() }));
    },

    createEvent: async (event: any) => {
        const eventsRef = collection(db, 'events');
        const docRef = await addDoc(eventsRef, {
            ...event,
            createdAt: serverTimestamp(),
            interested: []
        });
        return docRef.id;
    },

    toggleEventInterest: async (eventId: string, uid: string, isInterested: boolean) => {
        const eventRef = doc(db, 'events', eventId);
        await updateDoc(eventRef, {
            interested: isInterested ? arrayRemove(uid) : arrayUnion(uid)
        });
    },

    // Generic Saved Items
    toggleSaveItem: async (uid: string, itemId: string, type: 'post' | 'ride' | 'event', itemData: any, isSaved: boolean) => {
        const saveRef = doc(db, 'users', uid, 'saved', itemId);
        if (isSaved) {
            await deleteDoc(saveRef);
        } else {
            await setDoc(saveRef, {
                itemId,
                type,
                ...itemData,
                savedAt: serverTimestamp()
            });
        }
    },

    isItemSaved: async (uid: string, itemId: string) => {
        const saveRef = doc(db, 'users', uid, 'saved', itemId);
        const snap = await getDoc(saveRef);
        return snap.exists();
    },

    // Real-time listeners wrapper
    subscribeToCollection: (collectionName: string, callback: (data: any[]) => void) => {
        const colRef = collection(db, collectionName);
        let q;
        if (collectionName === 'events') {
            q = query(colRef, orderBy('date', 'asc'));
        } else if (collectionName === 'rides') {
            q = query(colRef, orderBy('createdAt', 'desc'));
        } else {
            q = query(colRef, orderBy('createdAt', 'desc'));
        }

        return onSnapshot(q, (snap) => {
            const data = snap.docs.map(d => ({
                $id: d.id,
                ...d.data()
            }));
            callback(data);
        }, (err) => {
            console.error(`Error subscribing to ${collectionName}:`, err);
        });
    },

    subscribeToDoc: (collectionName: string, docId: string, callback: (data: any) => void) => {
        const docRef = doc(db, collectionName, docId);
        return onSnapshot(docRef, (snap) => {
            callback(snap.exists() ? { $id: snap.id, ...snap.data() } : null);
        });
    },

    // Chat Management
    sendMessage: async (chatId: string, senderId: string, text: string) => {
        const messagesRef = collection(db, 'chats', chatId, 'messages');
        const chatRef = doc(db, 'chats', chatId);
        const now = serverTimestamp();

        await addDoc(messagesRef, {
            senderId,
            text,
            createdAt: now
        });

        await setDoc(chatRef, {
            lastMessage: text,
            lastMessageAt: now,
            updatedAt: now
        }, { merge: true });
    },

    subscribeToMessages: (chatId: string, callback: (messages: any[]) => void) => {
        const messagesRef = collection(db, 'chats', chatId, 'messages');
        const q = query(messagesRef, orderBy('createdAt', 'asc'));
        return onSnapshot(q, (snap) => {
            const messages = snap.docs.map(d => ({ id: d.id, ...d.data() }));
            callback(messages);
        });
    },

    // Friend Management
    sendFriendRequest: async (fromUid: string, toUid: string) => {
        const reqsRef = collection(db, 'friendRequests');
        await addDoc(reqsRef, {
            fromUserId: fromUid,
            toUserId: toUid,
            status: 'pending',
            createdAt: serverTimestamp()
        });
    },

    subscribeToFriendRequests: (uid: string, callback: (reqs: any[]) => void) => {
        const reqsRef = collection(db, 'friendRequests');
        const q = query(reqsRef, where('toUserId', '==', uid));
        return onSnapshot(q, (snap) => {
            const reqs = snap.docs.map(d => ({ id: d.id, ...d.data() }));
            callback(reqs);
        });
    },

    updateFriendRequest: async (reqId: string, status: 'accepted' | 'rejected') => {
        const reqRef = doc(db, 'friendRequests', reqId);
        await updateDoc(reqRef, {
            status,
            updatedAt: serverTimestamp()
        });
    },

    getFriends: async (uid: string) => {
        const reqsRef = collection(db, 'friendRequests');
        const q1 = query(reqsRef, where('fromUserId', '==', uid), where('status', '==', 'accepted'));
        const q2 = query(reqsRef, where('toUserId', '==', uid), where('status', '==', 'accepted'));

        const [snap1, snap2] = await Promise.all([getDocs(q1), getDocs(q2)]);

        const friendUids = new Set<string>();
        snap1.docs.forEach(d => friendUids.add(d.data().toUserId));
        snap2.docs.forEach(d => friendUids.add(d.data().fromUserId));

        return Array.from(friendUids);
    }
};
