import { dbService } from '../db.service';
import { aiService } from '../aiService';

export interface EventRecommendation {
    eventId: string;
    eventTitle: string;
    eventDate: string;
    eventTime: string;
    eventLocation: string;
    matchScore: number;
    reason: string;
    category: string;
}

export interface UserPreference {
    userId: string;
    interests: string[];
    attendedEvents: string[];
    preferredCategories: string[];
    lastUpdated: Date;
}

class EventRecommenderService {
    /**
     * Analyzes user's past behavior to build preference profile
     */
    async buildUserProfile(userId: string): Promise<UserPreference> {
        try {
            // Get user's posts to infer interests
            const posts = await dbService.getPosts();
            const userPosts = posts.filter((p: any) => p.userId === userId);

            // Get events user has shown interest in
            const events = await dbService.getEvents();
            const interestedEvents = events.filter((e: any) =>
                e.interested?.includes(userId)
            );

            // Use AI to extract interests from posts
            const postsContent = userPosts.slice(0, 10).map((p: any) => p.content).join('. ');

            const prompt = `Analyze these user posts and extract their interests:
"${postsContent}"

Also consider they attended these events: ${interestedEvents.map((e: any) => e.title).join(', ')}

Return a JSON object with:
- interests: string[] (list of interests like "AI", "Music", "Sports")
- preferredCategories: string[] (event types like "Technical", "Cultural", "Sports")

Return ONLY the JSON object.`;

            const response = await aiService.chat(prompt);
            const cleanResponse = response.replace(/```json|```/g, '').trim();
            const analysis = JSON.parse(cleanResponse);

            return {
                userId,
                interests: analysis.interests || [],
                attendedEvents: interestedEvents.map((e: any) => e.$id),
                preferredCategories: analysis.preferredCategories || [],
                lastUpdated: new Date()
            };
        } catch (error) {
            console.error('Error building user profile:', error);
            return {
                userId,
                interests: [],
                attendedEvents: [],
                preferredCategories: [],
                lastUpdated: new Date()
            };
        }
    }

    /**
     * Scores an event against user preferences
     */
    async scoreEvent(event: any, userProfile: UserPreference): Promise<number> {
        try {
            const prompt = `Rate how well this event matches the user's interests (0-100):

Event: ${event.title}
Description: ${event.description || 'No description'}
Location: ${event.location}

User Interests: ${userProfile.interests.join(', ')}
Preferred Categories: ${userProfile.preferredCategories.join(', ')}

Return ONLY a number between 0-100.`;

            const response = await aiService.chat(prompt);
            const score = parseInt(response.trim());
            return isNaN(score) ? 0 : Math.min(100, Math.max(0, score));
        } catch (error) {
            console.error('Error scoring event:', error);
            return 0;
        }
    }

    /**
     * Generates personalized recommendation reason
     */
    async generateRecommendationReason(event: any, userProfile: UserPreference, score: number): Promise<string> {
        try {
            const prompt = `Write a brief, personalized reason (max 20 words) why this event is recommended:

Event: ${event.title}
User Interests: ${userProfile.interests.slice(0, 3).join(', ')}
Match Score: ${score}/100

Be enthusiastic and specific. Start with "Because you're interested in..."`;

            const response = await aiService.chat(prompt);
            return response.trim();
        } catch (error) {
            return `This event matches your interests with ${score}% compatibility!`;
        }
    }

    /**
     * Main autonomous function: finds and recommends events proactively
     */
    async getPersonalizedRecommendations(userId: string): Promise<EventRecommendation[]> {
        try {
            // Step 1: Build/update user profile
            const userProfile = await this.buildUserProfile(userId);

            // Step 2: Get upcoming events
            const events = await dbService.getEvents();
            const upcomingEvents = events.filter((e: any) => {
                const eventDate = new Date(e.date);
                return eventDate >= new Date() && !e.interested?.includes(userId);
            });

            if (upcomingEvents.length === 0) {
                return [];
            }

            // Step 3: Score each event
            const recommendations: EventRecommendation[] = [];

            for (let i = 0; i < upcomingEvents.length; i++) {
                const event: any = upcomingEvents[i];
                const score = await this.scoreEvent(event, userProfile);

                // Only recommend events with score >= 70
                if (score >= 70) {
                    const reason = await this.generateRecommendationReason(event, userProfile, score);

                    recommendations.push({
                        eventId: event.$id,
                        eventTitle: event.title,
                        eventDate: event.date,
                        eventTime: event.time,
                        eventLocation: event.location,
                        matchScore: score,
                        reason,
                        category: event.category || 'General'
                    });
                }

                // Limit to top 3 recommendations
                if (recommendations.length >= 3) break;
            }

            // Sort by score
            return recommendations.sort((a, b) => b.matchScore - a.matchScore);
        } catch (error) {
            console.error('Error getting recommendations:', error);
            return [];
        }
    }

    /**
     * Categorizes an event using AI
     */
    async categorizeEvent(eventTitle: string, eventDescription: string): Promise<string> {
        try {
            const prompt = `Categorize this event into ONE category:

Title: ${eventTitle}
Description: ${eventDescription}

Categories: Technical, Cultural, Sports, Academic, Social, Career

Return ONLY the category name.`;

            const response = await aiService.chat(prompt);
            return response.trim();
        } catch (error) {
            return 'General';
        }
    }
}

export const eventRecommenderService = new EventRecommenderService();
