import { dbService } from '../db.service';
import { aiService } from '../aiService';

export interface ProactiveSuggestion {
    id: string;
    trigger: string;
    suggestion: string;
    actions: SuggestionAction[];
    priority: number;
    icon: string;
    category: 'deadline' | 'conflict' | 'opportunity' | 'reminder';
}

export interface SuggestionAction {
    label: string;
    type: 'navigate' | 'create' | 'notify';
    data?: any;
}

class ProactiveAssistantService {
    /**
     * Analyzes user context and generates proactive suggestions
     */
    async generateSuggestions(userId: string): Promise<ProactiveSuggestion[]> {
        const suggestions: ProactiveSuggestion[] = [];

        try {
            // Get user's data
            const [posts, rides, events] = await Promise.all([
                dbService.getPosts(),
                dbService.getRides(),
                dbService.getEvents()
            ]);

            const userPosts = posts.filter((p: any) => p.userId === userId);
            const userRides = rides.filter((r: any) =>
                r.participants?.includes(userId) || r.hostId === userId
            );
            const userEvents = events.filter((e: any) =>
                e.interested?.includes(userId) || e.organizerId === userId
            );

            // Check for upcoming events without rides
            const upcomingEvents = userEvents.filter((e: any) => {
                const eventDate = new Date(e.date);
                const today = new Date();
                const daysUntil = Math.ceil((eventDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
                return daysUntil >= 0 && daysUntil <= 3;
            });

            for (const event of upcomingEvents) {
                const evt: any = event;
                const hasRide = userRides.some((r: any) => r.date === evt.date);
                if (!hasRide) {
                    suggestions.push({
                        id: `ride-${evt.$id}`,
                        trigger: 'Upcoming event without transportation',
                        suggestion: `${evt.title} is in ${this.getDaysUntil(evt.date)} days. Need a ride?`,
                        actions: [
                            { label: 'Find Ride', type: 'navigate', data: '/ridesharing' },
                            { label: 'Dismiss', type: 'notify' }
                        ],
                        priority: 80,
                        icon: '🚗',
                        category: 'opportunity'
                    });
                }
            }

            // Check for posts mentioning deadlines
            const recentPosts = userPosts.slice(0, 10);
            if (recentPosts.length > 0) {
                const deadlineSuggestion = await this.analyzeForDeadlines(recentPosts);
                if (deadlineSuggestion) {
                    suggestions.push(deadlineSuggestion);
                }
            }

            // Check for study opportunities
            if (userPosts.some((p: any) => p.content?.toLowerCase().includes('exam'))) {
                suggestions.push({
                    id: 'study-reminder',
                    trigger: 'Exam mentioned in posts',
                    suggestion: 'I noticed you mentioned an exam. Want me to find study partners?',
                    actions: [
                        { label: 'Find Partners', type: 'create', data: { type: 'study' } },
                        { label: 'Later', type: 'notify' }
                    ],
                    priority: 70,
                    icon: '📚',
                    category: 'opportunity'
                });
            }

            // Sort by priority
            return suggestions.sort((a, b) => b.priority - a.priority).slice(0, 3);
        } catch (error) {
            console.error('Error generating suggestions:', error);
            return [];
        }
    }

    /**
     * Analyzes posts for deadline mentions
     */
    private async analyzeForDeadlines(posts: any[]): Promise<ProactiveSuggestion | null> {
        try {
            const postsContent = posts.map(p => p.content).join('. ');

            const prompt = `Analyze these posts for upcoming deadlines or important dates:

"${postsContent}"

If you find any deadlines, return JSON with:
- hasDeadline: boolean
- deadline: string (the deadline mentioned)
- task: string (what needs to be done)
- urgency: "low", "medium", or "high"

Return ONLY the JSON object.`;

            const response = await aiService.chat(prompt);
            const cleanResponse = response.replace(/```json|```/g, '').trim();
            const result = JSON.parse(cleanResponse);

            if (result.hasDeadline) {
                return {
                    id: 'deadline-reminder',
                    trigger: 'Deadline detected in posts',
                    suggestion: `Reminder: ${result.task} - deadline is ${result.deadline}`,
                    actions: [
                        { label: 'Set Reminder', type: 'notify' },
                        { label: 'Dismiss', type: 'notify' }
                    ],
                    priority: result.urgency === 'high' ? 90 : result.urgency === 'medium' ? 75 : 60,
                    icon: '⏰',
                    category: 'deadline'
                };
            }

            return null;
        } catch (error) {
            return null;
        }
    }

    /**
     * Helper: Get days until date
     */
    private getDaysUntil(dateStr: string): string {
        const targetDate = new Date(dateStr);
        const today = new Date();
        const daysUntil = Math.ceil((targetDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));

        if (daysUntil === 0) return 'today';
        if (daysUntil === 1) return 'tomorrow';
        return `${daysUntil} days`;
    }
}

export const proactiveAssistantService = new ProactiveAssistantService();
