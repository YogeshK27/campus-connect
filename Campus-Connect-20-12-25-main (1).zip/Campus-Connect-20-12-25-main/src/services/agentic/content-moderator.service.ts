import { aiService } from '../aiService';

export interface ModerationResult {
    flagged: boolean;
    categories: string[];
    confidence: number;
    action: 'allow' | 'review' | 'block';
    reason: string;
    suggestions?: string;
}

class ContentModeratorService {
    /**
     * Analyzes content for inappropriate material
     */
    async moderateContent(content: string): Promise<ModerationResult> {
        try {
            const prompt = `Analyze this student post for inappropriate content:

"${content}"

Check for:
- Hate speech or discrimination
- Spam or promotional content
- Academic dishonesty (sharing exam answers, plagiarism)
- Harassment or bullying
- Inappropriate language

Return JSON with:
- flagged: boolean (true if any issues found)
- categories: string[] (list of issues found, empty if none)
- confidence: number (0-100, how certain you are)
- action: "allow" (safe), "review" (borderline), or "block" (clearly inappropriate)
- reason: brief explanation
- suggestions: optional improvement suggestions if flagged

Return ONLY the JSON object.`;

            const response = await aiService.chat(prompt);
            const cleanResponse = response.replace(/```json|```/g, '').trim();

            try {
                const result = JSON.parse(cleanResponse);
                return {
                    flagged: result.flagged || false,
                    categories: result.categories || [],
                    confidence: result.confidence || 0,
                    action: result.action || 'allow',
                    reason: result.reason || 'Content appears appropriate',
                    suggestions: result.suggestions
                };
            } catch {
                // Default to allowing if parsing fails
                return {
                    flagged: false,
                    categories: [],
                    confidence: 0,
                    action: 'allow',
                    reason: 'Unable to analyze content'
                };
            }
        } catch (error) {
            console.error('Error moderating content:', error);
            return {
                flagged: false,
                categories: [],
                confidence: 0,
                action: 'allow',
                reason: 'Moderation service unavailable'
            };
        }
    }

    /**
     * Batch moderate multiple posts
     */
    async moderateBatch(posts: Array<{ id: string; content: string; authorId: string }>): Promise<Map<string, ModerationResult>> {
        const results = new Map<string, ModerationResult>();

        for (const post of posts) {
            const result = await this.moderateContent(post.content);
            results.set(post.id, result);
        }

        return results;
    }

    /**
     * Get moderation statistics
     */
    getModerationStats(results: ModerationResult[]): {
        total: number;
        flagged: number;
        blocked: number;
        categories: Record<string, number>;
    } {
        const stats = {
            total: results.length,
            flagged: results.filter(r => r.flagged).length,
            blocked: results.filter(r => r.action === 'block').length,
            categories: {} as Record<string, number>
        };

        results.forEach(result => {
            result.categories.forEach(category => {
                stats.categories[category] = (stats.categories[category] || 0) + 1;
            });
        });

        return stats;
    }
}

export const contentModeratorService = new ContentModeratorService();
