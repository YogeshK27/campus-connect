import { dbService } from '../db.service';
import { aiService } from '../aiService';

export interface StudyMatch {
    userId: string;
    userName: string;
    userPhoto: string;
    subject: string;
    matchScore: number;
    reason: string;
}

export interface StudyGroupSuggestion {
    id: string;
    subject: string;
    members: StudyMatch[];
    suggestedTime: string;
    suggestedLocation: string;
    createdAt: Date;
}

class StudyBuddyService {
    /**
     * Analyzes a post to detect study-related content
     */
    async analyzePostForStudyNeeds(postContent: string): Promise<{
        isStudyRelated: boolean;
        subject?: string;
        difficulty?: string;
        urgency?: string;
        preferredTime?: string;
    } | null> {
        try {
            const prompt = `Analyze this student post and extract study-related information:
"${postContent}"

Return a JSON object with:
- isStudyRelated: boolean (true if this is about studying, exams, assignments, or projects)
- subject: string (the academic subject, e.g., "Data Structures", "Machine Learning")
- difficulty: string ("beginner", "intermediate", "advanced")
- urgency: string ("low", "medium", "high" - based on deadlines mentioned)
- preferredTime: string (if mentioned, e.g., "evening", "weekend", "next week")

Return ONLY the JSON object, no markdown formatting.`;

            const response = await aiService.chat(prompt);
            const cleanResponse = response.replace(/```json|```/g, '').trim();

            try {
                return JSON.parse(cleanResponse);
            } catch {
                // Fallback: try to extract JSON from response
                const jsonMatch = cleanResponse.match(/\{.*\}/s);
                if (jsonMatch) {
                    return JSON.parse(jsonMatch[0]);
                }
                return null;
            }
        } catch (error) {
            console.error('Error analyzing post:', error);
            return null;
        }
    }

    /**
     * Finds potential study partners based on subject and user activity
     */
    async findStudyPartners(subject: string, requestingUserId: string): Promise<StudyMatch[]> {
        try {
            // Get all posts to find users interested in the same subject
            const posts = await dbService.getPosts();

            // Find posts mentioning the subject
            const relevantPosts = posts.filter((p: any) =>
                p.content?.toLowerCase().includes(subject.toLowerCase()) &&
                p.userId !== requestingUserId
            );

            // Extract unique users
            const userMap = new Map<string, any>();
            relevantPosts.forEach((post: any) => {
                if (!userMap.has(post.userId)) {
                    userMap.set(post.userId, {
                        userName: post.authorName,
                        userPhoto: post.authorPic || '',
                        posts: []
                    });
                }
                userMap.get(post.userId)!.posts.push(post.content);
            });

            // Score each potential partner using AI
            const matches: StudyMatch[] = [];

            for (const [_userId, userData] of userMap.entries()) {
                if (matches.length >= 5) break; // Limit to top 5 matches

                try {
                    const prompt = `Rate the compatibility (0-100) of these two students for studying ${subject}:

Student A wants to study: ${subject}
Student B's recent posts: ${userData.posts.slice(0, 3).join('; ')}

Return a JSON object with:
- score: number (0-100, how well they match)
- reason: string (brief explanation why they're a good match)

Return ONLY the JSON object.`;

                    const response = await aiService.chat(prompt);
                    const cleanResponse = response.replace(/```json|```/g, '').trim();
                    const result = JSON.parse(cleanResponse);

                    if (result.score >= 60) {
                        matches.push({
                            userId: userData.userId,
                            userName: userData.userName,
                            userPhoto: userData.userPhoto,
                            subject,
                            matchScore: result.score,
                            reason: result.reason
                        });
                    }
                } catch (error) {
                    console.error('Error scoring match:', error);
                }
            }

            // Sort by score
            return matches.sort((a, b) => b.matchScore - a.matchScore);
        } catch (error) {
            console.error('Error finding study partners:', error);
            return [];
        }
    }

    /**
     * Creates a study group suggestion
     */
    async createStudyGroupSuggestion(
        subject: string,
        members: StudyMatch[]
    ): Promise<StudyGroupSuggestion | null> {
        try {
            // Use AI to suggest optimal meeting time and location
            const prompt = `Suggest an optimal study session for a group studying ${subject}.

Return a JSON object with:
- suggestedTime: string (e.g., "Tomorrow at 6 PM", "This weekend")
- suggestedLocation: string (e.g., "Library Study Room", "Campus Café")

Return ONLY the JSON object.`;

            const response = await aiService.chat(prompt);
            const cleanResponse = response.replace(/```json|```/g, '').trim();
            const suggestion = JSON.parse(cleanResponse);

            const groupSuggestion: StudyGroupSuggestion = {
                id: Math.random().toString(36).substr(2, 9),
                subject,
                members,
                suggestedTime: suggestion.suggestedTime,
                suggestedLocation: suggestion.suggestedLocation,
                createdAt: new Date()
            };

            return groupSuggestion;
        } catch (error) {
            console.error('Error creating study group suggestion:', error);
            return null;
        }
    }

    /**
     * Main autonomous function: monitors posts and creates study groups
     */
    async processNewPost(postContent: string, authorId: string): Promise<StudyGroupSuggestion | null> {
        try {
            // Step 1: Analyze if post is study-related
            const analysis = await this.analyzePostForStudyNeeds(postContent);

            if (!analysis || !analysis.isStudyRelated || !analysis.subject) {
                return null;
            }

            // Step 2: Find matching study partners
            const matches = await this.findStudyPartners(analysis.subject, authorId);

            if (matches.length === 0) {
                return null;
            }

            // Step 3: Create study group suggestion
            const suggestion = await this.createStudyGroupSuggestion(
                analysis.subject,
                matches
            );

            return suggestion;
        } catch (error) {
            console.error('Error processing post for study buddy:', error);
            return null;
        }
    }
}

export const studyBuddyService = new StudyBuddyService();
