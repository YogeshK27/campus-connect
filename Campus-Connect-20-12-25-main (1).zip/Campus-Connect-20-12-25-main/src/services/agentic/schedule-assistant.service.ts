import { dbService } from '../db.service';
import { aiService } from '../aiService';

export interface ConflictingItem {
    id: string;
    type: 'ride' | 'event' | 'study';
    title: string;
    time: string;
    date: string;
    location?: string;
}

export interface Conflict {
    id: string;
    items: ConflictingItem[];
    severity: 'low' | 'medium' | 'high';
    detectedAt: Date;
    resolved: boolean;
}

export interface Solution {
    id: string;
    description: string;
    action: 'reschedule' | 'cancel' | 'notify' | 'alternative';
    confidence: number;
    details: string;
}

class ScheduleAssistantService {
    /**
     * Detects conflicts in user's schedule
     */
    async detectConflicts(userId: string): Promise<Conflict[]> {
        try {
            const conflicts: Conflict[] = [];

            // Get user's rides
            const rides = await dbService.getRides();
            const userRides = rides.filter((r: any) =>
                r.participants?.includes(userId) || r.hostId === userId
            );

            // Get user's events
            const events = await dbService.getEvents();
            const userEvents = events.filter((e: any) =>
                e.interested?.includes(userId) || e.organizerId === userId
            );

            // Combine all scheduled items
            const scheduledItems: ConflictingItem[] = [
                ...userRides.map((r: any) => ({
                    id: r.$id,
                    type: 'ride' as const,
                    title: `Ride: ${r.from} → ${r.to}`,
                    time: r.time,
                    date: r.date,
                    location: r.from
                })),
                ...userEvents.map((e: any) => ({
                    id: e.$id,
                    type: 'event' as const,
                    title: e.title,
                    time: e.time,
                    date: e.date,
                    location: e.location
                }))
            ];

            // Check for time conflicts
            for (let i = 0; i < scheduledItems.length; i++) {
                for (let j = i + 1; j < scheduledItems.length; j++) {
                    const item1 = scheduledItems[i];
                    const item2 = scheduledItems[j];

                    // Check if same date
                    if (item1.date === item2.date) {
                        // Simple time overlap check (can be enhanced)
                        const time1 = this.parseTime(item1.time);
                        const time2 = this.parseTime(item2.time);

                        if (Math.abs(time1 - time2) < 2) { // Within 2 hours
                            conflicts.push({
                                id: Math.random().toString(36).substr(2, 9),
                                items: [item1, item2],
                                severity: this.calculateSeverity(item1, item2),
                                detectedAt: new Date(),
                                resolved: false
                            });
                        }
                    }
                }
            }

            return conflicts;
        } catch (error) {
            console.error('Error detecting conflicts:', error);
            return [];
        }
    }

    /**
     * Generates AI-powered solutions for a conflict
     */
    async generateSolutions(conflict: Conflict): Promise<Solution[]> {
        try {
            const prompt = `Analyze this scheduling conflict and suggest solutions:

Conflict:
- Item 1: ${conflict.items[0].title} at ${conflict.items[0].time} on ${conflict.items[0].date}
- Item 2: ${conflict.items[1].title} at ${conflict.items[1].time} on ${conflict.items[1].date}

Suggest 2-3 practical solutions. For each solution, provide:
- action: "reschedule", "cancel", "notify", or "alternative"
- description: brief user-friendly description
- confidence: 0-100 (how good is this solution)
- details: specific steps to execute

Return a JSON array of solutions.`;

            const response = await aiService.chat(prompt);
            const cleanResponse = response.replace(/```json|```/g, '').trim();

            try {
                const solutions = JSON.parse(cleanResponse);
                return solutions.map((s: any, index: number) => ({
                    id: `sol-${index}`,
                    description: s.description,
                    action: s.action,
                    confidence: s.confidence || 75,
                    details: s.details
                }));
            } catch {
                // Fallback solution
                return [{
                    id: 'sol-1',
                    description: 'Reschedule one of the items',
                    action: 'reschedule',
                    confidence: 70,
                    details: 'Choose which item to move to a different time'
                }];
            }
        } catch (error) {
            console.error('Error generating solutions:', error);
            return [];
        }
    }

    /**
     * Analyzes priority using AI
     */
    async analyzePriority(item1: ConflictingItem, item2: ConflictingItem): Promise<{
        higherPriority: string;
        reason: string;
    }> {
        try {
            const prompt = `Which of these two activities should have higher priority?

Activity A: ${item1.title}
Activity B: ${item2.title}

Consider: academic importance, social value, commitments to others.

Return JSON with:
- higherPriority: "A" or "B"
- reason: brief explanation (max 15 words)`;

            const response = await aiService.chat(prompt);
            const cleanResponse = response.replace(/```json|```/g, '').trim();
            const result = JSON.parse(cleanResponse);

            return {
                higherPriority: result.higherPriority === 'A' ? item1.id : item2.id,
                reason: result.reason
            };
        } catch (error) {
            return {
                higherPriority: item1.id,
                reason: 'Unable to determine priority'
            };
        }
    }

    /**
     * Helper: Parse time string to hours
     */
    private parseTime(timeStr: string): number {
        const match = timeStr.match(/(\d+):?(\d+)?\s*(AM|PM)?/i);
        if (!match) return 0;

        let hours = parseInt(match[1]);
        const minutes = parseInt(match[2] || '0');
        const period = match[3]?.toUpperCase();

        if (period === 'PM' && hours !== 12) hours += 12;
        if (period === 'AM' && hours === 12) hours = 0;

        return hours + minutes / 60;
    }

    /**
     * Helper: Calculate conflict severity
     */
    private calculateSeverity(item1: ConflictingItem, item2: ConflictingItem): 'low' | 'medium' | 'high' {
        // Events are generally higher priority
        if (item1.type === 'event' && item2.type === 'event') return 'high';
        if (item1.type === 'event' || item2.type === 'event') return 'medium';
        return 'low';
    }
}

export const scheduleAssistantService = new ScheduleAssistantService();
