import { dbService } from './db.service';
import { aiService } from './aiService';
import type {
    Mission,
    MissionStep,
    AgentResponse,
    TransportResult,
    CredentialingResult,
    AcademicSyncResult
} from '../types/agent.types';

export class AgentService {
    private createMissionStep(description: string, status: 'pending' | 'in_progress' | 'completed' | 'failed' = 'pending'): MissionStep {
        return {
            id: Math.random().toString(36).substr(2, 9),
            description,
            status,
            timestamp: new Date()
        };
    }

    private createMission(type: 'transport' | 'credentialing' | 'academic_sync', title: string): Mission {
        return {
            id: Math.random().toString(36).substr(2, 9),
            type,
            status: 'pending',
            title,
            steps: []
        };
    }

    async executeTransportMission(userId: string, from: string): Promise<Mission> {
        const mission = this.createMission('transport', 'Transport Logistics');

        try {
            // Step 1: Query database
            const step1 = this.createMissionStep('Searching rides database...', 'in_progress');
            mission.steps.push(step1);
            mission.status = 'in_progress';

            const rides = await dbService.getRides();
            const availableRides = rides.filter((r: any) =>
                r.status === 'open' &&
                r.from.toLowerCase().includes(from.toLowerCase()) &&
                r.availableSeats > 0
            );

            step1.status = 'completed';
            step1.details = `Found ${availableRides.length} available rides`;

            if (availableRides.length === 0) {
                throw new Error('No rides available matching your criteria');
            }

            // Step 2: Select optimal ride
            const step2 = this.createMissionStep('Selecting optimal ride...', 'in_progress');
            mission.steps.push(step2);

            // Select first available ride (can be enhanced with rating logic)
            const selectedRide: any = availableRides[0];
            step2.status = 'completed';
            step2.details = `Selected ride with ${selectedRide.hostName}`;

            // Step 3: Auto-book ride
            const step3 = this.createMissionStep('Booking ride...', 'in_progress');
            mission.steps.push(step3);

            await dbService.joinRide(selectedRide.$id, userId, {
                uid: userId,
                name: 'Current User',
                photoURL: ''
            });

            step3.status = 'completed';
            step3.details = 'Ride booked successfully';

            mission.status = 'completed';
            mission.result = {
                rideId: selectedRide.$id,
                driverName: selectedRide.hostName,
                from: selectedRide.from,
                to: selectedRide.to,
                time: selectedRide.time,
                fare: selectedRide.fare
            } as TransportResult;

        } catch (error: any) {
            mission.status = 'failed';
            mission.error = error.message;
            mission.steps.forEach(step => {
                if (step.status === 'in_progress') step.status = 'failed';
            });
        }

        return mission;
    }

    async executeCredentialingMission(userId: string): Promise<Mission> {
        const mission = this.createMission('credentialing', 'Event Credentialing');

        try {
            // Step 1: Fetch events
            const step1 = this.createMissionStep('Fetching upcoming events...', 'in_progress');
            mission.steps.push(step1);
            mission.status = 'in_progress';

            const events = await dbService.getEvents();
            const upcomingEvents = events.filter((e: any) => {
                const eventDate = new Date(e.date);
                return eventDate >= new Date();
            });

            step1.status = 'completed';
            step1.details = `Found ${upcomingEvents.length} upcoming events`;

            if (upcomingEvents.length === 0) {
                throw new Error('No upcoming events found');
            }

            // Step 2: Generate QR pass
            const step2 = this.createMissionStep('Generating event pass...', 'in_progress');
            mission.steps.push(step2);

            const selectedEvent: any = upcomingEvents[0];
            // Generate a simple QR code URL (in production, this would be a real QR code)
            const qrCode = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=EVENT:${selectedEvent.$id}:USER:${userId}`;

            step2.status = 'completed';
            step2.details = 'Event pass ready';

            mission.status = 'completed';
            mission.result = {
                eventId: selectedEvent.$id,
                eventTitle: selectedEvent.title,
                qrCode,
                passReady: true
            } as CredentialingResult;

        } catch (error: any) {
            mission.status = 'failed';
            mission.error = error.message;
            mission.steps.forEach(step => {
                if (step.status === 'in_progress') step.status = 'failed';
            });
        }

        return mission;
    }

    async executeAcademicSyncMission(projectTag: string = 'Project X'): Promise<Mission> {
        const mission = this.createMission('academic_sync', 'Academic Sync');

        try {
            // Step 1: Search for project notes
            const step1 = this.createMissionStep('Searching for project updates...', 'in_progress');
            mission.steps.push(step1);
            mission.status = 'in_progress';

            const posts = await dbService.getPosts();
            const projectPosts = posts.filter((p: any) =>
                p.content?.toLowerCase().includes(projectTag.toLowerCase())
            );

            step1.status = 'completed';
            step1.details = `Found ${projectPosts.length} posts tagged with "${projectTag}"`;

            if (projectPosts.length === 0) {
                throw new Error(`No posts found with tag "${projectTag}"`);
            }

            // Step 2: Analyze with AI
            const step2 = this.createMissionStep('Analyzing notes with Gemini AI...', 'in_progress');
            mission.steps.push(step2);

            const latestPost: any = projectPosts[0];
            const prompt = `Summarize this project update and identify any location changes or important deadlines: "${latestPost.content}"`;

            const summary = await aiService.chat(prompt);

            step2.status = 'completed';
            step2.details = 'AI analysis complete';

            // Extract location change if mentioned
            const locationMatch = summary.match(/location.*?(?:changed|moved).*?to\s+([^.]+)/i);
            const locationChange = locationMatch ? locationMatch[1].trim() : undefined;

            mission.status = 'completed';
            mission.result = {
                projectName: projectTag,
                summary,
                locationChange,
                notesFound: true
            } as AcademicSyncResult;

        } catch (error: any) {
            mission.status = 'failed';
            mission.error = error.message;
            mission.steps.forEach(step => {
                if (step.status === 'in_progress') step.status = 'failed';
            });
        }

        return mission;
    }

    async executeConciergeRequest(userId: string, userInput: string): Promise<AgentResponse> {
        const missions: Mission[] = [];

        // Parse user intent (simple keyword matching for now)
        const needsTransport = /ride|transport|drive|pick.*up/i.test(userInput);
        const needsPass = /pass|qr|ticket|entry/i.test(userInput);
        const needsAcademicSync = /project|notes|meeting|group/i.test(userInput);

        // Extract parameters
        const fromMatch = userInput.match(/from\s+([A-Za-z\s]+?)(?:\s+to|\s+and|$)/i);
        const from = fromMatch ? fromMatch[1].trim() : 'Block B';

        // Execute missions in parallel
        const missionPromises: Promise<Mission>[] = [];

        if (needsTransport) {
            missionPromises.push(this.executeTransportMission(userId, from));
        }

        if (needsPass) {
            missionPromises.push(this.executeCredentialingMission(userId));
        }

        if (needsAcademicSync) {
            missionPromises.push(this.executeAcademicSyncMission('Project X'));
        }

        const completedMissions = await Promise.all(missionPromises);
        missions.push(...completedMissions);

        // Generate summary
        const summary = this.generateSummary(missions);

        return {
            missions,
            summary,
            completedAt: new Date()
        };
    }

    private generateSummary(missions: Mission[]): string {
        const parts: string[] = [];

        missions.forEach(mission => {
            if (mission.status === 'completed' && mission.result) {
                switch (mission.type) {
                    case 'transport':
                        const transport = mission.result as TransportResult;
                        parts.push(`✓ Your ride with ${transport.driverName} is confirmed for ${transport.time} (₹${transport.fare})`);
                        break;
                    case 'credentialing':
                        const cred = mission.result as CredentialingResult;
                        parts.push(`✓ Your ${cred.eventTitle} pass is ready and pinned`);
                        break;
                    case 'academic_sync':
                        const academic = mission.result as AcademicSyncResult;
                        parts.push(`✓ ${academic.projectName}: ${academic.summary}`);
                        if (academic.locationChange) {
                            parts.push(`  📍 Location updated to: ${academic.locationChange}`);
                        }
                        break;
                }
            } else if (mission.status === 'failed') {
                parts.push(`✗ ${mission.title} failed: ${mission.error}`);
            }
        });

        return parts.join('\n\n');
    }
}

export const agentService = new AgentService();
