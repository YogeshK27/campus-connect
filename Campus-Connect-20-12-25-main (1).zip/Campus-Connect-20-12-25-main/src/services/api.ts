import { dbService } from './db.service';

export const api = {
    getPosts: async () => {
        return dbService.getPosts();
    },

    createPost: async (post: { uid: string; type: string; content: string; authorName: string }) => {
        return dbService.createPost(post);
    },

    getRides: async () => {
        return dbService.getRides();
    },

    getEvents: async () => {
        return dbService.getEvents();
    },

    getUser: async (uid: string) => {
        return dbService.getUser(uid);
    },

    register: async (userData: any) => {
        // In v2, registration is handled by onGoogleLogin + dbService.createUser
        return dbService.createUser(userData.uid, userData);
    }
};
