export type MissionType = 'transport' | 'credentialing' | 'academic_sync';
export type MissionStatus = 'pending' | 'in_progress' | 'completed' | 'failed';

export interface Mission {
    id: string;
    type: MissionType;
    status: MissionStatus;
    title: string;
    steps: MissionStep[];
    result?: any;
    error?: string;
}

export interface MissionStep {
    id: string;
    description: string;
    status: MissionStatus;
    timestamp: Date;
    details?: string;
}

export interface AgentRequest {
    userInput: string;
    userId: string;
    timestamp: Date;
}

export interface AgentResponse {
    missions: Mission[];
    summary: string;
    completedAt?: Date;
}

export interface TransportResult {
    rideId: string;
    driverName: string;
    from: string;
    to: string;
    time: string;
    fare: number;
}

export interface CredentialingResult {
    eventId: string;
    eventTitle: string;
    qrCode: string;
    passReady: boolean;
}

export interface AcademicSyncResult {
    projectName: string;
    summary: string;
    locationChange?: string;
    notesFound: boolean;
}
