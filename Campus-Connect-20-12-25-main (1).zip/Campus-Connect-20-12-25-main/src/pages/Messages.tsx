import React, { useState, useEffect } from 'react';
import { MessageSquare, Loader2, ShieldAlert } from 'lucide-react';
import { db, auth } from '../lib/firebase';
import { collection, onSnapshot, query, getDoc, doc, orderBy } from 'firebase/firestore';
import { onAuthStateChanged } from 'firebase/auth';
import { Link, useNavigate } from 'react-router-dom';

interface Conversation {
    id: string;
    chatId: string;
    lastMessage: string;
    lastMessageTime: any;
    otherUser?: any;
}

const Messages: React.FC = () => {
    const navigate = useNavigate();
    const [currentUser, setCurrentUser] = useState<any>(null);
    const [conversations, setConversations] = useState<Conversation[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const unsubscribe = onAuthStateChanged(auth, (user) => {
            setCurrentUser(user);
        });
        return () => unsubscribe();
    }, []);

    useEffect(() => {
        if (!currentUser) return;

        useEffect(() => {
            if (!currentUser) return;

            const convsQuery = query(collection(db, 'users', currentUser.uid, 'conversations'), orderBy('lastMessageTime', 'desc'));

            const unsubscribe = onSnapshot(convsQuery, async (snapshot) => {
                const convList = await Promise.all(snapshot.docs.map(async (d) => {
                    const data = d.data();
                    const otherUid = d.id;
                    const userSnap = await getDoc(doc(db, 'users', otherUid));
                    return {
                        id: otherUid,
                        ...data,
                        otherUser: userSnap.exists() ? { uid: otherUid, ...userSnap.data() } : null
                    } as Conversation;
                }));

                setConversations(convList);
                setLoading(false);
            });

            return () => unsubscribe();
        }, [currentUser]);
    }, [currentUser]);

    if (!currentUser) {
        return (
            <div className="flex flex-col items-center justify-center py-20">
                <ShieldAlert className="text-red-500 mb-4" size={48} />
                <h2 className="text-xl font-bold">Access Restricted</h2>
                <p className="text-[var(--color-text-secondary)]">Sign in to view your messages.</p>
                <Link to="/login" className="mt-4 text-indigo-500 font-bold hover:underline">Login</Link>
            </div>
        );
    }

    return (
        <div className="max-w-2xl mx-auto px-4 py-8 pb-20">
            <div className="flex items-center justify-between mb-8">
                <h1 className="text-3xl font-black italic tracking-tighter">CHATS</h1>
                <Link to="/friends" className="text-xs font-bold uppercase text-indigo-500 hover:underline">Friends List</Link>
            </div>

            {loading ? (
                <div className="flex justify-center py-20"><Loader2 className="animate-spin text-indigo-500" /></div>
            ) : conversations.length > 0 ? (
                <div className="space-y-3">
                    {conversations.map(conv => (
                        <div
                            key={conv.id}
                            onClick={() => navigate(`/chat/${conv.chatId}`)}
                            className="bg-[var(--color-surface)] border border-[var(--color-border)] rounded-2xl p-4 flex items-center justify-between hover:border-indigo-500/50 hover:shadow-lg hover:shadow-indigo-500/5 transition-all cursor-pointer group"
                        >
                            <div className="flex items-center gap-4">
                                <div className="w-14 h-14 rounded-full border-2 border-[var(--color-bg)] overflow-hidden bg-indigo-500 flex items-center justify-center text-white font-bold group-hover:scale-105 transition-transform">
                                    {conv.otherUser?.profilePhotoUrl ? (
                                        <img src={conv.otherUser.profilePhotoUrl} className="w-full h-full object-cover" alt="" />
                                    ) : conv.otherUser?.name?.charAt(0) || '?'}
                                </div>
                                <div>
                                    <div className="font-bold text-[var(--color-text-main)] group-hover:text-indigo-500 transition-colors">{conv.otherUser?.name || 'Deleted User'}</div>
                                    <div className="text-xs text-[var(--color-text-secondary)] line-clamp-1 max-w-[200px]">{conv.lastMessage}</div>
                                </div>
                            </div>
                            <div className="text-right">
                                <div className="text-[10px] text-[var(--color-text-muted)] font-bold">
                                    {conv.lastMessageTime ? new Date(conv.lastMessageTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : 'Recently'}
                                </div>
                                {conv.otherUser?.uid && (
                                    <div className="mt-1 w-2 h-2 rounded-full bg-green-500 ml-auto"></div>
                                )}
                            </div>
                        </div>
                    ))}
                </div>
            ) : (
                <div className="text-center py-20 opacity-40 border-2 border-dashed border-[var(--color-border)] rounded-3xl">
                    <MessageSquare size={48} className="mx-auto mb-4 text-[var(--color-text-muted)]" />
                    <p className="font-black uppercase tracking-widest text-lg">No Conversations</p>
                    <p className="text-xs mt-1">Chat from ride details or friend profiles.</p>
                </div>
            )}
        </div>
    );
};

export default Messages;
