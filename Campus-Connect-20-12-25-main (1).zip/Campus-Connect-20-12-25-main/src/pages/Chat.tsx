import React, { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { Send, ArrowLeft, Loader2, ShieldAlert } from 'lucide-react';
import { dbService } from '../services/db.service';
import { auth } from '../lib/firebase';
import { onAuthStateChanged } from 'firebase/auth';

interface Message {
    id: string;
    senderId: string;
    text: string;
    createdAt: any;
}

const Chat: React.FC = () => {
    const { chatId } = useParams();
    const navigate = useNavigate();
    const [messages, setMessages] = useState<Message[]>([]);
    const [newMessage, setNewMessage] = useState('');
    const [currentUser, setCurrentUser] = useState<any>(null);
    const [otherUser, setOtherUser] = useState<any>(null);
    const [loading, setLoading] = useState(true);
    const scrollRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const unsubscribe = onAuthStateChanged(auth, (user) => {
            setCurrentUser(user);
        });
        return () => unsubscribe();
    }, []);

    useEffect(() => {
        if (!chatId || !currentUser) return;

        // Determine other user's ID
        const uids = chatId.split('_');
        const otherUid = uids.find(id => id !== currentUser.uid);

        if (!otherUid) {
            setLoading(false);
            return;
        }

        const fetchOtherUser = async () => {
            const userData = await dbService.getUser(otherUid);
            if (userData) {
                setOtherUser({ uid: otherUid, ...userData });
            }
        };
        fetchOtherUser();

        // Sub to messages (Firestore)
        const unsub = dbService.subscribeToMessages(chatId, (fetchedMessages) => {
            setMessages(fetchedMessages);
            setLoading(false);
            setTimeout(() => {
                scrollRef.current?.scrollIntoView({ behavior: 'smooth' });
            }, 100);
        });

        return () => unsub();
    }, [chatId, currentUser]);

    const handleSend = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!newMessage.trim() || !currentUser || !chatId) return;

        try {
            await dbService.sendMessage(chatId, currentUser.uid, newMessage);
            setNewMessage('');
        } catch (err: any) {
            console.error("Error sending message (Firestore):", err);
        }
    };

    if (!currentUser) return <div className="p-10 text-center"><ShieldAlert className="mx-auto mb-4" /> Please Login</div>;
    if (loading) return <div className="p-20 flex justify-center"><Loader2 className="animate-spin text-indigo-500" /></div>;

    return (
        <div className="flex flex-col h-[calc(100vh-100px)] max-w-2xl mx-auto border-x border-[var(--color-border)] bg-[var(--color-bg)]">
            {/* Header */}
            <div className="p-4 border-b border-[var(--color-border)] bg-[var(--color-surface)] flex items-center gap-4">
                <button onClick={() => navigate(-1)} className="p-2 hover:bg-[var(--color-bg)] rounded-full transition-colors">
                    <ArrowLeft size={20} />
                </button>
                <Link to={`/profile/${otherUser?.uid}`} className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full overflow-hidden bg-indigo-500 flex items-center justify-center text-white font-bold">
                        {otherUser?.profilePhotoUrl ? (
                            <img src={otherUser.profilePhotoUrl} className="w-full h-full object-cover" alt="" />
                        ) : otherUser?.name?.charAt(0) || 'U'}
                    </div>
                    <div>
                        <div className="font-bold text-[var(--color-text-main)] text-sm">{otherUser?.name || 'User'}</div>
                        <div className="text-[10px] text-green-500 font-bold uppercase tracking-widest">Online</div>
                    </div>
                </Link>
            </div>

            {/* Chat Body */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
                {messages.length === 0 ? (
                    <div className="text-center py-10 opacity-40">
                        <p className="text-xs font-black uppercase tracking-widest">No messages yet</p>
                        <p className="text-[10px]">Send a hello!</p>
                    </div>
                ) : (
                    messages.map((m, idx) => {
                        const isMe = m.senderId === currentUser.uid;
                        return (
                            <div key={m.id || idx} className={`flex ${isMe ? 'justify-end' : 'justify-start'}`}>
                                <div className={`max-w-[80%] px-4 py-2 rounded-2xl text-sm font-medium shadow-sm ${isMe
                                    ? 'bg-indigo-600 text-white rounded-br-none'
                                    : 'bg-[var(--color-surface)] text-[var(--color-text-main)] border border-[var(--color-border)] rounded-bl-none'
                                    }`}>
                                    {m.text}
                                </div>
                            </div>
                        );
                    })
                )}
                <div ref={scrollRef}></div>
            </div>

            {/* Footer */}
            <form onSubmit={handleSend} className="p-4 border-t border-[var(--color-border)] bg-[var(--color-surface)] flex gap-2">
                <input
                    className="flex-1 bg-[var(--color-bg)] border border-[var(--color-border)] rounded-2xl px-4 py-2 text-sm focus:ring-2 ring-indigo-500 outline-none"
                    placeholder="Type a message..."
                    value={newMessage}
                    onChange={e => setNewMessage(e.target.value)}
                />
                <button type="submit" className="w-10 h-10 bg-indigo-600 text-white rounded-full flex items-center justify-center hover:scale-110 active:scale-95 transition-all shadow-lg shadow-indigo-500/30">
                    <Send size={18} />
                </button>
            </form>
        </div>
    );
};

export default Chat;
