import { Heart, MessageCircle, UserPlus, Info } from 'lucide-react';

const mockNotifications = [
    { id: 1, type: 'like', text: 'Aryan Das liked your post: "Library open till 2 AM"', time: '5m', read: false },
    { id: 2, type: 'comment', text: 'Priya commented on your ride request: "I can join too!"', time: '1h', read: false },
    { id: 3, type: 'system', text: 'Your ride has been confirmed.', time: '2h', read: true },
    { id: 4, type: 'follow', text: 'Coding Club started following you.', time: 'Yesterday', read: true },
];

const Notifications: React.FC = () => {
    return (
        <div className="notifications-container">
            <div className="notifications-header">
                <h1>Notifications</h1>
                <button className="mark-read-btn">Mark all as read</button>
            </div>

            <div className="notifications-list">
                {mockNotifications.map(notif => (
                    <div key={notif.id} className={`notification-item ${!notif.read ? 'unread' : ''}`}>
                        <div className="notif-icon-wrapper">
                            {notif.type === 'like' && <Heart className="notif-icon icon-like" size={20} />}
                            {notif.type === 'comment' && <MessageCircle className="notif-icon icon-comment" size={20} />}
                            {notif.type === 'system' && <Info className="notif-icon icon-system" size={20} />}
                            {notif.type === 'follow' && <UserPlus className="notif-icon icon-follow" size={20} />}
                        </div>

                        <div className="notif-content">
                            <p>{notif.text}</p>
                            <span className="notif-time">{notif.time} ago</span>
                        </div>

                        {!notif.read && <div className="unread-dot" />}
                    </div>
                ))}
            </div>

            <style>{`
        .notifications-container {
          max-width: 600px;
          margin: 0 auto;
        }

        .notifications-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 1.5rem;
        }

        .notifications-header h1 {
          font-size: 1.5rem;
        }

        .mark-read-btn {
          color: var(--color-primary);
          font-size: 0.875rem;
          font-weight: 500;
        }

        .notifications-list {
          display: flex;
          flex-direction: column;
          gap: 0.5rem;
        }

        .notification-item {
          display: flex;
          gap: 1rem;
          background: var(--color-surface);
          padding: 1rem;
          border-radius: var(--radius-lg);
          border: 1px solid var(--color-border);
          align-items: center;
          position: relative;
        }

        .notification-item.unread {
          background: var(--color-surface-hover);
          border-color: var(--color-primary);
        }

        .notif-icon-wrapper {
          flex-shrink: 0;
          width: 40px;
          height: 40px;
          border-radius: 50%;
          background: var(--color-bg);
          display: flex;
          align-items: center;
          justify-content: center;
          border: 1px solid var(--color-border);
        }

        .icon-like { color: #ef4444; }
        .icon-comment { color: #3b82f6; }
        .icon-system { color: #f59e0b; }
        .icon-follow { color: #10b981; }

        .notif-content {
          flex: 1;
        }

        .notif-content p {
          font-size: 0.9375rem;
          margin-bottom: 0.25rem;
          color: var(--color-text-main);
        }

        .notif-time {
          font-size: 0.75rem;
          color: var(--color-text-muted);
        }

        .unread-dot {
          width: 8px;
          height: 8px;
          background: var(--color-primary);
          border-radius: 50%;
        }
      `}</style>
        </div>
    );
};

export default Notifications;
