import React, { useState, useEffect } from 'react';
import { Plus, CheckCircle, Loader2, MessageCircle, Trash2 } from 'lucide-react';
import { auth, db } from '../lib/firebase';
import { collection, addDoc, onSnapshot, query, orderBy, serverTimestamp, updateDoc, doc, getDoc, deleteDoc } from 'firebase/firestore';
import { onAuthStateChanged, type User } from 'firebase/auth';
import CommentsSection from '../components/common/CommentsSection';
import { formatDistanceToNow } from 'date-fns';

interface PollOption {
    id: number;
    text: string;
    votes: number;
}

interface Poll {
    id: string;
    question: string;
    options: PollOption[];
    authorId: string;
    authorName: string;
    createdAt: string;
    expiresAt: string;
    totalVotes: number;
    voters?: Record<string, number>; // uid -> optionId
}

const Polls: React.FC = () => {
    const [polls, setPolls] = useState<Poll[]>([]);
    const [loading, setLoading] = useState(true);
    const [showCreate, setShowCreate] = useState(false);
    const [currentUser, setCurrentUser] = useState<User | null>(null);
    const [showComments, setShowComments] = useState<string | null>(null); // poll ID

    // Create Form
    const [question, setQuestion] = useState('');
    const [options, setOptions] = useState(['', '']);
    const [duration, setDuration] = useState('1'); // days

    useEffect(() => {
        const unsubscribeAuth = onAuthStateChanged(auth, u => setCurrentUser(u));

        const q = query(collection(db, 'polls'), orderBy('createdAt', 'desc'));
        const unsubscribePolls = onSnapshot(q, (snapshot) => {
            const fetchedPolls = snapshot.docs.map(doc => ({
                id: doc.id,
                ...doc.data()
            })) as Poll[];
            setPolls(fetchedPolls);
            setLoading(false);
        });

        return () => {
            unsubscribeAuth();
            unsubscribePolls();
        };
    }, []);

    const handleAddOption = () => {
        if (options.length < 5) setOptions([...options, '']);
    };

    const handleOptionChange = (index: number, value: string) => {
        const newOptions = [...options];
        newOptions[index] = value;
        setOptions(newOptions);
    };

    const handleCreate = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!currentUser) return alert("Login to create poll");
        if (options.some(o => !o.trim())) return alert("All options must be filled");

        const expiresDate = new Date();
        expiresDate.setDate(expiresDate.getDate() + parseInt(duration));

        try {
            await addDoc(collection(db, 'polls'), {
                question,
                options: options.map((text, i) => ({ id: i, text, votes: 0 })),
                authorId: currentUser.uid,
                authorName: currentUser.displayName || 'Student',
                createdAt: serverTimestamp(),
                expiresAt: expiresDate.toISOString(),
                totalVotes: 0,
                voters: {}
            });
            setShowCreate(false);
            setQuestion('');
            setOptions(['', '']);
        } catch (error) {
            console.error(error);
        }
    };

    const handleVote = async (poll: Poll, optionId: number) => {
        if (!currentUser) return alert("Login to vote");

        if (new Date() > new Date(poll.expiresAt)) return alert("Poll ended");

        if (poll.voters?.[currentUser.uid] !== undefined) {
            return alert("You already voted");
        }

        try {
            const pollDocRef = doc(db, 'polls', poll.id);
            const snapshot = await getDoc(pollDocRef);

            if (!snapshot.exists()) return;
            const currentPoll = snapshot.data() as Poll;

            const newOptions = [...currentPoll.options];
            newOptions[optionId].votes += 1;

            await updateDoc(pollDocRef, {
                options: newOptions,
                totalVotes: (currentPoll.totalVotes || 0) + 1,
                [`voters.${currentUser.uid}`]: optionId
            });
        } catch (error) {
            console.error("Vote failed (Firestore):", error);
        }
    };

    const handleDelete = async (pollId: string) => {
        if (!confirm("Delete poll?")) return;
        try {
            await deleteDoc(doc(db, 'polls', pollId));
        } catch (e) {
            console.error(e);
        }
    };

    return (
        <div className="page-container h-full overflow-y-auto pb-20">
            <div className="header-actions">
                <h1>Campus Polls</h1>
                <button className="primary-btn" onClick={() => setShowCreate(!showCreate)}>
                    <Plus size={20} /> Create Poll
                </button>
            </div>

            {showCreate && (
                <div className="create-card">
                    <h3>New Poll</h3>
                    <form onSubmit={handleCreate}>
                        <input type="text" placeholder="Ask a question..." value={question} onChange={e => setQuestion(e.target.value)} required />
                        <div className="options-input">
                            {options.map((opt, i) => (
                                <input key={i} type="text" placeholder={`Option ${i + 1}`} value={opt} onChange={e => handleOptionChange(i, e.target.value)} required />
                            ))}
                            {options.length < 5 && (
                                <button type="button" onClick={handleAddOption} className="text-sm text-[var(--color-primary)] font-bold">+ Add Option</button>
                            )}
                        </div>
                        <select value={duration} onChange={e => setDuration(e.target.value)}>
                            <option value="1">Ends in 24 Hours</option>
                            <option value="3">Ends in 3 Days</option>
                            <option value="7">Ends in 1 Week</option>
                        </select>
                        <button type="submit" className="submit-btn" disabled={!currentUser}>Start Poll</button>
                    </form>
                </div>
            )}

            <div className="polls-list space-y-6">
                {loading ? <div className="text-center p-10"><Loader2 className="animate-spin inline" /></div> :
                    polls.length === 0 ? <p className="text-center text-[var(--color-text-muted)]">No active polls.</p> :
                        polls.map(poll => {
                            const hasVoted = currentUser && poll.voters?.[currentUser.uid] !== undefined;
                            const votedOption = hasVoted ? poll.voters?.[currentUser.uid] : null;
                            const isExpired = new Date() > new Date(poll.expiresAt);

                            return (
                                <div key={poll.id} className="poll-card">
                                    <div className="flex justify-between items-start mb-2">
                                        <h3 className="font-bold text-lg text-[var(--color-text-main)] w-full">{poll.question}</h3>
                                        {currentUser?.uid === poll.authorId && (
                                            <button onClick={() => handleDelete(poll.id)} className="text-red-500 hover:bg-red-500/10 p-1 rounded transition-colors"><Trash2 size={16} /></button>
                                        )}
                                    </div>
                                    <div className="text-xs text-[var(--color-text-muted)] mb-4">
                                        Posted by {poll.authorName} • {formatDistanceToNow(new Date(poll.createdAt))} ago
                                    </div>
                                    <div className="options space-y-3">
                                        {poll.options.map(opt => {
                                            const percentage = poll.totalVotes > 0 ? Math.round((opt.votes / poll.totalVotes) * 100) : 0;
                                            const isSelected = votedOption === opt.id;

                                            return (
                                                <div
                                                    key={opt.id}
                                                    className={`option relative border rounded-lg overflow-hidden transition-all ${!hasVoted && !isExpired ? 'hover:border-[var(--color-primary)] cursor-pointer' : ''} ${isSelected ? 'border-[var(--color-primary)] ring-1 ring-[var(--color-primary)]' : 'border-[var(--color-border)]'}`}
                                                    onClick={() => !hasVoted && !isExpired && handleVote(poll, opt.id)}
                                                >
                                                    {/* Progress Bar Background */}
                                                    {(hasVoted || isExpired) && (
                                                        <div
                                                            className={`absolute top-0 left-0 h-full transition-all duration-500 ${isSelected ? 'bg-purple-500/20' : 'bg-gray-500/10'}`}
                                                            style={{ width: `${percentage}%` }}
                                                        />
                                                    )}

                                                    <div className="relative p-3 flex justify-between items-center z-10">
                                                        <span className="font-medium text-[var(--color-text-main)] flex items-center gap-2">
                                                            {opt.text}
                                                            {isSelected && <CheckCircle size={14} className="text-[var(--color-primary)]" />}
                                                        </span>
                                                        {(hasVoted || isExpired) && (
                                                            <span className="text-sm font-bold text-[var(--color-text-secondary)]">{percentage}%</span>
                                                        )}
                                                    </div>
                                                </div>
                                            );
                                        })}
                                    </div>
                                    <div className="mt-4 flex justify-between items-center text-xs text-[var(--color-text-secondary)] border-t border-[var(--color-border)] pt-3">
                                        <span>{poll.totalVotes} votes • {isExpired ? 'Ended' : `Ends ${formatDistanceToNow(new Date(poll.expiresAt), { addSuffix: true })}`}</span>
                                        <button className="flex items-center gap-1 hover:text-[var(--color-primary)]" onClick={() => setShowComments(showComments === poll.id ? null : poll.id)}>
                                            <MessageCircle size={14} /> Comments
                                        </button>
                                    </div>

                                    {/* Comments Integration */}
                                    {showComments === poll.id && (
                                        <div className="mt-4 pt-4 border-t border-[var(--color-border)] animate-in slide-in-from-top-2">
                                            <CommentsSection
                                                parentId={poll.id}
                                                collectionPath={`polls/${poll.id}/comments`}
                                                currentUser={currentUser}
                                            />
                                        </div>
                                    )}
                                </div>
                            );
                        })
                }
            </div>

            <style>{`
                .page-container {
                    padding: 1rem;
                    max-width: 800px;
                    margin: 0 auto;
                }
                .header-actions {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    margin-bottom: 2rem;
                }
                h1 { color: var(--color-text-main); font-size: 1.5rem; font-weight: 700; }
                .primary-btn {
                    background: var(--color-primary);
                    color: white;
                    border: none;
                    padding: 0.5rem 1rem;
                    border-radius: var(--radius-md);
                    display: flex;
                    align-items: center;
                    gap: 0.5rem;
                    cursor: pointer;
                }
                .create-card {
                    background: var(--color-surface);
                    padding: 1.5rem;
                    border-radius: var(--radius-lg);
                    margin-bottom: 2rem;
                    border: 1px solid var(--color-border);
                }
                .create-card form {
                    display: flex;
                    flex-direction: column;
                    gap: 1rem;
                    margin-top: 1rem;
                }
                .create-card h3 { color: var(--color-text-main); }
                input, select {
                    padding: 0.75rem;
                    background: var(--color-bg);
                    border: 1px solid var(--color-border);
                    border-radius: var(--radius-md);
                    color: var(--color-text-main);
                }
                .options-input {
                    display: flex;
                    flex-direction: column;
                    gap: 0.5rem;
                }
                .submit-btn {
                    background: var(--color-primary);
                    color: white;
                    padding: 0.75rem;
                    border: none;
                    border-radius: var(--radius-md);
                    font-weight: 600;
                    cursor: pointer;
                }
                .poll-card {
                    background: var(--color-surface);
                    padding: 1.5rem;
                    border-radius: var(--radius-lg);
                    border: 1px solid var(--color-border);
                    box-shadow: var(--shadow-sm);
                }
            `}</style>
        </div>
    );
};

export default Polls;
