import React, { useState, useEffect } from 'react';
import { Users, Calendar, ExternalLink, Loader2 } from 'lucide-react';
import { db } from '../lib/firebase';
import { collection, onSnapshot, query } from 'firebase/firestore';

interface Club {
    $id: string;
    name: string;
    description: string;
    category: string;
    members: number;
    image?: string;
    nextEvent?: string;
}

// Seed data if empty (mock for now or could create seed script)
const mockClubs: Club[] = [
    { $id: '1', name: 'Coding Club', description: 'For tech enthusiasts and developers.', category: 'Tech', members: 120, nextEvent: 'Hackathon' },
    { $id: '2', name: 'Dance Club', description: 'Express yourself through movement.', category: 'Arts', members: 85, nextEvent: 'Workshop' },
    { $id: '3', name: 'Debate Society', description: 'Voice your opinions.', category: 'Literary', members: 50 }
];

const Clubs: React.FC = () => {
    const [clubs, setClubs] = useState<Club[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const clubsQuery = query(collection(db, 'clubs'));
        setLoading(true);
        const unsubscribe = onSnapshot(clubsQuery, (snapshot) => {
            if (!snapshot.empty) {
                const fetchedClubs = snapshot.docs.map(doc => ({
                    $id: doc.id,
                    ...doc.data()
                })) as Club[];
                setClubs(fetchedClubs);
            } else {
                setClubs(mockClubs);
            }
            setLoading(false);
        }, (error) => {
            console.error("Error fetching clubs (Firestore):", error);
            setClubs(mockClubs);
            setLoading(false);
        });

        return () => unsubscribe();
    }, []);

    return (
        <div className="page-container h-full overflow-y-auto pb-20">
            <div className="header-actions">
                <h1>Student Clubs</h1>
            </div>

            <div className="clubs-grid">
                {loading ? (
                    <div className="flex justify-center p-8 text-[var(--color-text-muted)] col-span-full">
                        <Loader2 className="animate-spin" />
                    </div>
                ) : (
                    clubs.map(club => (
                        <div key={club.$id} className="club-card">
                            <div className="club-banner" style={{ background: 'linear-gradient(45deg, var(--color-primary), var(--color-accent))' }}>
                                <Users size={40} color="white" />
                            </div>
                            <div className="club-content">
                                <span className="category">{club.category}</span>
                                <h3>{club.name}</h3>
                                <p>{club.description}</p>
                                <div className="stats">
                                    <span><Users size={14} /> {club.members} Members</span>
                                    {club.nextEvent && <span><Calendar size={14} /> Next: {club.nextEvent}</span>}
                                </div>
                                <button className="join-btn">View Details <ExternalLink size={14} /></button>
                            </div>
                        </div>
                    )))}
            </div>

            <style>{`
                .page-container {
                    padding: 1rem;
                    max-width: 1000px;
                    margin: 0 auto;
                }
                .header-actions {
                    margin-bottom: 2rem;
                }
                .clubs-grid {
                    display: grid;
                    grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
                    gap: 1.5rem;
                }
                .club-card {
                    background: var(--color-surface);
                    border: 1px solid var(--color-border);
                    border-radius: var(--radius-lg);
                    overflow: hidden;
                    transition: transform 0.2s;
                }
                .club-card:hover {
                    transform: translateY(-5px);
                }
                .club-banner {
                    height: 100px;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                }
                .club-content {
                    padding: 1.5rem;
                }
                .category {
                    font-size: 0.75rem;
                    text-transform: uppercase;
                    color: var(--color-primary);
                    font-weight: 700;
                    margin-bottom: 0.5rem;
                    display: block;
                }
                .club-content h3 {
                    margin-bottom: 0.5rem;
                    color: var(--color-text-main);
                }
                .club-content p {
                    color: var(--color-text-secondary);
                    font-size: 0.9rem;
                    margin-bottom: 1.5rem;
                }
                .stats {
                    display: flex;
                    gap: 1rem;
                    color: var(--color-text-muted);
                    font-size: 0.8rem;
                    margin-bottom: 1rem;
                }
                .stats span { display: flex; align-items: center; gap: 0.25rem; }
                .join-btn {
                    width: 100%;
                    padding: 0.75rem;
                    background: var(--color-surface-hover);
                    border: none;
                    border-radius: var(--radius-md);
                    color: var(--color-text-main);
                    cursor: pointer;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    gap: 0.5rem;
                }
                .join-btn:hover {
                    background: var(--color-primary);
                    color: white;
                }
            `}</style>
        </div>
    );
};

export default Clubs;
