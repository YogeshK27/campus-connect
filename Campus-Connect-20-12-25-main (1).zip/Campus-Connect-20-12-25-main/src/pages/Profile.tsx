import React, { useEffect, useState } from 'react';
import { MapPin, Calendar, Edit2, Camera, Loader2, ShieldAlert, User as UserIcon, Globe, Linkedin, Twitter, Github, Moon, Sun, Settings as SettingsIcon, UserPlus, MessageSquare } from 'lucide-react';
import { auth, storage, db } from '../lib/firebase';
import { dbService } from '../services/db.service';
import { ref as storageRef, uploadBytes, getDownloadURL } from 'firebase/storage';
import { onAuthStateChanged, deleteUser, type User as FirebaseUser } from 'firebase/auth';
import { useNavigate, useParams, Link } from 'react-router-dom';
import { useTheme } from '../context/ThemeContext';
import { serverTimestamp, collection, query as firestoreQuery, where, getDocs, orderBy, updateDoc, doc, deleteDoc, addDoc } from 'firebase/firestore';

interface UserProfile {
  uid: string;
  name: string;
  email: string;
  role: string;
  bio: string;
  profilePhotoUrl: string;
  profileComplete: boolean;
  createdAt: string;
  lastLogin: string;
  college: string;
  year?: string;
  branch?: string;
  socials?: {
    linkedin?: string;
    twitter?: string;
    github?: string;
    website?: string;
  };
  interests?: string[];
}

type ViewStatus = 'loading' | 'success' | 'error' | 'not_found';

const Profile: React.FC = () => {
  const { uid: routeUid } = useParams();
  const navigate = useNavigate();
  const { theme, toggleTheme } = useTheme();

  const [currentUser, setCurrentUser] = useState<FirebaseUser | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);

  // Strict State Machine
  const [status, setStatus] = useState<ViewStatus>('loading');
  const [errorMessage, setErrorMessage] = useState('');

  const [uploading, setUploading] = useState(false);

  // Tabs
  const [activeTab, setActiveTab] = useState('Overview');
  // Data States
  const [posts, setPosts] = useState<any[]>([]);
  const [rides, setRides] = useState<any[]>([]);
  const [events, setEvents] = useState<any[]>([]);
  const [notes, setNotes] = useState<any[]>([]);
  const [savedItems, setSavedItems] = useState<any[]>([]);
  const [dataLoading, setDataLoading] = useState(false);

  // Edit States
  const [isEditingName, setIsEditingName] = useState(false);
  const [newName, setNewName] = useState('');
  const [isEditingSocials, setIsEditingSocials] = useState(false);
  const [socialsForm, setSocialsForm] = useState({
    linkedin: '',
    twitter: '',
    github: '',
    website: ''
  });
  const [settingsForm, setSettingsForm] = useState({
    name: '',
    bio: '',
    college: '',
    year: '',
    branch: '',
    residence_type: ''
  });

  // Social Stats
  const [friendStatus, setFriendStatus] = useState<'none' | 'pending' | 'friends'>('none');

  // 1. Auth Listener
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      setCurrentUser(user);
    });
    return () => unsubscribe();
  }, []);

  // 2. Fetch Profile Logic
  useEffect(() => {
    let isMounted = true;

    const resolveAndFetch = () => {
      setStatus('loading');

      let targetUid = routeUid;
      if (!targetUid) {
        if (auth.currentUser) targetUid = auth.currentUser.uid;
        else if (currentUser) targetUid = currentUser.uid;
      }

      if (!targetUid) {
        if (status !== 'loading') setStatus('error');
        setErrorMessage("User session not found.");
        return;
      }

      // Using subscribeToDoc from dbService (Firestore)
      const unsub = dbService.subscribeToDoc('users', targetUid, (userData) => {
        if (!isMounted) return;

        if (userData) {
          const p: UserProfile = {
            uid: targetUid as string,
            name: userData.name || 'User',
            email: userData.email || '',
            role: userData.role || 'member',
            bio: userData.bio || '',
            profilePhotoUrl: userData.profilePhotoUrl || '',
            profileComplete: userData.profileComplete || false,
            createdAt: userData.createdAt?.toDate?.()?.toISOString() || userData.createdAt || new Date().toISOString(),
            lastLogin: userData.lastLogin?.toDate?.()?.toISOString() || userData.lastLogin || new Date().toISOString(),
            college: userData.college || 'Campus Connect',
            year: userData.year,
            branch: userData.branch,
            socials: userData.socials || {},
            interests: userData.interests || []
          };
          setUserProfile(p);
          setStatus('success');
        } else if (targetUid === auth.currentUser?.uid) {
          setStatus('success');
          setUserProfile({
            uid: targetUid,
            name: auth.currentUser.displayName || 'User',
            email: auth.currentUser.email || '',
            role: 'member',
            bio: '',
            profilePhotoUrl: auth.currentUser.photoURL || '',
            profileComplete: false,
            createdAt: new Date().toISOString(),
            lastLogin: new Date().toISOString(),
            college: 'Woxsen University'
          });
        } else {
          setStatus('not_found');
        }
      });

      return unsub;
    };

    const unsubProfile = resolveAndFetch();

    return () => {
      isMounted = false;
      if (unsubProfile && typeof unsubProfile === 'function') unsubProfile();
    };
  }, [routeUid, currentUser]);

  // 2.5 Form Initializer (Reliable population without resetting during active edits)
  useEffect(() => {
    if (!userProfile) return;

    // Use a simple check to see if we should sync the form with the profile
    // We sync if:
    // 1. We aren't on the Settings tab (keeps Overview/Socials fresh)
    // 2. OR if the form is currently empty (initial load safety)
    const isFormUninitialized = !settingsForm.name;

    if (isFormUninitialized || activeTab !== 'Settings') {
      setNewName(userProfile.name);
      setSocialsForm({
        linkedin: userProfile.socials?.linkedin || '',
        twitter: userProfile.socials?.twitter || '',
        github: userProfile.socials?.github || '',
        website: userProfile.socials?.website || ''
      });
      setSettingsForm({
        name: userProfile.name,
        bio: userProfile.bio,
        college: userProfile.college,
        year: userProfile.year || '',
        branch: userProfile.branch || '',
        residence_type: (userProfile as any).residence_type || 'Hostel'
      });
    }
  }, [userProfile, activeTab]);

  // 3. Fetch Tab Data
  useEffect(() => {
    if (status !== 'success' || !userProfile?.uid) return;

    const fetchTabData = async () => {
      const isMounted = true;
      setDataLoading(true);
      try {
        const uid = userProfile.uid;
        switch (activeTab) {
          case 'Posts': {
            const q = firestoreQuery(collection(db, 'posts'), where('userId', '==', uid), orderBy('createdAt', 'desc'));
            const snap = await getDocs(q);
            if (isMounted) setPosts(snap.docs.map(d => ({ id: d.id, ...d.data() })));
            break;
          }
          case 'Rides': {
            const q = firestoreQuery(collection(db, 'rides'), where('hostId', '==', uid), orderBy('createdAt', 'desc'));
            const snap = await getDocs(q);
            if (isMounted) setRides(snap.docs.map(d => ({ id: d.id, ...d.data() })));
            break;
          }
          case 'Events': {
            const q = firestoreQuery(collection(db, 'events'), where('organizerId', '==', uid), orderBy('date', 'asc'));
            const snap = await getDocs(q);
            if (isMounted) setEvents(snap.docs.map(d => ({ id: d.id, ...d.data() })));
            break;
          }
          case 'Notes': {
            const q = firestoreQuery(collection(db, 'notes'), where('uploadedBy', '==', uid), orderBy('createdAt', 'desc'));
            const snap = await getDocs(q);
            if (isMounted) setNotes(snap.docs.map(d => ({ id: d.id, ...d.data() })));
            break;
          }
          case 'Saved':
            if (isOwnProfile) {
              const q = firestoreQuery(collection(db, 'users', uid, 'saved'), orderBy('savedAt', 'desc'));
              const snap = await getDocs(q);
              if (isMounted) setSavedItems(snap.docs.map(d => ({ id: d.id, ...d.data() })));
            }
            break;
        }
      } catch (error) {
        console.error("Tab Data Error (RTDB):", error);
      } finally {
        if (isMounted) setDataLoading(false);
      }
    };

    fetchTabData();
  }, [activeTab, userProfile, status]);

  const isOwnProfile = currentUser && userProfile && currentUser.uid === userProfile.uid;

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!isOwnProfile || !e.target.files || !e.target.files[0] || !userProfile) return;
    const file = e.target.files[0];
    setUploading(true);
    try {
      const imgRef = storageRef(storage, `profile-pics/${userProfile.uid}`);
      await uploadBytes(imgRef, file);
      const downloadURL = await getDownloadURL(imgRef);
      await updateDoc(doc(db, 'users', userProfile.uid), { profilePhotoUrl: downloadURL });
      setUserProfile((prev: any) => prev ? ({ ...prev, profilePhotoUrl: downloadURL }) : null);
    } catch (error: any) {
      alert("Upload failed: " + error.message);
    } finally {
      setUploading(false);
    }
  };

  const handleNameUpdate = async () => {
    if (!isOwnProfile || !newName.trim() || !userProfile) return;
    try {
      await updateDoc(doc(db, 'users', userProfile.uid), { name: newName });
      setUserProfile((prev: any) => prev ? ({ ...prev, name: newName }) : null);
      setIsEditingName(false);
    } catch (error: any) {
      alert("Failed update: " + error.message);
    }
  };

  const handleSocialsUpdate = async () => {
    if (!isOwnProfile || !userProfile) return;
    try {
      await updateDoc(doc(db, 'users', userProfile.uid), { socials: socialsForm });
      setUserProfile((prev: any) => prev ? ({ ...prev, socials: socialsForm }) : null);
      setIsEditingSocials(false);
    } catch (error: any) {
      alert("Failed update: " + error.message);
    }
  };

  const handleAddFriend = async () => {
    if (!currentUser || !userProfile || friendStatus !== 'none') return;
    try {
      await addDoc(collection(db, 'friendRequests'), {
        fromUserId: currentUser.uid,
        toUserId: userProfile.uid,
        status: 'pending',
        createdAt: serverTimestamp()
      });
      setFriendStatus('pending');
      alert("Friend request sent!");
    } catch (err: any) {
      alert("Failed to send request: " + err.message);
    }
  };

  const handleMessageUser = () => {
    if (!currentUser || !userProfile) return;
    const chatId = [currentUser.uid, userProfile.uid].sort().join('_');
    navigate(`/chat/${chatId}`);
  };

  const handleDeleteAccount = async () => {
    if (!isOwnProfile || !currentUser) return;
    if (!window.confirm("Irreversible action. Delete account?")) return;
    try {
      setStatus('loading');
      await deleteDoc(doc(db, 'users', currentUser.uid));
      await deleteUser(currentUser);
      navigate('/login');
    } catch (error: any) {
      alert("Failed: " + error.message);
      setStatus('success');
    }
  };

  const handleShareProfile = () => {
    if (!userProfile) return;
    const url = `${window.location.origin}/profile/${userProfile.uid}`;
    navigator.clipboard.writeText(url);
    alert("Profile link copied!");
  };

  if (status === 'loading') {
    return <div className="min-h-screen flex items-center justify-center"><Loader2 className="animate-spin text-[var(--color-primary)]" size={32} /></div>;
  }

  if (status === 'error') {
    return (
      <div className="flex flex-col items-center justify-center min-h-[50vh] text-center p-8">
        <ShieldAlert size={48} className="text-red-500 mb-4" />
        <h2 className="text-xl font-bold mb-2">Something went wrong</h2>
        <p className="text-[var(--color-text-secondary)]">{errorMessage}</p>
        <button onClick={() => window.location.reload()} className="mt-4 text-[var(--color-primary)] font-bold hover:underline">Try Again</button>
      </div>
    );
  }

  if (status === 'not_found' || !userProfile) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[50vh] text-center p-8">
        <div className="w-16 h-16 bg-[var(--color-surface-hover)] rounded-full flex items-center justify-center mb-4">
          <UserIcon size={32} className="text-[var(--color-text-muted)]" />
        </div>
        <h2 className="text-xl font-bold text-[var(--color-text-main)] mb-2">Profile Not Available</h2>
        <p className="text-[var(--color-text-secondary)] max-w-md">
          This user profile could not be found. It may have been deleted or never existed.
        </p>
        <button onClick={() => navigate('/')} className="mt-6 px-4 py-2 bg-[var(--color-primary)] text-white rounded-lg hover:opacity-90 transition-opacity">
          Go Home
        </button>
      </div>
    );
  }

  const tabs = ['Overview', 'Posts', 'Rides', 'Events', 'Notes'];
  if (isOwnProfile) tabs.push('Saved', 'Settings');

  // Avatar Fallback logic (v2): (Photo OR NameInitial) - Name
  const userInitial = userProfile.name.charAt(0).toUpperCase();

  return (
    <div className="profile-container pb-8">
      <div className="profile-header bg-[var(--color-surface)] rounded-2xl overflow-hidden border border-[var(--color-border)] mb-6">
        <div className="h-32 bg-gradient-to-r from-indigo-600 to-purple-600 relative">
          <button onClick={handleShareProfile} className="absolute top-4 right-4 bg-black/30 hover:bg-black/50 text-white px-3 py-1 rounded-full text-xs font-bold transition-colors">
            Share Profile
          </button>
        </div>
        <div className="px-6 pb-6 relative">
          <div className="absolute -top-12 left-6 p-1 bg-[var(--color-surface)] rounded-full">
            <div className="relative w-24 h-24">
              {userProfile.profilePhotoUrl ? (
                <img
                  src={userProfile.profilePhotoUrl}
                  alt={userProfile.name}
                  className="w-full h-full rounded-full object-cover border-4 border-[var(--color-surface)] shadow-md"
                />
              ) : (
                <div className="w-full h-full rounded-full border-4 border-[var(--color-surface)] bg-indigo-500 flex items-center justify-center text-4xl font-bold text-white shadow-md">
                  {userInitial}
                </div>
              )}
              {isOwnProfile && (
                <label className={`absolute bottom-0 right-0 p-2 bg-gray-900/80 rounded-full cursor-pointer hover:bg-black transition-colors ${uploading ? 'opacity-50' : ''}`}>
                  {uploading ? <Loader2 size={16} className="text-white animate-spin" /> : <Camera size={16} className="text-white" />}
                  <input type="file" hidden accept="image/*" onChange={handleImageUpload} disabled={uploading} />
                </label>
              )}
            </div>
          </div>

          <div className="mt-14 sm:mt-4 sm:ml-32 flex flex-col sm:flex-row justify-between items-start gap-4">
            <div>
              <div className="flex items-center gap-3">
                {isEditingName && isOwnProfile ? (
                  <div className="flex items-center gap-2">
                    <input className="bg-[var(--color-bg)] border border-[var(--color-border)] rounded px-2 py-1 font-bold text-[var(--color-text-main)]" value={newName} onChange={e => setNewName(e.target.value)} />
                    <button onClick={handleNameUpdate} className="text-green-500 text-sm font-bold">Save</button>
                    <button onClick={() => setIsEditingName(false)} className="text-red-500 text-sm">Cancel</button>
                  </div>
                ) : (
                  <>
                    <h1 className="text-2xl font-bold text-[var(--color-text-main)]">{userProfile.name}</h1>
                    {isOwnProfile && (
                      <button onClick={() => setIsEditingName(true)} className="text-[var(--color-text-muted)] hover:text-[var(--color-primary)]">
                        <Edit2 size={16} />
                      </button>
                    )}
                  </>
                )}
                <span className="px-2 py-0.5 rounded-full bg-purple-500/10 text-purple-400 text-xs font-bold uppercase">{userProfile.role}</span>
              </div>

              <div className="flex flex-wrap items-center gap-4 mt-2 text-sm text-[var(--color-text-muted)]">
                <div className="flex items-center gap-1"><MapPin size={14} /> {userProfile.college}</div>
                <div className="flex items-center gap-1"><Calendar size={14} /> Joined {userProfile.createdAt ? new Date(userProfile.createdAt).getFullYear() : 'N/A'}</div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              {isOwnProfile ? (
                <button onClick={() => setActiveTab('Settings')} className="px-4 py-2 bg-[var(--color-surface)] border border-[var(--color-border)] rounded-lg hover:bg-[var(--color-surface-hover)] text-sm font-medium transition-colors">
                  Edit Profile
                </button>
              ) : (
                <>
                  <button
                    onClick={handleAddFriend}
                    disabled={friendStatus !== 'none'}
                    className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-bold transition-all shadow-sm ${friendStatus === 'friends' ? 'bg-green-500 text-white cursor-default' :
                      friendStatus === 'pending' ? 'bg-gray-100 text-gray-500 cursor-default' :
                        'bg-indigo-600 text-white hover:bg-indigo-700 active:scale-[0.98]'
                      }`}
                  >
                    {friendStatus === 'friends' ? <UserIcon size={16} /> : <UserPlus size={16} />}
                    {friendStatus === 'friends' ? 'Friends' : friendStatus === 'pending' ? 'Request Pending' : 'Add Friend'}
                  </button>
                  <button onClick={handleMessageUser} className="flex items-center gap-2 px-4 py-2 border border-[var(--color-border)] bg-[var(--color-surface)] rounded-lg text-sm font-bold hover:bg-[var(--color-surface-hover)] active:scale-[0.98] transition-all">
                    <MessageSquare size={16} /> Message
                  </button>
                </>
              )}
            </div>
          </div>
        </div>
      </div>

      <div className="flex gap-1 border-b border-[var(--color-border)] mb-6 overflow-x-auto scroller-hidden">
        {tabs.map(tab => (
          <button
            key={tab}
            className={`px-4 py-3 text-sm font-bold whitespace-nowrap border-b-2 transition-colors ${activeTab === tab ? 'border-purple-500 text-purple-400' : 'border-transparent text-[var(--color-text-secondary)] hover:text-[var(--color-text-main)]'}`}
            onClick={() => setActiveTab(tab)}
          >
            {tab}
          </button>
        ))}
      </div>

      <div className="min-h-[200px] flex flex-col gap-6">
        {dataLoading ? <div className="text-center py-10"><Loader2 className="animate-spin mx-auto text-[var(--color-text-muted)]" /></div> : (
          <>
            {activeTab === 'Overview' && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-[var(--color-surface)] p-6 rounded-2xl border border-[var(--color-border)]">
                  <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
                    <UserIcon size={20} className="text-blue-500" /> About Me
                  </h3>
                  <p className="text-[var(--color-text-secondary)] leading-relaxed">
                    {userProfile.bio || "No bio yet. Tell the campus about yourself!"}
                  </p>
                </div>

                <div className="bg-[var(--color-surface)] p-6 rounded-2xl border border-[var(--color-border)]">
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="text-lg font-bold flex items-center gap-2">
                      <Globe size={20} className="text-green-500" /> Connect
                    </h3>
                    {isOwnProfile && (
                      <button onClick={() => setIsEditingSocials(!isEditingSocials)} className="text-[var(--color-primary)] text-sm font-bold">
                        {isEditingSocials ? 'Cancel' : 'Edit'}
                      </button>
                    )}
                  </div>

                  {isEditingSocials ? (
                    <div className="flex flex-col gap-3">
                      <input placeholder="LinkedIn URL" className="bg-[var(--color-bg)] border border-[var(--color-border)] rounded px-3 py-2 text-sm" value={socialsForm.linkedin} onChange={e => setSocialsForm({ ...socialsForm, linkedin: e.target.value })} />
                      <input placeholder="Twitter URL" className="bg-[var(--color-bg)] border border-[var(--color-border)] rounded px-3 py-2 text-sm" value={socialsForm.twitter} onChange={e => setSocialsForm({ ...socialsForm, twitter: e.target.value })} />
                      <input placeholder="Github URL" className="bg-[var(--color-bg)] border border-[var(--color-border)] rounded px-3 py-2 text-sm" value={socialsForm.github} onChange={e => setSocialsForm({ ...socialsForm, github: e.target.value })} />
                      <input placeholder="Portfolio/Website" className="bg-[var(--color-bg)] border border-[var(--color-border)] rounded px-3 py-2 text-sm" value={socialsForm.website} onChange={e => setSocialsForm({ ...socialsForm, website: e.target.value })} />
                      <button onClick={handleSocialsUpdate} className="bg-[var(--color-primary)] text-white py-2 rounded-lg text-sm font-bold mt-2">Update Socials</button>
                    </div>
                  ) : (
                    <div className="flex flex-col gap-4">
                      {userProfile.socials?.linkedin && <a href={userProfile.socials.linkedin} target="_blank" rel="noreferrer" className="flex items-center gap-3 text-[var(--color-text-secondary)] hover:text-blue-500 transition-colors"><Linkedin size={18} /> LinkedIn</a>}
                      {userProfile.socials?.twitter && <a href={userProfile.socials.twitter} target="_blank" rel="noreferrer" className="flex items-center gap-3 text-[var(--color-text-secondary)] hover:text-blue-400 transition-colors"><Twitter size={18} /> Twitter</a>}
                      {userProfile.socials?.github && <a href={userProfile.socials.github} target="_blank" rel="noreferrer" className="flex items-center gap-3 text-[var(--color-text-secondary)] hover:text-gray-400 transition-colors"><Github size={18} /> GitHub</a>}
                      {userProfile.socials?.website && <a href={userProfile.socials.website} target="_blank" rel="noreferrer" className="flex items-center gap-3 text-[var(--color-text-secondary)] hover:text-purple-400 transition-colors"><Globe size={18} /> Website</a>}
                      {!userProfile.socials?.linkedin && !userProfile.socials?.twitter && !userProfile.socials?.github && !userProfile.socials?.website && (
                        <p className="text-xs text-[var(--color-text-muted)] italic">No social links added yet.</p>
                      )}
                    </div>
                  )}
                </div>
              </div>
            )}

            {activeTab === 'Posts' && (
              <div className="flex flex-col gap-4">
                {posts.length > 0 ? posts.map((p: any) => (
                  <div key={p.id} className="p-4 border border-[var(--color-border)] rounded-2xl bg-[var(--color-surface)] hover:shadow-lg transition-shadow">
                    <h4 className="font-bold mb-1 text-[var(--color-text-main)]">{p.content?.substring(0, 100)}...</h4>
                    <div className="text-xs text-[var(--color-text-muted)]">{p.createdAt ? new Date(p.createdAt).toLocaleDateString() : 'Unknown Date'}</div>
                  </div>
                )) : <div className="text-[var(--color-text-secondary)] italic text-center py-10 bg-[var(--color-surface)] rounded-2xl border border-dashed border-[var(--color-border)]">No posts found.</div>}
              </div>
            )}

            {activeTab === 'Rides' && (
              <div className="flex flex-col gap-4">
                {rides.length > 0 ? rides.map((r: any) => (
                  <div key={r.id} className="p-4 border border-[var(--color-border)] rounded-2xl bg-[var(--color-surface)]">
                    <div className="font-bold text-lg text-[var(--color-text-main)]">{r.from} ➔ {r.to}</div>
                    <div className="text-sm text-[var(--color-text-secondary)] mt-1">
                      {r.date} at {r.time} • ₹{r.fare}
                    </div>
                  </div>
                )) : <div className="text-[var(--color-text-secondary)] italic text-center py-10 bg-[var(--color-surface)] rounded-2xl border border-dashed border-[var(--color-border)]">No rides hosted.</div>}
              </div>
            )}

            {activeTab === 'Events' && (
              <div className="flex flex-col gap-4">
                {events.length > 0 ? events.map((e: any) => (
                  <div key={e.id} className="p-4 border border-[var(--color-border)] rounded-2xl bg-[var(--color-surface)]">
                    <div className="font-bold text-[var(--color-text-main)]">{e.title}</div>
                    <div className="text-sm text-[var(--color-text-secondary)] mt-1">{e.date} • {e.location}</div>
                  </div>
                )) : <div className="text-[var(--color-text-secondary)] italic text-center py-10 bg-[var(--color-surface)] rounded-2xl border border-dashed border-[var(--color-border)]">No events found.</div>}
              </div>
            )}

            {activeTab === 'Notes' && (
              <div className="flex flex-col gap-4">
                {notes.length > 0 ? notes.map((n: any) => (
                  <div key={n.id} className="p-4 border border-[var(--color-border)] rounded-2xl bg-[var(--color-surface)]">
                    <h4 className="font-bold text-[var(--color-text-main)]">{n.title}</h4>
                    <p className="text-sm text-[var(--color-text-secondary)] mt-1">{n.subject}</p>
                  </div>
                )) : <div className="text-[var(--color-text-secondary)] italic text-center py-10 bg-[var(--color-surface)] rounded-2xl border border-dashed border-[var(--color-border)]">No notes uploaded.</div>}
              </div>
            )}

            {activeTab === 'Saved' && isOwnProfile && (
              <div className="flex flex-col gap-4">
                {savedItems.length > 0 ? savedItems.map((s: any) => (
                  <div key={s.id} className="p-4 border border-[var(--color-border)] rounded-2xl bg-[var(--color-surface)] flex justify-between items-center group">
                    <div>
                      <span className="text-xs font-bold uppercase text-[var(--color-primary)] mb-1 block">{s.type}</span>
                      {s.type === 'post' && (
                        <Link to={`/post/${s.itemId}`} className="hover:underline font-medium text-[var(--color-text-main)]">
                          {s.content || 'View Post'}
                        </Link>
                      )}
                      {s.type === 'event' && (
                        <Link to={`/events?id=${s.itemId}`} className="hover:underline font-medium text-[var(--color-text-main)]">
                          {s.title} <span className="text-[var(--color-text-muted)] font-normal text-sm ml-2">({s.date})</span>
                        </Link>
                      )}
                      {s.type === 'ride' && (
                        <Link to={`/rides?id=${s.itemId}`} className="hover:underline font-medium text-[var(--color-text-main)]">
                          {s.from} ➔ {s.to}
                        </Link>
                      )}
                      <div className="text-xs text-[var(--color-text-muted)] mt-1">
                        Saved on {s.savedAt ? new Date(s.savedAt).toLocaleDateString() : 'Unknown Date'}
                      </div>
                    </div>
                    <Link to={s.type === 'post' ? `/post/${s.itemId}` : s.type === 'event' ? `/events?id=${s.itemId}` : `/rides?id=${s.itemId}`} className="p-2 border rounded-full hover:bg-[var(--color-surface-hover)]">
                      ➔
                    </Link>
                  </div>
                )) : <div className="italic text-[var(--color-text-secondary)] text-center py-10 bg-[var(--color-surface)] rounded-2xl border border-dashed border-[var(--color-border)]">No saved items yet.</div>}
              </div>
            )}

            {activeTab === 'Settings' && isOwnProfile && (
              <div className="flex flex-col gap-6">
                {/* Profile Edit Section */}
                <div className="bg-[var(--color-surface)] p-6 rounded-2xl border border-[var(--color-border)]">
                  <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
                    <Edit2 size={20} className="text-indigo-500" /> Edit Profile
                  </h3>
                  <form onSubmit={async (e) => {
                    e.preventDefault();
                    if (!userProfile) return;
                    try {
                      setUploading(true);
                      await updateDoc(doc(db, 'users', userProfile.uid), settingsForm);
                      alert("Profile updated live!");
                    } catch (err: any) {
                      alert("Failed: " + err.message);
                    } finally {
                      setUploading(false);
                    }
                  }} className="space-y-4">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="space-y-1">
                        <label className="text-xs font-bold text-[var(--color-text-muted)] uppercase">Full Name</label>
                        <input
                          className="w-full bg-[var(--color-bg)] border border-[var(--color-border)] rounded-xl px-4 py-2"
                          value={settingsForm.name}
                          onChange={e => setSettingsForm({ ...settingsForm, name: e.target.value })}
                          required
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-xs font-bold text-[var(--color-text-muted)] uppercase">College</label>
                        <input
                          className="w-full bg-[var(--color-bg)] border border-[var(--color-border)] rounded-xl px-4 py-2"
                          value={settingsForm.college}
                          onChange={e => setSettingsForm({ ...settingsForm, college: e.target.value })}
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-1">
                        <label className="text-xs font-bold text-[var(--color-text-muted)] uppercase">Year</label>
                        <select
                          className="w-full bg-[var(--color-bg)] border border-[var(--color-border)] rounded-xl px-4 py-2"
                          value={settingsForm.year}
                          onChange={e => setSettingsForm({ ...settingsForm, year: e.target.value })}
                        >
                          <option value="">Select Year</option>
                          <option value="1">1st Year</option>
                          <option value="2">2nd Year</option>
                          <option value="3">3rd Year</option>
                          <option value="4">4th Year</option>
                          <option value="PG">Post Grad</option>
                        </select>
                      </div>
                      <div className="space-y-1">
                        <label className="text-xs font-bold text-[var(--color-text-muted)] uppercase">Branch</label>
                        <input
                          className="w-full bg-[var(--color-bg)] border border-[var(--color-border)] rounded-xl px-4 py-2"
                          placeholder="e.g. CSE"
                          value={settingsForm.branch}
                          onChange={e => setSettingsForm({ ...settingsForm, branch: e.target.value })}
                        />
                      </div>
                    </div>

                    <div className="space-y-1">
                      <label className="text-xs font-bold text-[var(--color-text-muted)] uppercase">Bio</label>
                      <textarea
                        className="w-full bg-[var(--color-bg)] border border-[var(--color-border)] rounded-xl px-4 py-2"
                        rows={3}
                        value={settingsForm.bio}
                        onChange={e => setSettingsForm({ ...settingsForm, bio: e.target.value })}
                      />
                    </div>

                    <button
                      type="submit"
                      disabled={uploading}
                      className="w-full bg-indigo-600 text-white py-3 rounded-xl font-bold hover:bg-indigo-700 transition-colors disabled:opacity-50"
                    >
                      {uploading ? 'Saving...' : 'Save Changes'}
                    </button>
                  </form>
                </div>

                {/* Social Links Section */}
                <div className="bg-[var(--color-surface)] p-6 rounded-2xl border border-[var(--color-border)]">
                  <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
                    <Globe size={20} className="text-green-500" /> Social Links
                  </h3>
                  <div className="flex flex-col gap-3">
                    <input placeholder="LinkedIn URL" className="bg-[var(--color-bg)] border border-[var(--color-border)] rounded-xl px-4 py-2 text-sm" value={socialsForm.linkedin} onChange={e => setSocialsForm({ ...socialsForm, linkedin: e.target.value })} />
                    <input placeholder="Twitter URL" className="bg-[var(--color-bg)] border border-[var(--color-border)] rounded-xl px-4 py-2 text-sm" value={socialsForm.twitter} onChange={e => setSocialsForm({ ...socialsForm, twitter: e.target.value })} />
                    <input placeholder="Github URL" className="bg-[var(--color-bg)] border border-[var(--color-border)] rounded-xl px-4 py-2 text-sm" value={socialsForm.github} onChange={e => setSocialsForm({ ...socialsForm, github: e.target.value })} />
                    <input placeholder="Portfolio/Website" className="bg-[var(--color-bg)] border border-[var(--color-border)] rounded-xl px-4 py-2 text-sm" value={socialsForm.website} onChange={e => setSocialsForm({ ...socialsForm, website: e.target.value })} />
                    <button onClick={handleSocialsUpdate} className="bg-indigo-600 text-white py-3 rounded-xl text-sm font-bold mt-2">Update Socials</button>
                  </div>
                </div>

                <div className="bg-[var(--color-surface)] p-6 rounded-2xl border border-[var(--color-border)]">
                  <h3 className="text-lg font-bold mb-4 flex items-center gap-2"><SettingsIcon size={20} className="text-purple-500" /> General Preferences</h3>
                  <div className="flex flex-col gap-4">
                    <div className="flex items-center justify-between p-3 bg-[var(--color-bg)] rounded-xl border border-[var(--color-border)]">
                      <div>
                        <div className="font-bold text-[var(--color-text-main)]">Interface Theme</div>
                        <div className="text-xs text-[var(--color-text-muted)]">Switch between light and dark mode</div>
                      </div>
                      <button onClick={toggleTheme} className="p-2 bg-[var(--color-surface)] border border-[var(--color-border)] rounded-lg hover:bg-[var(--color-surface-hover)] transition-colors">
                        {theme === 'dark' ? <Sun size={20} className="text-yellow-500" /> : <Moon size={20} className="text-indigo-500" />}
                      </button>
                    </div>

                    <div className="flex items-center justify-between p-3 bg-[var(--color-bg)] rounded-xl border border-[var(--color-border)] opacity-60">
                      <div>
                        <div className="font-bold text-[var(--color-text-main)]">Email Notifications</div>
                        <div className="text-xs text-[var(--color-text-muted)]">Manage your campus alerts via email</div>
                      </div>
                      <div className="w-10 h-6 bg-gray-300 rounded-full relative cursor-not-allowed">
                        <div className="absolute left-1 top-1 w-4 h-4 bg-white rounded-full"></div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-[var(--color-surface)] p-6 rounded-2xl border border-[var(--color-border)]">
                  <h3 className="text-lg font-bold mb-4 flex items-center gap-2 text-red-500"><ShieldAlert size={20} /> Danger Zone</h3>
                  <p className="text-sm text-[var(--color-text-secondary)] mb-4 leading-relaxed">
                    Permanently delete your Campus Connect account and all associated data. This action is irreversible.
                  </p>
                  <button onClick={handleDeleteAccount} className="px-6 py-2.5 bg-red-500 text-white rounded-xl font-bold hover:bg-red-600 transition-colors shadow-lg shadow-red-500/20">
                    Delete Account
                  </button>
                </div>
              </div>
            )}
          </>
        )}
      </div>

      <style>{`
        .scroller-hidden::-webkit-scrollbar {
          display: none;
        }
        .scroller-hidden {
          -ms-overflow-style: none;
          scrollbar-width: none;
        }
      `}</style>
    </div>
  );
};

export default Profile;
