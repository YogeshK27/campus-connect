import React from 'react';
import { Briefcase } from 'lucide-react';

const Internships: React.FC = () => {
  return (
    <div className="page-container">
      <h1>Internships & Projects</h1>
      <div className="empty-state">
        <Briefcase size={48} />
        <p>No active opportunities right now.</p>
      </div>
      <style>{`
        .empty-state {
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          padding: 4rem;
          color: var(--color-text-muted);
          gap: 1rem;
        }
      `}</style>
    </div>
  );
};

export default Internships;
