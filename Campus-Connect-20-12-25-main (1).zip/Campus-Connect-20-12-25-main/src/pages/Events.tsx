import React, { useState, useEffect } from 'react';
import { MapPin, Clock, Plus, Loader2, Share2, Bookmark } from 'lucide-react';
import { Link } from 'react-router-dom';
import { auth } from '../lib/firebase';
import { onAuthStateChanged } from 'firebase/auth';
import { dbService } from '../services/db.service';
import { useToast } from '../context/ToastContext';

interface Event {
    $id: string;
    title: string;
    description: string;
    date: string;
    time: string;
    location: string;
    organizer: string;
    organizerId: string;
    image?: string;
    interested?: string[]; // Array of UIDs
    isSaved?: boolean; // Client-side logic
}

const Events: React.FC = () => {
    const [events, setEvents] = useState<Event[]>([]);
    const [loading, setLoading] = useState(true);
    const [showCreate, setShowCreate] = useState(false);
    const [currentUser, setCurrentUser] = useState<any>(null);

    const [createForm, setCreateForm] = useState({
        title: '',
        description: '',
        date: '',
        time: '',
        location: ''
    });

    const [savedIds, setSavedIds] = useState<Set<string>>(new Set());

    useEffect(() => {
        const unsubscribe = onAuthStateChanged(auth, (user) => {
            setCurrentUser(user);
        });
        return () => unsubscribe();
    }, []);

    useEffect(() => {
        setLoading(true);
        const unsubscribe = dbService.subscribeToCollection('events', (data) => {
            const fetchedEvents = (data as Event[]).map(e => ({
                ...e,
                interested: e.interested || []
            }));
            const sortedEvents = fetchedEvents.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
            setEvents(sortedEvents);
            setLoading(false);
        });

        return () => unsubscribe();
    }, []);

    useEffect(() => {
        if (currentUser) {
            const unsubscribe = dbService.subscribeToCollection(`users/${currentUser.uid}/saved`, (data) => {
                setSavedIds(new Set(data.map(d => d.itemId)));
            });
            return () => unsubscribe();
        } else {
            setSavedIds(new Set());
        }
    }, [currentUser]);

    const { showToast } = useToast();

    const handleCreate = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!currentUser) return showToast("Please login to create an event", "error");

        try {
            await dbService.createEvent({
                ...createForm,
                organizer: currentUser.displayName || 'Student',
                organizerId: currentUser.uid,
            });
            setShowCreate(false);
            setCreateForm({
                title: '',
                description: '',
                date: '',
                time: '',
                location: ''
            });
            showToast("Event published successfully!", "success");
        } catch (error: any) {
            console.error(error);
            showToast('Failed to create event: ' + error.message, "error");
        }
    };

    const handleInterest = async (event: Event) => {
        if (!currentUser) return showToast("Please login first", "error");
        const isInterested = event.interested?.includes(currentUser.uid);
        try {
            await dbService.toggleEventInterest(event.$id, currentUser.uid, !!isInterested);
            showToast(isInterested ? "Interest removed" : "Added to your interests!", "success");
        } catch (error: any) {
            console.error("Error updating interest (Firestore):", error);
            showToast("Failed to update interest", "error");
        }
    };

    const handleSave = async (event: Event) => {
        if (!currentUser) return showToast("Please login to save", "error");
        const isSaved = savedIds.has(event.$id);

        try {
            await dbService.toggleSaveItem(currentUser.uid, event.$id, 'event', {
                title: event.title,
                date: event.date,
            }, isSaved);
            showToast(isSaved ? "Removed from saved" : "Event saved to profile", "success");
        } catch (error) {
            console.error("Error saving event (Firestore):", error);
            showToast("Failed to save event", "error");
        }
    };

    return (
        <div className="page-container h-full overflow-y-auto pb-20">
            <div className="header-actions">
                <h1>Campus Events</h1>
                <button className="primary-btn" onClick={() => setShowCreate(!showCreate)}>
                    <Plus size={20} /> Create Event
                </button>
            </div>

            {showCreate && (
                <div className="create-card">
                    <h3>New Event</h3>
                    <form onSubmit={handleCreate}>
                        <input type="text" placeholder="Event Title" value={createForm.title} onChange={e => setCreateForm({ ...createForm, title: e.target.value })} required />
                        <textarea placeholder="Description" value={createForm.description} onChange={e => setCreateForm({ ...createForm, description: e.target.value })} rows={3} required />
                        <div className="row">
                            <input type="date" value={createForm.date} onChange={e => setCreateForm({ ...createForm, date: e.target.value })} required />
                            <input type="time" value={createForm.time} onChange={e => setCreateForm({ ...createForm, time: e.target.value })} required />
                        </div>
                        <input type="text" placeholder="Location (e.g. Auditorium)" value={createForm.location} onChange={e => setCreateForm({ ...createForm, location: e.target.value })} required />
                        <button type="submit" className="submit-btn" disabled={!currentUser}>Publish Event</button>
                    </form>
                </div>
            )}

            <div className="events-list">
                {loading ? (
                    <div className="flex justify-center p-8 text-[var(--color-text-muted)]">
                        <Loader2 className="animate-spin" />
                    </div>
                ) : (
                    events.length > 0 ? events.map(event => (
                        <div key={event.$id} className="event-card">
                            <div className="event-date">
                                <span className="day">{new Date(event.date).getDate()}</span>
                                <span className="month">{new Date(event.date).toLocaleString('default', { month: 'short' })}</span>
                            </div>
                            <div className="event-content">
                                <h3>{event.title}</h3>
                                <div className="meta">
                                    <span><Clock size={14} /> {event.time}</span>
                                    <span><MapPin size={14} /> {event.location}</span>
                                </div>
                                <p>{event.description}</p>
                                <div className="organizer">
                                    Organized by <Link to={`/profile/${event.organizerId}`} className="hover:text-[var(--color-primary)] hover:underline font-medium transition-colors">{event.organizer}</Link>
                                </div>
                            </div>
                            <div className="flex flex-col gap-2 items-center">
                                <button
                                    className={`interest-btn ${event.interested?.includes(currentUser?.uid) ? 'active' : ''}`}
                                    onClick={() => handleInterest(event)}
                                >
                                    {event.interested?.includes(currentUser?.uid) ? 'Interested ✓' : 'Interested'}
                                    {event.interested && event.interested.length > 0 && <span className="count">({event.interested.length})</span>}
                                </button>
                                <button
                                    className="p-2 text-[var(--color-text-secondary)] hover:text-[var(--color-primary)] transition-colors rounded-full hover:bg-[var(--color-surface-hover)]"
                                    onClick={() => {
                                        navigator.clipboard.writeText(`${window.location.origin}/events?id=${event.$id}`);
                                        showToast("Event link copied!", "success");
                                    }}
                                    title="Share Event"
                                >
                                    <Share2 size={18} />
                                </button>
                                <button
                                    className={`p-2 transition-colors rounded-full hover:bg-[var(--color-surface-hover)] ${savedIds.has(event.$id) ? 'text-[var(--color-primary)]' : 'text-[var(--color-text-secondary)]'}`}
                                    onClick={() => handleSave(event)}
                                    title={savedIds.has(event.$id) ? "Unsave Event" : "Save Event"}
                                >
                                    <Bookmark size={18} fill={savedIds.has(event.$id) ? "currentColor" : "none"} />
                                </button>
                            </div>
                        </div>
                    )) : (
                        <p className="empty-state">No upcoming events.</p>
                    )
                )}
            </div>

            <style>{`
                .page-container {
                    padding: 1rem;
                    max-width: 800px;
                    margin: 0 auto;
                }
                .header-actions {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    margin-bottom: 2rem;
                }
                h1 { color: var(--color-text-main); font-size: 1.5rem; font-weight: 700; }
                .primary-btn {
                    background: var(--color-primary);
                    color: white;
                    border: none;
                    padding: 0.5rem 1rem;
                    border-radius: var(--radius-md);
                    display: flex;
                    align-items: center;
                    gap: 0.5rem;
                    cursor: pointer;
                }
                .create-card {
                    background: var(--color-surface);
                    padding: 1.5rem;
                    border-radius: var(--radius-lg);
                    margin-bottom: 2rem;
                    border: 1px solid var(--color-border);
                }
                .create-card h3 {
                     margin-bottom: 1rem;
                     color: var(--color-text-main);
                }
                .create-card form {
                    display: flex;
                    flex-direction: column;
                    gap: 1rem;
                }
                .row {
                    display: flex;
                    gap: 1rem;
                }
                input, textarea {
                    padding: 0.5rem;
                    background: var(--color-bg);
                    border: 1px solid var(--color-border);
                    border-radius: var(--radius-md);
                    color: var(--color-text-main);
                    width: 100%;
                }
                .submit-btn {
                    background: var(--color-primary);
                    color: white;
                    padding: 0.75rem;
                    border: none;
                    border-radius: var(--radius-md);
                    cursor: pointer;
                    font-weight: 600;
                }
                .events-list {
                    display: flex;
                    flex-direction: column;
                    gap: 1rem;
                }
                .event-card {
                    background: var(--color-surface);
                    border: 1px solid var(--color-border);
                    border-radius: var(--radius-lg);
                    padding: 1rem;
                    display: flex;
                    gap: 1.5rem;
                    align-items: flex-start;
                }
                .event-date {
                    background: var(--color-surface-hover);
                    padding: 0.5rem 1rem;
                    border-radius: var(--radius-md);
                    display: flex;
                    flex-direction: column;
                    align-items: center;
                    min-width: 60px;
                }
                .day { font-size: 1.5rem; font-weight: 700; color: var(--color-primary); }
                .month { font-size: 0.875rem; color: var(--color-text-muted); text-transform: uppercase; font-weight: 700; }
                .event-content {
                    flex: 1;
                    color: var(--color-text-main);
                }
                .event-content h3 {
                    margin-bottom: 0.5rem;
                    font-size: 1.1rem;
                    font-weight: 800;
                    letter-spacing: -0.02em;
                }
                .meta {
                    display: flex;
                    gap: 1rem;
                    color: var(--color-text-secondary);
                    font-size: 0.8rem;
                    font-weight: 600;
                    margin-bottom: 0.75rem;
                }
                .meta span { display: flex; align-items: center; gap: 0.25rem; }
                .organizer {
                    font-size: 0.75rem;
                    color: var(--color-text-muted);
                    margin-top: 0.5rem;
                    font-medium;
                }
                .interest-btn {
                    background: transparent;
                    border: 1px solid var(--color-border);
                    color: var(--color-text-main);
                    padding: 0.5rem 1.25rem;
                    border-radius: var(--radius-full);
                    cursor: pointer;
                    align-self: center;
                    transition: all 0.2s;
                    display: flex;
                    gap: 0.5rem;
                    align-items: center;
                    font-size: 0.8rem;
                    font-weight: 700;
                }
                .interest-btn:hover {
                    border-color: var(--color-primary);
                    background: var(--color-surface-hover);
                }
                .interest-btn.active {
                    background: var(--color-primary);
                    color: white;
                    border-color: var(--color-primary);
                    box-shadow: 0 4px 12px rgba(99, 102, 241, 0.3);
                }
                .count {
                    font-size: 0.8rem;
                    opacity: 0.8;
                }
                .empty-state {
                    text-align: center;
                    color: var(--color-text-muted);
                    padding: 2rem;
                }
            `}</style>
        </div >
    );
};

export default Events;
