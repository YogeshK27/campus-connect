import React, { useState, useEffect } from 'react';
import { Calendar, Clock, Plus, Loader2, Share2, Bookmark, Navigation, CheckCircle, X, Users } from 'lucide-react';
import { Link } from 'react-router-dom';
import { auth } from '../lib/firebase';
import { onAuthStateChanged } from 'firebase/auth';
import { dbService } from '../services/db.service';
import { toDate } from '../utils/date.utils';
import { useToast } from '../context/ToastContext';

interface Ride {
    $id: string;
    hostId: string;
    rideType: 'request' | 'offer';
    from: string;
    to: string;
    date: string;
    time: string;
    totalSeats: number;
    availableSeats: number;
    fare: number;
    notes?: string;
    participants: string[];
    passengers: { uid: string; name: string; photoURL?: string }[];
    status: 'open' | 'ongoing' | 'completed' | 'canceled';
    hostName: string;
    carModel?: string;
    createdAt: any;
}

const RideSharing: React.FC = () => {
    const [rides, setRides] = useState<Ride[]>([]);
    const [loading, setLoading] = useState(true);
    const [showCreate, setShowCreate] = useState(false);
    const [currentUser, setCurrentUser] = useState<any>(null);

    const [createForm, setCreateForm] = useState({
        rideType: 'offer' as 'offer' | 'request',
        from: '',
        to: '',
        date: new Date().toISOString().split('T')[0],
        time: '',
        seats: 3,
        price: 0,
        notes: '',
        carModel: ''
    });

    const [savedIds, setSavedIds] = useState<Set<string>>(new Set());

    useEffect(() => {
        const unsubscribe = onAuthStateChanged(auth, (user) => {
            setCurrentUser(user);
        });
        return () => unsubscribe();
    }, []);

    useEffect(() => {
        if (currentUser) {
            const unsubscribe = dbService.subscribeToCollection(`users/${currentUser.uid}/saved`, (data) => {
                setSavedIds(new Set(data.map(d => d.itemId)));
            });
            return () => unsubscribe();
        } else {
            setSavedIds(new Set());
        }
    }, [currentUser]);

    useEffect(() => {
        setLoading(true);
        const unsubscribe = dbService.subscribeToCollection('rides', (data) => {
            setRides((data as Ride[]).filter(r => r.status !== 'canceled'));
            setLoading(false);
        });

        return () => unsubscribe();
    }, []);

    const { showToast } = useToast();

    const handleSave = async (ride: Ride) => {
        if (!currentUser) return showToast("Please login to save", "error");
        const isSaved = savedIds.has(ride.$id);

        try {
            await dbService.toggleSaveItem(currentUser.uid, ride.$id, 'ride', {
                from: ride.from,
                to: ride.to,
            }, isSaved);
            showToast(isSaved ? "Removed from saved" : "Ride saved to profile", "success");
        } catch (error) {
            console.error("Error saving ride (Firestore):", error);
            showToast("Failed to save ride", "error");
        }
    };

    const handleCreate = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!currentUser) return showToast("Please login first", "error");

        try {
            const seats = Number(createForm.seats);
            await dbService.createRide({
                hostId: currentUser.uid,
                hostName: currentUser.displayName || 'Campus User',
                rideType: createForm.rideType,
                from: createForm.from,
                to: createForm.to,
                date: createForm.date,
                time: createForm.time,
                totalSeats: seats,
                availableSeats: seats,
                fare: Number(createForm.price),
                notes: createForm.notes,
                carModel: createForm.carModel,
                passengers: [],
                status: 'open'
            });

            setShowCreate(false);
            setCreateForm({
                rideType: 'offer',
                from: '',
                to: '',
                date: new Date().toISOString().split('T')[0],
                time: '',
                seats: 3,
                price: 0,
                notes: '',
                carModel: ''
            });
            showToast("Ride posted successfully!", "success");
        } catch (error: any) {
            console.error(error);
            showToast('Failed to create ride: ' + error.message, "error");
        }
    };

    const handleJoin = async (ride: Ride) => {
        if (!currentUser) return showToast("Please login to join", "error");
        if (ride.availableSeats <= 0) return showToast("No seats available", "error");
        if (ride.hostId === currentUser.uid) return showToast("You cannot join your own ride", "error");
        if (ride.participants.includes(currentUser.uid)) return showToast("You already joined this ride", "info");

        if (!confirm(`Confirm join usage for ₹${ride.fare}?`)) return;

        try {
            const passengerInfo = {
                uid: currentUser.uid,
                name: currentUser.displayName || 'User',
                photoURL: currentUser.photoURL || ''
            };

            await dbService.joinRide(ride.$id, currentUser.uid, passengerInfo);
            showToast("Joined successfully!", "success");
        } catch (error: any) {
            console.error(error);
            showToast("Failed to join: " + error.message, "error");
        }
    };

    const handleLeave = async (ride: Ride) => {
        if (!currentUser) return;
        if (!confirm("Are you sure you want to leave this ride?")) return;

        try {
            const passengerInfo = ride.passengers.find(p => p.uid === currentUser.uid);
            if (!passengerInfo) return;

            await dbService.leaveRide(ride.$id, currentUser.uid, passengerInfo);
            showToast("You have left the ride.", "info");
        } catch (error: any) {
            console.error(error);
            showToast("Failed to leave: " + error.message, "error");
        }
    };

    const updateStatus = async (rideId: string, newStatus: Ride['status'] | 'canceled') => {
        try {
            if (newStatus === 'canceled') {
                await dbService.deleteRide(rideId); // Or update status to canceled
                showToast("Ride canceled", "info");
            } else {
                await dbService.updateRide(rideId, { status: newStatus });
                showToast(`Ride status: ${newStatus}`, "success");
            }
        } catch (err: any) {
            showToast("Failed to update status: " + err.message, "error");
        }
    };

    return (
        <div className="max-w-4xl mx-auto px-4 py-8 pb-24">
            <div className="flex justify-between items-center mb-8">
                <div>
                    <h1 className="text-3xl font-black text-[var(--color-text-main)] italic tracking-tight uppercase">RIDES</h1>
                    <p className="text-[var(--color-text-secondary)] text-sm font-medium">Split fares, find your way.</p>
                </div>
                <button
                    onClick={() => setShowCreate(!showCreate)}
                    className="bg-[var(--color-primary)] text-white px-6 py-3 rounded-2xl font-bold shadow-lg shadow-indigo-500/20 hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center gap-2"
                >
                    {showCreate ? <X size={20} /> : <Plus size={20} />}
                    {showCreate ? 'Close' : 'Offer / Request'}
                </button>
            </div>

            {showCreate && (
                <div className="bg-[var(--color-surface)] border border-[var(--color-border)] rounded-3xl p-6 mb-8 shadow-xl animate-in fade-in slide-in-from-top-4 duration-300">
                    <div className="flex gap-2 mb-6 p-1 bg-[var(--color-bg)] rounded-2xl w-fit">
                        <button
                            onClick={() => setCreateForm({ ...createForm, rideType: 'offer' })}
                            className={`px-6 py-2 rounded-xl text-sm font-bold transition-all ${createForm.rideType === 'offer' ? 'bg-[var(--color-primary)] text-white shadow-md' : 'text-[var(--color-text-secondary)] hover:text-[var(--color-text-main)]'}`}
                        >
                            Offering
                        </button>
                        <button
                            onClick={() => setCreateForm({ ...createForm, rideType: 'request' })}
                            className={`px-6 py-2 rounded-xl text-sm font-bold transition-all ${createForm.rideType === 'request' ? 'bg-[var(--color-primary)] text-white shadow-md' : 'text-[var(--color-text-secondary)] hover:text-[var(--color-text-main)]'}`}
                        >
                            Requesting
                        </button>
                    </div>

                    <form onSubmit={handleCreate} className="space-y-4">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div className="space-y-1">
                                <label className="text-xs font-bold text-[var(--color-text-muted)] uppercase px-1">From</label>
                                <input
                                    className="w-full bg-[var(--color-bg)] border border-[var(--color-border)] rounded-2xl px-4 py-3 text-[var(--color-text-main)] focus:ring-2 ring-[var(--color-primary)] outline-none transition-all"
                                    placeholder="Campus Main Gate"
                                    value={createForm.from}
                                    onChange={e => setCreateForm({ ...createForm, from: e.target.value })}
                                    required
                                />
                            </div>
                            <div className="space-y-1">
                                <label className="text-xs font-bold text-[var(--color-text-muted)] uppercase px-1">To</label>
                                <input
                                    className="w-full bg-[var(--color-bg)] border border-[var(--color-border)] rounded-2xl px-4 py-3 text-[var(--color-text-main)] focus:ring-2 ring-[var(--color-primary)] outline-none transition-all"
                                    placeholder="City Center"
                                    value={createForm.to}
                                    onChange={e => setCreateForm({ ...createForm, to: e.target.value })}
                                    required
                                />
                            </div>
                        </div>

                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                            <div className="space-y-1">
                                <label className="text-xs font-bold text-[var(--color-text-muted)] uppercase px-1">Date</label>
                                <input type="date" className="w-full bg-[var(--color-bg)] border border-[var(--color-border)] rounded-2xl px-4 py-3 text-sm" value={createForm.date} onChange={e => setCreateForm({ ...createForm, date: e.target.value })} required />
                            </div>
                            <div className="space-y-1">
                                <label className="text-xs font-bold text-[var(--color-text-muted)] uppercase px-1">Time</label>
                                <input type="time" className="w-full bg-[var(--color-bg)] border border-[var(--color-border)] rounded-2xl px-4 py-3 text-sm" value={createForm.time} onChange={e => setCreateForm({ ...createForm, time: e.target.value })} required />
                            </div>
                            <div className="space-y-1">
                                <label className="text-xs font-bold text-[var(--color-text-muted)] uppercase px-1">
                                    {createForm.rideType === 'offer' ? 'Available Seats' : 'Seats Needed'}
                                </label>
                                <input type="number" min="1" max="10" className="w-full bg-[var(--color-bg)] border border-[var(--color-border)] rounded-2xl px-4 py-3 text-sm" value={createForm.seats} onChange={e => setCreateForm({ ...createForm, seats: Number(e.target.value) })} required />
                            </div>
                            <div className="space-y-1">
                                <label className="text-xs font-bold text-[var(--color-text-muted)] uppercase px-1">
                                    {createForm.rideType === 'offer' ? 'Fare / Seat (₹)' : 'Max Budget (₹)'}
                                </label>
                                <input type="number" min="0" className="w-full bg-[var(--color-bg)] border border-[var(--color-border)] rounded-2xl px-4 py-3 text-sm" value={createForm.price} onChange={e => setCreateForm({ ...createForm, price: Number(e.target.value) })} required />
                            </div>
                        </div>

                        <div className={`grid grid-cols-1 ${createForm.rideType === 'offer' ? 'md:grid-cols-2' : ''} gap-4`}>
                            {createForm.rideType === 'offer' && (
                                <input
                                    className="w-full bg-[var(--color-bg)] border border-[var(--color-border)] rounded-2xl px-4 py-3 text-sm"
                                    placeholder="Car Model (e.g. White Swift - KA01...)"
                                    value={createForm.carModel}
                                    onChange={e => setCreateForm({ ...createForm, carModel: e.target.value })}
                                />
                            )}
                            <input
                                className="w-full bg-[var(--color-bg)] border border-[var(--color-border)] rounded-2xl px-4 py-3 text-sm"
                                placeholder={createForm.rideType === 'offer' ? "Additional notes..." : "Requirements or any specific notes..."}
                                value={createForm.notes}
                                onChange={e => setCreateForm({ ...createForm, notes: e.target.value })}
                            />
                        </div>

                        <button
                            type="submit"
                            className="w-full bg-[var(--color-primary)] text-white py-4 rounded-2xl font-black text-lg shadow-xl shadow-indigo-500/20 hover:opacity-90 active:scale-[0.99] transition-all uppercase tracking-widest"
                        >
                            Post Ride
                        </button>
                    </form>
                </div>
            )}

            <div className="grid grid-cols-1 gap-4">
                {loading ? (
                    <div className="flex flex-col items-center justify-center py-20 gap-4">
                        <Loader2 className="animate-spin text-[var(--color-primary)]" size={40} />
                        <p className="text-[var(--color-text-muted)] font-medium">Fetching the best routes...</p>
                    </div>
                ) : (
                    rides.length > 0 ? rides.map(ride => {
                        const isHost = currentUser?.uid === ride.hostId;
                        const isJoined = currentUser && ride.participants.includes(currentUser.uid);
                        const isFull = ride.availableSeats <= 0;

                        return (
                            <div key={ride.$id} className="group bg-[var(--color-surface)] border border-[var(--color-border)] rounded-3xl p-6 hover:shadow-2xl hover:border-[var(--color-primary)] hover:shadow-indigo-500/5 transition-all duration-300 relative overflow-hidden">
                                {ride.status === 'ongoing' && (
                                    <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-green-500 via-emerald-500 to-green-500 animate-pulse"></div>
                                )}

                                <div className="flex flex-col md:flex-row gap-6">
                                    <div className="flex-1 space-y-4">
                                        <div className="flex items-center justify-between">
                                            <div className="flex items-center gap-2">
                                                <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-tighter ${ride.rideType === 'offer' ? 'bg-indigo-500/10 text-indigo-500' : 'bg-orange-500/10 text-orange-500'}`}>
                                                    {ride.rideType === 'offer' ? 'Offering' : 'Requesting'}
                                                </span>
                                                {ride.status === 'ongoing' && (
                                                    <span className="flex items-center gap-1 px-3 py-1 rounded-full bg-green-500/10 text-green-500 text-[10px] font-black uppercase tracking-tighter">
                                                        <div className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse"></div> Ongoing
                                                    </span>
                                                )}
                                                {ride.status === 'completed' && (
                                                    <span className="px-3 py-1 rounded-full bg-gray-500/10 text-gray-500 text-[10px] font-black uppercase tracking-tighter">
                                                        Completed
                                                    </span>
                                                )}
                                            </div>
                                            <div className="flex items-center gap-3">
                                                <button onClick={() => handleSave(ride)} className={`p-2 rounded-xl transition-all ${savedIds.has(ride.$id) ? 'bg-indigo-500/10 text-indigo-500' : 'bg-[var(--color-bg)] text-[var(--color-text-muted)] hover:text-indigo-500'}`}>
                                                    <Bookmark size={18} fill={savedIds.has(ride.$id) ? "currentColor" : "none"} />
                                                </button>
                                                <button
                                                    onClick={() => {
                                                        navigator.clipboard.writeText(`${window.location.origin}/rides?id=${ride.$id}`);
                                                        showToast("Link copied!", "success");
                                                    }}
                                                    className="p-2 rounded-xl bg-[var(--color-bg)] text-[var(--color-text-muted)] hover:text-indigo-500 transition-all"
                                                >
                                                    <Share2 size={18} />
                                                </button>
                                            </div>
                                        </div>

                                        <div className="flex items-center gap-4">
                                            <div className="flex flex-col items-center gap-1">
                                                <div className="w-2.5 h-2.5 rounded-full border-2 border-indigo-500"></div>
                                                <div className="w-0.5 h-8 border-l border-dashed border-indigo-200"></div>
                                                <div className="w-2.5 h-2.5 rounded-full bg-indigo-500"></div>
                                            </div>
                                            <div className="flex-1">
                                                <h3 className="text-xl font-black text-[var(--color-text-main)] leading-none mb-4">{ride.from}</h3>
                                                <h3 className="text-xl font-black text-[var(--color-text-main)] leading-none">{ride.to}</h3>
                                            </div>
                                        </div>

                                        <div className="flex flex-wrap items-center gap-4 text-xs font-bold text-[var(--color-text-secondary)]">
                                            <div className="flex items-center gap-1.5 py-2 px-3 bg-[var(--color-bg)] rounded-xl"><Calendar size={14} /> {toDate(ride.date).toLocaleDateString()}</div>
                                            <div className="flex items-center gap-1.5 py-2 px-3 bg-[var(--color-bg)] rounded-xl"><Clock size={14} /> {ride.time}</div>
                                            <div className="flex items-center gap-1.5 py-2 px-3 bg-[var(--color-bg)] rounded-xl">
                                                <Users size={14} /> {ride.availableSeats} / {ride.totalSeats} seats
                                            </div>
                                        </div>

                                        {(ride.carModel || ride.notes) && (
                                            <div className="space-y-2 pt-2">
                                                {ride.carModel && (
                                                    <div className="flex items-center gap-2 text-xs font-medium text-[var(--color-text-secondary)] bg-[var(--color-surface-hover)] p-3 rounded-2xl border border-[var(--color-border)]">
                                                        <Navigation size={14} className="text-[var(--color-primary)]" />
                                                        <span><span className="font-bold text-[var(--color-text-main)]">Car:</span> {ride.carModel}</span>
                                                    </div>
                                                )}
                                                {ride.notes && (
                                                    <div className="text-xs text-[var(--color-text-muted)] italic px-1">
                                                        "{ride.notes}"
                                                    </div>
                                                )}
                                            </div>
                                        )}

                                        {ride.passengers && ride.passengers.length > 0 && (
                                            <div className="pt-2">
                                                <p className="text-[10px] font-black uppercase text-[var(--color-text-muted)] mb-2">Participants</p>
                                                <div className="flex -space-x-2">
                                                    {ride.passengers.map((p) => (
                                                        <Link key={p.uid} to={`/profile/${p.uid}`} className="relative group/avatar">
                                                            {p.photoURL ? (
                                                                <img src={p.photoURL} alt={p.name} className="w-8 h-8 rounded-full border-2 border-[var(--color-surface)] object-cover shadow-sm" />
                                                            ) : (
                                                                <div className="w-8 h-8 rounded-full border-2 border-[var(--color-surface)] bg-indigo-500 flex items-center justify-center text-[10px] text-white font-bold shadow-sm">
                                                                    {p.name.charAt(0)}
                                                                </div>
                                                            )}
                                                            <div className="absolute -bottom-10 left-1/2 -translate-x-1/2 bg-black text-white text-[10px] px-2 py-1 rounded opacity-0 group-hover/avatar:opacity-100 transition-opacity whitespace-nowrap z-10 pointer-events-none">
                                                                {p.name}
                                                            </div>
                                                        </Link>
                                                    ))}
                                                </div>
                                            </div>
                                        )}
                                    </div>

                                    <div className="md:w-48 flex flex-col justify-between items-end border-t md:border-t-0 md:border-l border-[var(--color-border)] pt-4 md:pt-0 md:pl-6">
                                        <div className="text-right">
                                            <div className="text-[10px] font-black uppercase text-[var(--color-text-muted)] mb-1">Fare / Seat</div>
                                            <div className="text-3xl font-black text-indigo-500">₹{ride.fare}</div>
                                        </div>

                                        <div className="w-full space-y-2 mt-4">
                                            {isHost ? (
                                                <div className="flex flex-col gap-2">
                                                    {ride.status === 'open' && (
                                                        <button
                                                            onClick={() => updateStatus(ride.$id, 'ongoing')}
                                                            className="w-full bg-green-500 text-white py-3 rounded-2xl font-black text-xs uppercase tracking-wider hover:bg-green-600 transition-all flex items-center justify-center gap-2"
                                                        >
                                                            <Navigation size={14} /> Start Ride
                                                        </button>
                                                    )}
                                                    {ride.status === 'ongoing' && (
                                                        <button
                                                            onClick={() => updateStatus(ride.$id, 'completed')}
                                                            className="w-full bg-indigo-600 text-white py-3 rounded-2xl font-black text-xs uppercase tracking-wider hover:bg-indigo-700 transition-all flex items-center justify-center gap-2"
                                                        >
                                                            <CheckCircle size={14} /> End Ride
                                                        </button>
                                                    )}
                                                    <button
                                                        onClick={async () => {
                                                            if (confirm("Delete this ride permanently?")) {
                                                                await updateStatus(ride.$id, 'canceled');
                                                            }
                                                        }}
                                                        className="w-full py-2 text-red-500 text-[10px] font-black uppercase tracking-widest hover:bg-red-500/10 rounded-xl transition-all"
                                                    >
                                                        Cancel / Delete
                                                    </button>
                                                </div>
                                            ) : isJoined ? (
                                                <button
                                                    onClick={() => handleLeave(ride)}
                                                    className="w-full py-3 border-2 border-red-500/20 text-red-500 rounded-2xl font-black text-xs uppercase tracking-wider hover:bg-red-500/[0.02] transition-all"
                                                >
                                                    Leave Ride
                                                </button>
                                            ) : (
                                                <button
                                                    disabled={isFull || ride.status !== 'open'}
                                                    onClick={() => handleJoin(ride)}
                                                    className={`w-full py-3 rounded-2xl font-black text-xs uppercase tracking-wider transition-all ${isFull || ride.status !== 'open'
                                                        ? 'bg-[var(--color-surface-hover)] text-[var(--color-text-muted)] cursor-not-allowed'
                                                        : 'bg-indigo-600 text-white hover:shadow-lg hover:shadow-indigo-500/30'
                                                        }`}
                                                >
                                                    {ride.status !== 'open' ? 'Not Open' : isFull ? 'Full' : 'Join Ride'}
                                                </button>
                                            )}

                                            <div className="pt-2 text-[10px] font-medium text-[var(--color-text-muted)] text-center">
                                                Hosted by <Link to={`/profile/${ride.hostId}`} className="text-indigo-500 hover:underline">{isHost ? 'You' : ride.hostName}</Link>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        );
                    }) : (
                        <div className="flex flex-col items-center justify-center py-20 bg-[var(--color-surface)] border-2 border-dashed border-[var(--color-border)] rounded-3xl opacity-60">
                            <Navigation size={48} className="text-[var(--color-text-muted)] mb-4" />
                            <p className="text-[var(--color-text-main)] font-black uppercase tracking-widest text-lg">No Rides Found</p>
                            <p className="text-[var(--color-text-muted)] text-sm">Be the first to offer or request a trip!</p>
                        </div>
                    )
                )}
            </div>
        </div>
    );
};

export default RideSharing;
