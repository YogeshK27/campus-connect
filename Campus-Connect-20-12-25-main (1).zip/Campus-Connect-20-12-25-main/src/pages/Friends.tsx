import React, { useState, useEffect } from 'react';
import { UserPlus, Check, X, Loader2, MessageSquare, ShieldAlert } from 'lucide-react';
import { dbService } from '../services/db.service';
import { auth } from '../lib/firebase';
import { onAuthStateChanged } from 'firebase/auth';
import { Link, useNavigate } from 'react-router-dom';

interface FriendRequest {
    id: string;
    fromUserId: string;
    toUserId: string;
    status: 'pending' | 'accepted' | 'rejected';
    senderData?: any;
}

interface Friend {
    uid: string;
    name: string;
    photoURL?: string;
}

const Friends: React.FC = () => {
    const navigate = useNavigate();
    const [currentUser, setCurrentUser] = useState<any>(null);
    const [requests, setRequests] = useState<FriendRequest[]>([]);
    const [friends, setFriends] = useState<Friend[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const unsubscribe = onAuthStateChanged(auth, (user) => {
            setCurrentUser(user);
        });
        return () => unsubscribe();
    }, []);

    useEffect(() => {
        if (!currentUser) return;

        // 1. Listen for Incoming Pending Requests
        const unsubRequests = dbService.subscribeToFriendRequests(currentUser.uid, async (reqs) => {
            const pendingReqs = reqs.filter(r => r.status === 'pending');
            const enriched = await Promise.all(pendingReqs.map(async (req) => {
                const userData = await dbService.getUser(req.fromUserId);
                return { ...req, senderData: userData };
            }));
            setRequests(enriched);
        });

        // 2. Load Friends
        const fetchFriends = async () => {
            const friendUids = await dbService.getFriends(currentUser.uid);
            const friendList = await Promise.all(friendUids.map(async (fuid) => {
                const userData = await dbService.getUser(fuid);
                return {
                    uid: fuid,
                    name: userData?.name || 'User',
                    photoURL: userData?.profilePhotoUrl
                };
            }));
            setFriends(friendList);
            setLoading(false);
        };
        fetchFriends();

        return () => unsubRequests();
    }, [currentUser]);

    const handleAccept = async (reqId: string) => {
        try {
            await dbService.updateFriendRequest(reqId, 'accepted');
            // Re-fetch friends simplified - in a real app, use a subscription
            const friendUids = await dbService.getFriends(currentUser.uid);
            const friendList = await Promise.all(friendUids.map(async (fuid) => {
                const userData = await dbService.getUser(fuid);
                return {
                    uid: fuid,
                    name: userData?.name || 'User',
                    photoURL: userData?.profilePhotoUrl
                };
            }));
            setFriends(friendList);
        } catch (err: any) {
            alert("Error (Firestore): " + err.message);
        }
    };

    const handleReject = async (reqId: string) => {
        try {
            await dbService.updateFriendRequest(reqId, 'rejected');
        } catch (err: any) {
            alert("Error (Firestore): " + err.message);
        }
    };

    const handleMessage = (uid: string) => {
        const chatId = [currentUser.uid, uid].sort().join('_');
        navigate(`/chat/${chatId}`);
    };

    if (!currentUser) {
        return (
            <div className="flex flex-col items-center justify-center py-20">
                <ShieldAlert className="text-red-500 mb-4" size={48} />
                <h2 className="text-xl font-bold">Please Login</h2>
                <p className="text-[var(--color-text-secondary)]">You need to be signed in to manage friends.</p>
                <Link to="/login" className="mt-4 text-indigo-500 font-bold hover:underline">Go to Login</Link>
            </div>
        );
    }

    return (
        <div className="max-w-2xl mx-auto px-4 py-8 pb-20">
            <h1 className="text-3xl font-black italic tracking-tighter mb-8">SOCIAL</h1>

            {/* Requests Section */}
            {requests.length > 0 && (
                <div className="mb-10">
                    <h2 className="text-xs font-black uppercase tracking-widest text-[var(--color-text-muted)] mb-4 px-2">Pending Requests ({requests.length})</h2>
                    <div className="flex flex-col gap-3">
                        {requests.map(req => (
                            <div key={req.id} className="bg-[var(--color-surface)] border border-[var(--color-border)] rounded-2xl p-4 flex items-center justify-between shadow-sm animate-in fade-in zoom-in duration-300">
                                <div className="flex items-center gap-4">
                                    <div className="w-12 h-12 rounded-full border-2 border-[var(--color-bg)] overflow-hidden bg-indigo-500 flex items-center justify-center text-white font-bold">
                                        {req.senderData?.profilePhotoUrl ? (
                                            <img src={req.senderData.profilePhotoUrl} className="w-full h-full object-cover" alt="" />
                                        ) : req.senderData?.name?.charAt(0)}
                                    </div>
                                    <div>
                                        <div className="font-bold text-[var(--color-text-main)]">{req.senderData?.name || 'Someone'}</div>
                                        <div className="text-xs text-[var(--color-text-muted)]">Wants to be your friend</div>
                                    </div>
                                </div>
                                <div className="flex gap-2">
                                    <button onClick={() => handleAccept(req.id)} className="w-10 h-10 bg-green-500 text-white rounded-full flex items-center justify-center hover:scale-110 active:scale-90 transition-all shadow-md shadow-green-500/20">
                                        <Check size={20} />
                                    </button>
                                    <button onClick={() => handleReject(req.id)} className="w-10 h-10 bg-red-500 text-white rounded-full flex items-center justify-center hover:scale-110 active:scale-90 transition-all shadow-md shadow-red-500/20">
                                        <X size={20} />
                                    </button>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            )}

            {/* Friends List */}
            <div>
                <h2 className="text-xs font-black uppercase tracking-widest text-[var(--color-text-muted)] mb-4 px-2">Friends List</h2>
                {loading ? (
                    <div className="flex justify-center p-10"><Loader2 className="animate-spin text-[var(--color-primary)]" /></div>
                ) : friends.length > 0 ? (
                    <div className="grid grid-cols-1 gap-3">
                        {friends.map(friend => (
                            <div key={friend.uid} className="bg-[var(--color-surface)] border border-[var(--color-border)] rounded-2xl p-4 flex items-center justify-between hover:border-indigo-500/50 transition-all">
                                <Link to={`/profile/${friend.uid}`} className="flex items-center gap-4 flex-1">
                                    <div className="w-12 h-12 rounded-full border-2 border-[var(--color-bg)] overflow-hidden bg-indigo-500 flex items-center justify-center text-white font-bold">
                                        {friend.photoURL ? (
                                            <img src={friend.photoURL} className="w-full h-full object-cover" alt="" />
                                        ) : friend.name.charAt(0)}
                                    </div>
                                    <div>
                                        <div className="font-bold text-[var(--color-text-main)]">{friend.name}</div>
                                        <div className="text-xs text-green-500 font-bold uppercase tracking-tighter">Active Friend</div>
                                    </div>
                                </Link>
                                <button onClick={() => handleMessage(friend.uid)} className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-xl text-sm font-bold hover:bg-indigo-700 active:scale-[0.98] transition-all">
                                    <MessageSquare size={16} /> Message
                                </button>
                            </div>
                        ))}
                    </div>
                ) : (
                    <div className="text-center py-20 opacity-50 border-2 border-dashed border-[var(--color-border)] rounded-3xl">
                        <UserPlus size={48} className="mx-auto mb-4 text-[var(--color-text-muted)]" />
                        <p className="font-bold text-[var(--color-text-main)]">NO FRIENDS YET</p>
                        <p className="text-xs mt-1">Visit profiles to send requests!</p>
                    </div>
                )}
            </div>
        </div>
    );
};

export default Friends;
