import React, { useState } from 'react';
import { AlertTriangle, Mail, Lock, ArrowRight } from 'lucide-react';
import { signInWithPopup, signInWithEmailAndPassword } from 'firebase/auth';
import { auth, googleProvider } from '../../lib/firebase';
import { useNavigate, Link } from 'react-router-dom';
import { dbService } from '../../services/db.service';
import { useToast } from '../../context/ToastContext';
import christmasBg from '../../assets/christmas_auth_bg.png';
import campusLogo from '../../assets/campus_connect_icon.png';

const Login: React.FC = () => {
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const navigate = useNavigate();
    const { showToast } = useToast();

    const handleEmailLogin = async (e: React.FormEvent) => {
        e.preventDefault();
        setLoading(true);
        setError('');
        try {
            await signInWithEmailAndPassword(auth, email, password);
            showToast("Logged in successfully!", "success");
            navigate('/');
        } catch (err: any) {
            console.error(err);
            setError('Invalid email or password. Please try again.');
        } finally {
            setLoading(false);
        }
    };

    const handleGoogleLogin = async () => {
        setLoading(true);
        setError('');
        try {
            const result = await signInWithPopup(auth, googleProvider);
            const user = result.user;

            await dbService.createUser(user.uid, {
                email: user.email,
                name: user.displayName,
                profilePhotoUrl: user.photoURL,
            });
            showToast("Logged in successfully!", "success");
            navigate('/');
        } catch (err: any) {
            console.error(err);
            setError('Failed to sign in with Google.');
            showToast("Google login failed", "error");
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="min-h-screen flex flex-col md:flex-row bg-[#F8FAFC]">
            {/* Left Side - Christmas Sidebar */}
            <div className="w-full md:w-5/12 christmas-sidebar flex flex-col justify-center p-8 md:p-16 text-white min-h-[40vh] md:min-h-screen relative overflow-hidden">
                <div className="christmas-overlay" />

                <div className="absolute inset-0 z-0 opacity-40">
                    <img src={christmasBg} className="w-full h-full object-cover" alt="Festive Campus" />
                </div>

                <div className="relative z-10 space-y-8">
                    <div className="inline-flex items-center gap-3 px-4 py-2 rounded-2xl bg-white/10 border border-white/20 backdrop-blur-md shadow-xl animate-float">
                        <div className="flex gap-1.5">
                            <div className="w-2.5 h-2.5 rounded-full bg-[#4285F4]"></div>
                            <div className="w-2.5 h-2.5 rounded-full bg-[#EA4335]"></div>
                            <div className="w-2.5 h-2.5 rounded-full bg-[#FBBC05]"></div>
                            <div className="w-2.5 h-2.5 rounded-full bg-[#34A853]"></div>
                        </div>
                        <span className="text-xs font-bold tracking-widest uppercase text-white/90">Google Agentathon Project</span>
                    </div>

                    <div className="space-y-4">
                        <div className="flex items-center gap-4">
                            <img src={campusLogo} className="w-14 h-14" alt="Logo" />
                            <h2 className="text-3xl font-black italic tracking-tighter">CAMPUS CONNECT</h2>
                        </div>

                        <h1 className="text-5xl md:text-6xl font-black leading-[1.1] drop-shadow-lg">
                            Holiday <br />
                            <span className="text-[#FBBF24]">Connections</span> 🎄
                        </h1>

                        <p className="text-lg text-white/80 max-w-sm leading-relaxed font-medium">
                            Experience the magic of campus life. Connect, collaborate, and celebrate this festive season.
                        </p>
                    </div>

                    <div className="flex -space-x-3">
                        {[1, 2, 3, 4].map(i => (
                            <div key={i} className="w-10 h-10 rounded-full border-2 border-[#064e3b] bg-slate-200 overflow-hidden shadow-lg">
                                <img src={`https://i.pravatar.cc/100?u=${i}`} alt="" />
                            </div>
                        ))}
                        <div className="w-10 h-10 rounded-full border-2 border-[#064e3b] bg-white text-[#064e3b] flex items-center justify-center text-xs font-bold shadow-lg">
                            +5k
                        </div>
                    </div>
                </div>
            </div>

            {/* Right Side - Form */}
            <div className="w-full md:w-7/12 flex items-center justify-center p-6 md:p-12 bg-white">
                <div className="w-full max-w-md space-y-10">
                    <div className="text-center md:text-left">
                        <h2 className="text-4xl font-black text-slate-900 tracking-tight">Welcome Back</h2>
                        <p className="text-slate-500 mt-3 text-lg">Sign in to join the campus community.</p>
                    </div>

                    {error && (
                        <div className="p-4 rounded-2xl bg-red-50 border border-red-100 text-red-600 text-sm flex gap-3 items-center">
                            <AlertTriangle size={20} className="shrink-0" />
                            <span className="font-medium">{error}</span>
                        </div>
                    )}

                    <form onSubmit={handleEmailLogin} className="space-y-4">
                        <div className="space-y-1">
                            <label className="text-sm font-bold text-slate-700 ml-1">Email Address</label>
                            <div className="relative">
                                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                                <input
                                    type="email"
                                    required
                                    className="w-full pl-12 pr-4 py-3.5 bg-slate-50 border-2 border-transparent focus:border-indigo-500 focus:bg-white rounded-2xl transition-all outline-none text-slate-800 font-medium"
                                    placeholder="name@college.edu"
                                    value={email}
                                    onChange={(e) => setEmail(e.target.value)}
                                />
                            </div>
                        </div>

                        <div className="space-y-1">
                            <div className="flex justify-between items-center px-1">
                                <label className="text-sm font-bold text-slate-700">Password</label>
                                <a href="#" className="text-xs font-bold text-indigo-600 hover:underline">Forgot?</a>
                            </div>
                            <div className="relative">
                                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                                <input
                                    type="password"
                                    required
                                    className="w-full pl-12 pr-4 py-3.5 bg-slate-50 border-2 border-transparent focus:border-indigo-500 focus:bg-white rounded-2xl transition-all outline-none text-slate-800 font-medium"
                                    placeholder="••••••••"
                                    value={password}
                                    onChange={(e) => setPassword(e.target.value)}
                                />
                            </div>
                        </div>

                        <button
                            type="submit"
                            disabled={loading}
                            className="w-full bg-slate-900 hover:bg-black text-white font-bold py-4 rounded-2xl shadow-xl transition-all flex items-center justify-center gap-2 group"
                        >
                            {loading ? 'Signing in...' : 'Sign In'}
                            <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform" />
                        </button>
                    </form>

                    <div className="relative py-2">
                        <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-slate-100"></div></div>
                        <div className="relative flex justify-center text-xs uppercase"><span className="bg-white px-2 text-slate-400 font-bold tracking-widest">Or continue with</span></div>
                    </div>

                    <div className="grid grid-cols-1 gap-4">
                        <button
                            onClick={handleGoogleLogin}
                            disabled={loading}
                            className="w-full flex items-center justify-center gap-4 py-4 bg-white border-2 border-slate-100 rounded-2xl hover:border-indigo-500/30 hover:bg-indigo-50/10 transition-all shadow-sm hover:shadow-xl group"
                        >
                            <svg className="w-6 h-6" viewBox="0 0 24 24">
                                <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4" />
                                <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853" />
                                <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05" />
                                <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335" />
                            </svg>
                            <span className="font-bold text-slate-800 tracking-tight">Continue with Google</span>
                        </button>
                    </div>

                    <p className="text-center text-sm font-medium text-slate-500">
                        Don't have an account? <Link to="/signup" className="text-indigo-600 font-bold hover:underline">Sign Up Free</Link>
                    </p>

                    <div className="pt-6 border-t border-slate-100 flex flex-col md:flex-row items-center justify-between gap-4">
                        <p className="text-xs font-bold text-slate-400 tracking-widest uppercase text-center md:text-left">
                            Powered by Google Cloud AI
                        </p>
                        <div className="flex gap-4">
                            <span className="text-[10px] font-black text-indigo-500 uppercase tracking-tighter cursor-pointer hover:underline">Privacy</span>
                            <span className="text-[10px] font-black text-indigo-500 uppercase tracking-tighter cursor-pointer hover:underline">Terms</span>
                            <span className="text-[10px] font-black text-indigo-500 uppercase tracking-tighter cursor-pointer hover:underline">Help</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Login;
