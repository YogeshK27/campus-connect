import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { dbService } from '../../services/db.service';
import { auth } from '../../lib/firebase';
import { onAuthStateChanged } from 'firebase/auth';
import { Loader2 } from 'lucide-react';

const ProfileSetup: React.FC = () => {
    const navigate = useNavigate();
    const [loading, setLoading] = useState(false);
    const [user, setUser] = useState<any>(null);
    const [formData, setFormData] = useState({
        college: 'Woxsen University',
        year: '',
        branch: '',
        bio: '',
        residence_type: 'Hostel'
    });

    useEffect(() => {
        const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
            if (currentUser) {
                setUser(currentUser);
            } else {
                navigate('/login');
            }
        });
        return () => unsubscribe();
    }, [navigate]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!user) return;
        setLoading(true);

        try {
            await dbService.updateUser(user.uid, {
                college: formData.college,
                year: formData.year,
                branch: formData.branch,
                bio: formData.bio,
                residence_type: formData.residence_type,
                profileComplete: true
            });
            navigate('/');
        } catch (error: any) {
            console.error(error);
            alert('Failed to update profile: ' + error.message);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="setup-container">
            <div className="setup-card">
                <h1>Complete Your Profile</h1>
                <p>We need a few more details to get you started.</p>

                <form onSubmit={handleSubmit} className="setup-form">
                    <div className="form-group">
                        <label>College Name</label>
                        <input
                            type="text"
                            name="college"
                            value={formData.college}
                            disabled
                            className="input-disabled"
                        />
                    </div>

                    <div className="row">
                        <div className="form-group">
                            <label>Year</label>
                            <select name="year" value={formData.year} onChange={handleChange} required>
                                <option value="">Select Year</option>
                                <option value="1">1st Year</option>
                                <option value="2">2nd Year</option>
                                <option value="3">3rd Year</option>
                                <option value="4">4th Year</option>
                                <option value="PG">Post Grad</option>
                            </select>
                        </div>

                        <div className="form-group">
                            <label>Branch / Major</label>
                            <input
                                type="text"
                                name="branch"
                                placeholder="e.g. CSE, B.Arch"
                                value={formData.branch}
                                onChange={handleChange}
                                required
                            />
                        </div>
                    </div>

                    <div className="form-group">
                        <label>Residence Type</label>
                        <div className="radio-group">
                            <label className={`radio-option ${formData.residence_type === 'Hostel' ? 'selected' : ''}`}>
                                <input
                                    type="radio"
                                    name="residence_type"
                                    value="Hostel"
                                    checked={formData.residence_type === 'Hostel'}
                                    onChange={handleChange}
                                />
                                Hostel
                            </label>
                            <label className={`radio-option ${formData.residence_type === 'Day Scholar' ? 'selected' : ''}`}>
                                <input
                                    type="radio"
                                    name="residence_type"
                                    value="Day Scholar"
                                    checked={formData.residence_type === 'Day Scholar'}
                                    onChange={handleChange}
                                />
                                Day Scholar
                            </label>
                        </div>
                    </div>

                    <div className="form-group">
                        <label>Bio (Optional)</label>
                        <textarea
                            name="bio"
                            placeholder="Tell us a bit about yourself..."
                            value={formData.bio}
                            onChange={handleChange}
                            rows={3}
                        />
                    </div>

                    <button type="submit" className="submit-btn" disabled={loading}>
                        {loading ? <Loader2 className="animate-spin w-5 h-5 mx-auto" /> : 'Complete Setup'}
                    </button>
                </form>
            </div>

            <style>{`
                .setup-container {
                    min-height: 100vh;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    background: var(--color-bg);
                    padding: 1rem;
                }

                .setup-card {
                    background: var(--color-surface);
                    border: 1px solid var(--color-border);
                    border-radius: var(--radius-lg);
                    padding: 2rem;
                    width: 100%;
                    max-width: 500px;
                }

                h1 {
                    font-size: 1.5rem;
                    font-weight: 700;
                    margin-bottom: 0.5rem;
                }

                p {
                    color: var(--color-text-secondary);
                    margin-bottom: 2rem;
                    font-size: 0.875rem;
                }

                .setup-form {
                    display: flex;
                    flex-direction: column;
                    gap: 1.5rem;
                }

                .form-group {
                    display: flex;
                    flex-direction: column;
                    gap: 0.5rem;
                }

                .row {
                    display: grid;
                    grid-template-columns: 1fr 1fr;
                    gap: 1rem;
                }

                label {
                    font-size: 0.875rem;
                    font-weight: 500;
                    color: var(--color-text-secondary);
                }

                input, select, textarea {
                    background: var(--color-bg);
                    border: 1px solid var(--color-border);
                    padding: 0.75rem;
                    border-radius: var(--radius-md);
                    color: var(--color-text-main);
                    width: 100%;
                }

                input:focus, select:focus, textarea:focus {
                    border-color: var(--color-primary);
                    outline: none;
                }

                .input-disabled {
                    opacity: 0.6;
                    cursor: not-allowed;
                }

                .radio-group {
                    display: flex;
                    gap: 1rem;
                }

                .radio-option {
                    flex: 1;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    gap: 0.5rem;
                    padding: 0.75rem;
                    border: 1px solid var(--color-border);
                    border-radius: var(--radius-md);
                    cursor: pointer;
                    transition: all 0.2s;
                }

                .radio-option.selected {
                    background: rgba(109, 40, 217, 0.1);
                    border-color: var(--color-primary);
                    color: var(--color-primary);
                }

                .radio-option input {
                    width: auto;
                    display: none;
                }

                .submit-btn {
                    background: var(--color-primary);
                    color: white;
                    padding: 0.875rem;
                    border-radius: var(--radius-md);
                    font-weight: 600;
                    margin-top: 1rem;
                    cursor: pointer;
                }

                .submit-btn:hover {
                    background: var(--color-primary-hover);
                }
                
                .submit-btn:disabled {
                    opacity: 0.7;
                    cursor: not-allowed;
                }
            `}</style>
        </div>
    );
};

export default ProfileSetup;
