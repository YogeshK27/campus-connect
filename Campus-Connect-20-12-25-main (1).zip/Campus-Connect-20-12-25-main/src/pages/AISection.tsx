import React, { useState } from 'react';
import SmartPostGenerator from '../components/ai/SmartPostGenerator';
import Chatbot from '../components/ai/Chatbot';
import Flashcards from '../components/ai/Flashcards';
import { PenTool, MessageSquare, BrainCircuit, Sparkles } from 'lucide-react';

const AISection: React.FC = () => {
    const [activeTab, setActiveTab] = useState<'posts' | 'chat' | 'flashcards'>('posts');

    return (
        <div className="h-full flex flex-col bg-[var(--color-bg)]">
            {/* Header */}
            <div className="p-4 border-b border-[var(--color-border)] flex items-center gap-3 bg-[var(--color-surface)] sticky top-0 z-10 glass-effect">
                <div className="p-2 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-lg shadow-lg">
                    <Sparkles className="text-white w-6 h-6" />
                </div>
                <div>
                    <h1 className="text-xl font-bold text-[var(--color-text-main)]">Woxify AI</h1>
                    <p className="text-xs text-[var(--color-text-secondary)]">Powered by Gemini Pro & Flash</p>
                </div>
            </div>

            {/* Tabs */}
            <div className="flex bg-[var(--color-surface)] border-b border-[var(--color-border)] px-4">
                <button
                    onClick={() => setActiveTab('posts')}
                    className={`flex items-center gap-2 px-4 py-3 font-medium text-sm transition-all border-b-2 ${activeTab === 'posts'
                            ? 'border-indigo-600 text-indigo-600'
                            : 'border-transparent text-[var(--color-text-secondary)] hover:text-[var(--color-text-main)]'
                        }`}
                >
                    <PenTool size={18} />
                    Smart Posts
                </button>
                <button
                    onClick={() => setActiveTab('chat')}
                    className={`flex items-center gap-2 px-4 py-3 font-medium text-sm transition-all border-b-2 ${activeTab === 'chat'
                            ? 'border-indigo-600 text-indigo-600'
                            : 'border-transparent text-[var(--color-text-secondary)] hover:text-[var(--color-text-main)]'
                        }`}
                >
                    <MessageSquare size={18} />
                    Chatbot
                </button>
                <button
                    onClick={() => setActiveTab('flashcards')}
                    className={`flex items-center gap-2 px-4 py-3 font-medium text-sm transition-all border-b-2 ${activeTab === 'flashcards'
                            ? 'border-indigo-600 text-indigo-600'
                            : 'border-transparent text-[var(--color-text-secondary)] hover:text-[var(--color-text-main)]'
                        }`}
                >
                    <BrainCircuit size={18} />
                    Flashcards
                </button>
            </div>

            {/* Content Area */}
            <div className="flex-1 overflow-y-auto p-4 sm:p-6 bg-[var(--color-bg)]">
                <div className="max-w-4xl mx-auto">
                    {activeTab === 'posts' && <SmartPostGenerator />}
                    {activeTab === 'chat' && <Chatbot />}
                    {activeTab === 'flashcards' && <Flashcards />}
                </div>
            </div>
        </div>
    );
};

export default AISection;
