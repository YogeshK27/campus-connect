import React, { useState, useEffect } from 'react';
import { ExternalLink, Link as LinkIcon, Plus, Loader2, BookOpen, Upload } from 'lucide-react';
import { auth, db, storage } from '../lib/firebase';
import { collection, addDoc, onSnapshot, query, orderBy, serverTimestamp } from 'firebase/firestore';
import { onAuthStateChanged } from 'firebase/auth';
import { ref as storageRef, uploadBytes, getDownloadURL } from 'firebase/storage';

interface Note {
  $id: string;
  title: string;
  subject: string;
  semester: number;
  description?: string;
  resourceLink: string;
  uploadedBy: string;
  uploaderId: string;
  createdAt: string;
  type: 'link' | 'file';
}

const Notes: React.FC = () => {
  const [notes, setNotes] = useState<Note[]>([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [currentUser, setCurrentUser] = useState<any>(null);

  // Form State
  const [title, setTitle] = useState('');
  const [subject, setSubject] = useState('');
  const [semester, setSemester] = useState<number>(1);
  const [description, setDescription] = useState('');
  const [link, setLink] = useState('');
  const [file, setFile] = useState<File | null>(null); // New file state
  const [showForm, setShowForm] = useState(false);
  const [uploadType, setUploadType] = useState<'link' | 'file'>('link');

  // Filters
  const [filterSemester, setFilterSemester] = useState<number | 'All'>('All');

  useEffect(() => {
    const unsubscribeAuth = onAuthStateChanged(auth, (user) => {
      setCurrentUser(user);
    });

    const q = query(collection(db, 'notes'), orderBy('createdAt', 'desc'));
    setLoading(true);
    const unsubscribeNotes = onSnapshot(q, (snapshot) => {
      const fetchedNotes = snapshot.docs.map(doc => ({
        $id: doc.id,
        ...doc.data()
      })) as Note[];
      setNotes(fetchedNotes);
      setLoading(false);
    });

    return () => {
      unsubscribeAuth();
      unsubscribeNotes();
    };
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return alert("Please login to share notes");
    if (!title || !subject) return;

    let finalResourceLink = link;

    if (uploadType === 'link') {
      if (!link.startsWith('http')) {
        alert('Please provide a valid URL (http/https)');
        return;
      }
    } else {
      if (!file) return alert("Please select a file");
      // Upload File logic
      try {
        const fileRef = storageRef(storage, `notes/${Date.now()}_${file.name}`);
        const snapshot = await uploadBytes(fileRef, file);
        finalResourceLink = await getDownloadURL(snapshot.ref);
      } catch (err: any) {
        console.error("Upload error:", err);
        return alert("File upload failed");
      }
    }

    setSubmitting(true);
    try {
      await addDoc(collection(db, 'notes'), {
        title,
        subject,
        semester,
        description,
        resourceLink: finalResourceLink,
        uploadedBy: currentUser.displayName || 'Student',
        uploaderId: currentUser.uid,
        createdAt: serverTimestamp(),
        type: uploadType
      });

      setTitle('');
      setSubject('');
      setSemester(1);
      setDescription('');
      setLink('');
      setFile(null);
      setShowForm(false);
    } catch (error: any) {
      console.error(error);
      alert("Failed to share note: " + error.message);
    } finally {
      setSubmitting(false);
    }
  };

  const filteredNotes = notes.filter(n => filterSemester === 'All' || n.semester === filterSemester);

  return (
    <div className="page-container h-full overflow-y-auto pb-20">
      <div className="header-actions">
        <h1>Notes & Resources</h1>
        <button className="primary-btn" onClick={() => setShowForm(!showForm)}>
          <Plus size={20} /> Share Resource
        </button>
      </div>

      {showForm && (
        <div className="share-section">
          <h3>Share a Resource</h3>

          <div className="flex gap-4 mb-4">
            <button
              type="button"
              className={`tab-btn ${uploadType === 'link' ? 'active' : ''}`}
              onClick={() => setUploadType('link')}
            >
              <LinkIcon size={16} /> Link
            </button>
            <button
              type="button"
              className={`tab-btn ${uploadType === 'file' ? 'active' : ''}`}
              onClick={() => setUploadType('file')}
            >
              <Upload size={16} /> File Upload
            </button>
          </div>

          <form onSubmit={handleSubmit}>
            <div className="grid-2">
              <input type="text" placeholder="Title (e.g. Unit 1 Notes)" value={title} onChange={e => setTitle(e.target.value)} required />
              <input type="text" placeholder="Subject (e.g. Data Structures)" value={subject} onChange={e => setSubject(e.target.value)} required />
            </div>
            <div className="grid-2">
              <select value={semester} onChange={e => setSemester(Number(e.target.value))}>
                {[1, 2, 3, 4, 5, 6, 7, 8].map(s => <option key={s} value={s}>Semester {s}</option>)}
              </select>
              <input type="text" placeholder="Description (Optional)" value={description} onChange={e => setDescription(e.target.value)} />
            </div>

            {uploadType === 'link' ? (
              <div className="link-input">
                <LinkIcon size={18} className="icon" />
                <input type="url" placeholder="Paste HTTPS link (e.g. Google Drive)" value={link} onChange={e => setLink(e.target.value)} required={uploadType === 'link'} />
              </div>
            ) : (
              <div className="file-input-wrapper">
                <input type="file" onChange={e => setFile(e.target.files ? e.target.files[0] : null)} required={uploadType === 'file'} accept=".pdf,.doc,.docx,.ppt,.pptx,.txt" />
              </div>
            )}

            <button type="submit" className="upload-btn" disabled={submitting || !currentUser}>
              {submitting ? 'Sharing...' : 'Share Resource'} {submitting ? <Loader2 className="animate-spin ml-2" size={16} /> : <ExternalLink size={16} />}
            </button>
          </form>
        </div>
      )}

      <div className="filters mb-6">
        <span className="text-sm text-[var(--color-text-muted)] mr-2">Filter by Semester:</span>
        <div className="flex gap-2 flex-wrap">
          <button
            className={`filter-chip ${filterSemester === 'All' ? 'active' : ''}`}
            onClick={() => setFilterSemester('All')}
          >
            All
          </button>
          {[1, 2, 3, 4, 5, 6, 7, 8].map(s => (
            <button
              key={s}
              className={`filter-chip ${filterSemester === s ? 'active' : ''}`}
              onClick={() => setFilterSemester(s)}
            >
              Sem {s}
            </button>
          ))}
        </div>
      </div>

      <div className="notes-list">
        {loading ? (
          <div className="flex justify-center p-8 text-[var(--color-text-muted)]">
            <Loader2 className="animate-spin" />
          </div>
        ) : (
          filteredNotes.length > 0 ? filteredNotes.map(note => (
            <div key={note.$id} className="note-card">
              <div className="note-icon">
                <BookOpen size={24} />
              </div>
              <div className="note-info">
                <h4>{note.title}</h4>
                <div className="flex gap-2 text-xs mb-1">
                  <span className="badge">Sem {note.semester}</span>
                  <span className="badge">{note.subject}</span>
                </div>
                {note.description && <p className="desc">{note.description}</p>}
                <span className="uploader">Shared by {note.uploadedBy}</span>
              </div>
              <a href={note.resourceLink} target="_blank" rel="noopener noreferrer" className="download-btn">
                {note.type === 'file' ? <Upload size={20} /> : <ExternalLink size={20} />}
              </a>
            </div>
          )) : (
            <p className="empty-state">No resources shared yet.</p>
          )
        )}
      </div>

      <style>{`
                .page-container {
                    padding: 1rem;
                    max-width: 800px;
                    margin: 0 auto;
                }
                .header-actions {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    margin-bottom: 2rem;
                }
                h1 { color: var(--color-text-main); font-size: 1.5rem; font-weight: 700; }
                .primary-btn {
                    background: var(--color-primary);
                    color: white;
                    border: none;
                    padding: 0.5rem 1rem;
                    border-radius: var(--radius-md);
                    display: flex;
                    align-items: center;
                    gap: 0.5rem;
                    cursor: pointer;
                }
                .share-section {
                    background: var(--color-surface);
                    padding: 1.5rem;
                    border: 1px solid var(--color-border);
                    border-radius: var(--radius-lg);
                    margin-bottom: 2rem;
                }
                .share-section h3 { color: var(--color-text-main); margin-bottom: 1rem; }
                .share-section form {
                    display: flex;
                    flex-direction: column;
                    gap: 1rem;
                }
                .grid-2 {
                    display: grid;
                    grid-template-columns: 1fr 1fr;
                    gap: 1rem;
                }
                @media (max-width: 640px) {
                    .grid-2 { grid-template-columns: 1fr; }
                }
                .tab-btn {
                    padding: 0.5rem 1rem;
                    background: transparent;
                    border: 1px solid var(--color-border);
                    color: var(--color-text-secondary);
                    border-radius: var(--radius-md);
                    cursor: pointer;
                    display: flex;
                    align-items: center;
                    gap: 0.5rem;
                }
                .tab-btn.active {
                    background: var(--color-primary);
                    color: white;
                    border-color: var(--color-primary);
                }
                .link-input {
                    display: flex;
                    align-items: center;
                    background: var(--color-bg);
                    border: 1px solid var(--color-border);
                    border-radius: var(--radius-md);
                    padding-left: 0.75rem;
                }
                .link-input .icon {
                    color: var(--color-text-muted);
                }
                .link-input input {
                    border: none;
                }
                .file-input-wrapper input {
                    padding: 0.5rem;
                    border: 1px solid var(--color-border);
                    border-radius: var(--radius-md);
                    width: 100%;
                    background: var(--color-bg);
                    color: var(--color-text-main);
                }
                .upload-btn {
                    background: var(--color-primary);
                    color: white;
                    border: none;
                    padding: 0.75rem;
                    border-radius: var(--radius-md);
                    cursor: pointer;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    gap: 0.5rem;
                    font-weight: 600;
                }
                .filters {
                    display: flex;
                    align-items: center;
                    flex-wrap: wrap;
                }
                .filter-chip {
                    background: var(--color-surface);
                    border: 1px solid var(--color-border);
                    color: var(--color-text-secondary);
                    padding: 0.25rem 0.75rem;
                    border-radius: var(--radius-full);
                    font-size: 0.8rem;
                    cursor: pointer;
                    transition: all 0.2s;
                }
                .filter-chip.active {
                    background: var(--color-primary);
                    color: white;
                    border-color: var(--color-primary);
                }
                .notes-list {
                    display: grid;
                    gap: 1rem;
                }
                .note-card {
                    background: var(--color-surface);
                    border: 1px solid var(--color-border);
                    border-radius: var(--radius-lg);
                    padding: 1rem;
                    display: flex;
                    align-items: center;
                    gap: 1rem;
                    transition: transform 0.2s;
                }
                .note-card:hover {
                    transform: translateY(-2px);
                    border-color: var(--color-primary);
                }
                .note-icon {
                    background: var(--color-surface-hover);
                    padding: 1rem;
                    border-radius: var(--radius-md);
                    color: var(--color-primary);
                }
                .note-info {
                    flex: 1;
                    color: var(--color-text-main);
                }
                .note-info h4 {
                    margin-bottom: 0.25rem;
                    font-weight: 600;
                }
                .badge {
                    background: var(--color-surface-hover);
                    padding: 2px 6px;
                    border-radius: 4px;
                    color: var(--color-text-secondary);
                }
                .desc {
                    color: var(--color-text-secondary);
                    font-size: 0.875rem;
                    margin-bottom: 0.25rem;
                }
                .uploader {
                    font-size: 0.75rem;
                    color: var(--color-text-muted);
                }
                .download-btn {
                    color: var(--color-text-secondary);
                    padding: 0.5rem;
                    border-radius: 50%;
                    transition: background 0.2s;
                }
                .download-btn:hover {
                    background: var(--color-surface-hover);
                    color: var(--color-primary);
                }
                .empty-state {
                    text-align: center;
                    color: var(--color-text-muted);
                    padding: 2rem;
                }
                input, select {
                    padding: 0.75rem;
                    background: var(--color-bg);
                    border: 1px solid var(--color-border);
                    border-radius: var(--radius-md);
                    color: var(--color-text-main);
                    width: 100%;
                }
            `}</style>
    </div>
  );
};

export default Notes;
