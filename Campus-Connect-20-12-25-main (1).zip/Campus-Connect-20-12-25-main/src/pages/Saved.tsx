import React from 'react';
import { Bookmark, FileText, Calendar, Car } from 'lucide-react';

const Saved: React.FC = () => {
    return (
        <div className="saved-container">
            <h1>Saved Items</h1>

            <div className="saved-tabs">
                <button className="active">All</button>
                <button>Posts</button>
                <button>Rides</button>
                <button>Events</button>
                <button>Notes</button>
            </div>

            <div className="saved-list">
                {/* Mock Saved Item 1 */}
                <div className="saved-item">
                    <div className="saved-icon icon-ride"><Car size={20} /></div>
                    <div className="saved-content">
                        <h3>Ride to City Center</h3>
                        <p>Leaving at 5:30 PM • ₹150</p>
                    </div>
                    <button className="unsave-btn"><Bookmark size={20} fill="currentColor" /></button>
                </div>

                {/* Mock Saved Item 2 */}
                <div className="saved-item">
                    <div className="saved-icon icon-event"><Calendar size={20} /></div>
                    <div className="saved-content">
                        <h3>Tech Fest 2025</h3>
                        <p>Auditorium A • 10 AM</p>
                    </div>
                    <button className="unsave-btn"><Bookmark size={20} fill="currentColor" /></button>
                </div>

                {/* Mock Saved Item 3 */}
                <div className="saved-item">
                    <div className="saved-icon icon-note"><FileText size={20} /></div>
                    <div className="saved-content">
                        <h3>OS Notes - Unit 3</h3>
                        <p>PDF • 2.4 MB</p>
                    </div>
                    <button className="unsave-btn"><Bookmark size={20} fill="currentColor" /></button>
                </div>
            </div>

            <style>{`
        .saved-container h1 {
          margin-bottom: 1.5rem;
        }

        .saved-tabs {
          display: flex;
          gap: 0.5rem;
          margin-bottom: 1.5rem;
          overflow-x: auto;
          padding-bottom: 0.5rem;
        }

        .saved-tabs button {
          padding: 0.375rem 0.75rem;
          border-radius: var(--radius-full);
          border: 1px solid var(--color-border);
          font-size: 0.875rem;
          color: var(--color-text-secondary);
          white-space: nowrap;
        }

        .saved-tabs button.active {
          background: var(--color-primary);
          color: white;
          border-color: var(--color-primary);
        }

        .saved-list {
          display: flex;
          flex-direction: column;
          gap: 1rem;
        }

        .saved-item {
          display: flex;
          align-items: center;
          gap: 1rem;
          background: var(--color-surface);
          padding: 1rem;
          border-radius: var(--radius-lg);
          border: 1px solid var(--color-border);
        }

        .saved-icon {
          width: 48px;
          height: 48px;
          border-radius: 12px;
          display: flex;
          align-items: center;
          justify-content: center;
          color: white;
        }

        .icon-ride { background: #ef4444; }
        .icon-event { background: #f59e0b; }
        .icon-note { background: #10b981; }

        .saved-content {
          flex: 1;
        }

        .saved-content h3 {
          font-size: 1rem;
          font-weight: 600;
          margin-bottom: 0.25rem;
        }

        .saved-content p {
          color: var(--color-text-muted);
          font-size: 0.875rem;
        }

        .unsave-btn {
          color: var(--color-primary);
          padding: 0.5rem;
        }
      `}</style>
        </div>
    );
};

export default Saved;
