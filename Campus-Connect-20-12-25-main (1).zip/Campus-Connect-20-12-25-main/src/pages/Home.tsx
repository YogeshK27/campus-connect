import React, { useEffect, useState } from 'react';
import CreatePost from '../components/feed/CreatePost';
import PostItem, { type Post } from '../components/feed/PostItem';
import CampusConcierge from '../components/Agent/CampusConcierge';
import StudyBuddy from '../components/Agent/StudyBuddy';
import EventRecommender from '../components/Agent/EventRecommender';
import ScheduleAssistant from '../components/Agent/ScheduleAssistant';
import ProactiveAssistant from '../components/Agent/ProactiveAssistant';
import { dbService } from '../services/db.service';

const Home: React.FC = () => {
    const [posts, setPosts] = useState<Post[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        setLoading(true);
        const unsubscribe = dbService.subscribeToCollection('posts', (data) => {
            setPosts(data as Post[]);
            setLoading(false);
        });

        return () => unsubscribe();
    }, []);

    return (
        <div className="feed-container h-full overflow-y-auto pb-20">
            <ProactiveAssistant />
            <CampusConcierge />
            <StudyBuddy />
            <EventRecommender />
            <ScheduleAssistant />
            <CreatePost />

            {loading ? (
                <div className="flex justify-center p-8 text-[var(--color-text-muted)]">
                    Loading posts...
                </div>
            ) : (
                <div className="feed-list flex flex-col gap-1">
                    {posts.length > 0 ? (
                        posts.map(post => (
                            <PostItem key={post.$id} post={post} />
                        ))
                    ) : (
                        <div className="text-center p-8 text-[var(--color-text-muted)] border border-dashed border-[var(--color-border)] rounded-xl">
                            No posts yet. Be the first to share something!
                        </div>
                    )}
                </div>
            )}
        </div>
    );
};

export default Home;
