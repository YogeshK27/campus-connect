import React, { useState, useEffect } from 'react';
import { MapPin, Tag, Image as ImageIcon, Plus, X, Loader2 } from 'lucide-react';
import { auth, db, storage } from '../lib/firebase';
import { collection, addDoc, onSnapshot, query, orderBy, serverTimestamp } from 'firebase/firestore';
import { ref as storageRef, uploadBytes, getDownloadURL } from 'firebase/storage';
import { onAuthStateChanged } from 'firebase/auth';

interface LostItem {
  $id: string;
  title: string;
  description: string;
  location: string;
  type: 'Lost' | 'Found';
  image?: string;
  contact: string;
  createdAt: string;
  status: 'Open' | 'Resolved';
  userId: string;
  userName: string;
}

const LostFound: React.FC = () => {
  const [items, setItems] = useState<LostItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreate, setShowCreate] = useState(false);
  const [currentUser, setCurrentUser] = useState<any>(null);

  // Form State
  const [form, setForm] = useState({
    title: '',
    description: '',
    location: '',
    type: 'Lost' as 'Lost' | 'Found',
    contact: ''
  });
  const [image, setImage] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);

  useEffect(() => {
    const unsubscribeAuth = onAuthStateChanged(auth, (user) => {
      setCurrentUser(user);
    });

    const q = query(collection(db, 'lost_found'), orderBy('createdAt', 'desc'));
    setLoading(true);
    const unsubscribeItems = onSnapshot(q, (snapshot) => {
      const fetchedItems = snapshot.docs.map(doc => ({
        $id: doc.id,
        ...doc.data()
      })) as LostItem[];
      setItems(fetchedItems);
      setLoading(false);
    });

    return () => {
      unsubscribeAuth();
      unsubscribeItems();
    };
  }, []);

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setImage(file);
      setPreview(URL.createObjectURL(file));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return alert("Please login to post");
    setUploading(true);

    try {
      let imageUrl = '';
      if (image) {
        const fileRef = storageRef(storage, `lost-found/${Date.now()}_${image.name}`);
        await uploadBytes(fileRef, image);
        imageUrl = await getDownloadURL(fileRef);
      }

      await addDoc(collection(db, 'lost_found'), {
        ...form,
        image: imageUrl,
        userId: currentUser.uid,
        userName: currentUser.displayName || 'Student',
        status: 'Open',
        createdAt: serverTimestamp()
      });

      setShowCreate(false);
      setForm({ title: '', description: '', location: '', type: 'Lost', contact: '' });
      setImage(null);
      setPreview(null);
    } catch (error: any) {
      console.error(error);
      alert('Failed to post item: ' + error.message);
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="page-container h-full overflow-y-auto pb-20">
      <div className="header-actions">
        <h1>Lost & Found</h1>
        <button className="primary-btn" onClick={() => setShowCreate(!showCreate)}>
          <Plus size={20} /> Report Item
        </button>
      </div>

      {showCreate && (
        <div className="create-card">
          <h3>Report Lost/Found Item</h3>
          <form onSubmit={handleSubmit}>
            <div className="type-toggle">
              <button type="button" className={`type-btn ${form.type === 'Lost' ? 'lost' : ''}`} onClick={() => setForm({ ...form, type: 'Lost' })}>Lost</button>
              <button type="button" className={`type-btn ${form.type === 'Found' ? 'found' : ''}`} onClick={() => setForm({ ...form, type: 'Found' })}>Found</button>
            </div>
            <input type="text" placeholder="Item Name" value={form.title} onChange={e => setForm({ ...form, title: e.target.value })} required />
            <textarea placeholder="Description" value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} rows={3} required />
            <input type="text" placeholder="Location (Last seen/Found at)" value={form.location} onChange={e => setForm({ ...form, location: e.target.value })} required />
            <input type="text" placeholder="Contact Info (Phone/Email)" value={form.contact} onChange={e => setForm({ ...form, contact: e.target.value })} required />

            <div className="image-upload">
              <label className="upload-label">
                <ImageIcon size={20} /> Add Photo
                <input type="file" hidden accept="image/*" onChange={handleImageSelect} />
              </label>
              {preview && (
                <div className="preview-container">
                  <img src={preview} alt="Preview" />
                  <button type="button" onClick={() => { setImage(null); setPreview(null); }} className="remove-img"><X size={14} /></button>
                </div>
              )}
            </div>

            <button type="submit" className="submit-btn" disabled={uploading || !currentUser}>
              {uploading ? 'Posting...' : 'Post Report'} {uploading && <Loader2 className="animate-spin inline ml-2" size={16} />}
            </button>
          </form>
        </div>
      )}

      <div className="items-grid">
        {loading ? (
          <div className="flex justify-center p-8 text-[var(--color-text-muted)] col-span-full">
            <Loader2 className="animate-spin" />
          </div>
        ) : (
          items.length > 0 ? items.map(item => (
            <div key={item.$id} className="item-card">
              <div className="item-image">
                {item.image ? (
                  <img src={item.image} alt={item.title} />
                ) : (
                  <div className="placeholder-img"><ImageIcon size={32} /></div>
                )}
                <span className={`status-badge ${item.type.toLowerCase()}`}>{item.type}</span>
              </div>
              <div className="item-content">
                <h3>{item.title}</h3>
                <p className="desc">{item.description}</p>
                <div className="meta">
                  <span><MapPin size={14} /> {item.location}</span>
                  <span><Tag size={14} /> {item.status}</span>
                </div>
                <div className="contact">Contact: {item.contact}</div>
                <div className="text-xs text-[var(--color-text-muted)] mt-2">Posted by {item.userName}</div>
              </div>
            </div>
          )) : <p className="col-span-full text-center text-[var(--color-text-muted)]">No items reported.</p>
        )}
      </div>

      <style>{`
          .page-container {
            padding: 1rem;
            max-width: 1000px;
            margin: 0 auto;
          }
          .header-actions {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
          }
          h1 { color: var(--color-text-main); font-size: 1.5rem; font-weight: 700; }
          .primary-btn {
            background: var(--color-primary);
            color: white;
            border: none;
            padding: 0.5rem 1rem;
            border-radius: var(--radius-md);
            display: flex;
            align-items: center;
            gap: 0.5rem;
            cursor: pointer;
          }
          .create-card {
            background: var(--color-surface);
            padding: 1.5rem;
            border-radius: var(--radius-lg);
            margin-bottom: 2rem;
            border: 1px solid var(--color-border);
            max-width: 600px;
            margin-left: auto;
            margin-right: auto;
          }
          .create-card form {
            display: flex;
            flex-direction: column;
            gap: 1rem;
            margin-top: 1rem;
          }
          .create-card h3 { color: var(--color-text-main); }
          .type-toggle {
            display: flex;
            gap: 1rem;
          }
          .type-btn {
            flex: 1;
            padding: 0.5rem;
            border: 1px solid var(--color-border);
            border-radius: var(--radius-md);
            background: transparent;
            color: var(--color-text-secondary);
            cursor: pointer;
          }
          .type-btn.lost { background: rgba(239, 68, 68, 0.1); color: #ef4444; border-color: #ef4444; }
          .type-btn.found { background: rgba(16, 185, 129, 0.1); color: #10b981; border-color: #10b981; }

          input, textarea {
            padding: 0.75rem;
            background: var(--color-bg);
            border: 1px solid var(--color-border);
            border-radius: var(--radius-md);
            color: var(--color-text-main);
          }
                        .upload-label {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            color: var(--color-primary);
            cursor: pointer;
            width: fit-content;
          }
                        .preview-container {
            position: relative;
            width: 100px;
            height: 100px;
            margin-top: 0.5rem;
          }
                        .preview-container img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            border-radius: var(--radius-md);
          }
                        .remove-img {
            position: absolute;
            top: -5px;
            right: -5px;
            background: red;
            color: white;
            border: none;
            border-radius: 50%;
            width: 20px;
            height: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
          }
                        .submit-btn {
            background: var(--color-primary);
            color: white;
            padding: 0.75rem;
            border: none;
            border-radius: var(--radius-md);
            font-weight: 600;
            cursor: pointer;
          }
                        .items-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: 1.5rem;
          }
                        .item-card {
            background: var(--color-surface);
            border: 1px solid var(--color-border);
            border-radius: var(--radius-lg);
            overflow: hidden;
          }
                        .item-image {
            position: relative;
            height: 180px;
            background: var(--color-surface-hover);
            display: flex;
            align-items: center;
            justify-content: center;
          }
                        .item-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
          }
                        .placeholder-img {
            color: var(--color-text-muted);
          }
                        .status-badge {
            position: absolute;
            top: 1rem;
            right: 1rem;
            padding: 0.25rem 0.75rem;
            border-radius: var(--radius-full);
            font-size: 0.75rem;
            font-weight: 600;
            text-transform: uppercase;
          }
                        .status-badge.lost { background: #ef4444; color: white; }
                        .status-badge.found { background: #10b981; color: white; }
                        
                        .item-content {
            padding: 1rem;
          }
                        .item-content h3 {
            margin-bottom: 0.5rem;
            font-size: 1.1rem;
            color: var(--color-text-main);
          }
                        .desc {
            color: var(--color-text-secondary);
            font-size: 0.9rem;
            margin-bottom: 1rem;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
          }
                        .meta {
            display: flex;
            gap: 1rem;
            color: var(--color-text-muted);
            font-size: 0.8rem;
            margin-bottom: 0.5rem;
          }
                        .meta span { display: flex; align-items: center; gap: 0.25rem; }
                        .contact {
            font-size: 0.85rem;
            font-weight: 500;
            color: var(--color-primary);
          }
          `}</style>
    </div>
  );
};

export default LostFound;
